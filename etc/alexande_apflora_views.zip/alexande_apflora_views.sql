-- phpMyAdmin SQL Dump
-- version 3.5.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 01. Okt 2013 um 03:28
-- Server Version: 5.1.70-cll
-- PHP-Version: 5.3.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `alexande_apflora_views`
--

-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApAnzKontr`
--
CREATE TABLE IF NOT EXISTS `vApAnzKontr` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Anzahl Kontrollen` bigint(21)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApAnzMassn`
--
CREATE TABLE IF NOT EXISTS `vApAnzMassn` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Anzahl Massnahmen` bigint(21)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApAnzMassnBisJahr`
--
CREATE TABLE IF NOT EXISTS `vApAnzMassnBisJahr` (
`ApArtId` int(10)
,`TPopMassnJahr` smallint(5)
,`AnzahlMassnahmen` decimal(41,0)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApAnzMassnProJahr`
--
CREATE TABLE IF NOT EXISTS `vApAnzMassnProJahr` (
`ApArtId` int(10)
,`TPopMassnJahr` smallint(5)
,`AnzahlMassnahmen` bigint(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApAnzMassnProJahr0`
--
CREATE TABLE IF NOT EXISTS `vApAnzMassnProJahr0` (
`ApArtId` int(10)
,`TPopMassnJahr` smallint(5)
,`AnzahlvonTPopMassnId` bigint(21)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApApBerichtRelevant`
--
CREATE TABLE IF NOT EXISTS `vApApBerichtRelevant` (
`ApArtId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApArtenAnzKontrInJahr`
--
CREATE TABLE IF NOT EXISTS `vApArtenAnzKontrInJahr` (
`ApArtId` int(10)
,`Artname` varchar(100)
,`TPopKontrId` int(10)
,`TPopKontrJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApJahresberichte`
--
CREATE TABLE IF NOT EXISTS `vApJahresberichte` (
`ApArtId` int(10)
,`JBerId` int(10)
,`Name` varchar(100)
,`JBerJahr` smallint(5)
,`JBerSituation` longtext
,`JBerVergleichVorjahrGesamtziel` longtext
,`JBerBeurteilung` varchar(50)
,`JBerVeraenGegenVorjahr` varchar(2)
,`JBerAnalyse` varchar(255)
,`JBerUmsetzung` longtext
,`JBerErfko` longtext
,`JBerATxt` longtext
,`JBerBTxt` longtext
,`JBerCTxt` longtext
,`JBerDTxt` longtext
,`JBerDatum` date
,`JBerBearb` varchar(255)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApJahresberichteUndMassnahmen`
--
CREATE TABLE IF NOT EXISTS `vApJahresberichteUndMassnahmen` (
`ApArtId` int(10)
,`Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`AP Verantwortlich` varchar(255)
,`Artwert` int(11)
,`Jahr` smallint(5)
,`Anzahl Massnahmen` bigint(20)
,`Anzahl Massnahmen bisher` decimal(41,0)
,`Bericht erstellt` varchar(4)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApMassnJahre`
--
CREATE TABLE IF NOT EXISTS `vApMassnJahre` (
`ApArtId` int(10)
,`TPopMassnJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApOhnePop`
--
CREATE TABLE IF NOT EXISTS `vApOhnePop` (
`ApArtId` int(10)
,`Art` varchar(100)
,`Bearbeitungsstand AP` varchar(50)
,`Start AP im Jahr` smallint(5)
,`Stand Umsetzung AP` varchar(50)
,`Verantwortlich` varchar(255)
,`Population` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApZiele`
--
CREATE TABLE IF NOT EXISTS `vApZiele` (
`AP Id` int(10)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`AP verantwortlich` varchar(255)
,`Ziel Id` int(10)
,`Ziel ApId` int(10)
,`Ziel Jahr` smallint(5)
,`Ziel Typ` varchar(50)
,`Ziel Beschreibung` longtext
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vApZieleOhneAp`
--
CREATE TABLE IF NOT EXISTS `vApZieleOhneAp` (
`AP Id` int(10)
,`Ziel Id` int(10)
,`Ziel ApId` int(10)
,`Ziel Jahr` smallint(5)
,`Ziel Typ` varchar(50)
,`Ziel Beschreibung` longtext
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vAssozArten`
--
CREATE TABLE IF NOT EXISTS `vAssozArten` (
`ApArtId` int(10)
,`AP Art` varchar(100)
,`AP Bearbeitungsstand` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`AP verantwortlich` varchar(255)
,`AA Id` int(11)
,`AA Art` varchar(100)
,`AA Bemerkungen` text
,`AA MutWann` date
,`AA MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vAssozArtenOhneAp`
--
CREATE TABLE IF NOT EXISTS `vAssozArtenOhneAp` (
`AP ApArtId` int(10)
,`AA Id` int(11)
,`AA ApArtId` int(11)
,`AA Art` varchar(100)
,`AA Bemerkungen` text
,`AA MutWann` date
,`AA MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vAuswAnzProTPopAngezArtBestJahr0`
--
CREATE TABLE IF NOT EXISTS `vAuswAnzProTPopAngezArtBestJahr0` (
`ApArtId` int(10)
,`PopId` int(10)
,`TPopId` int(10)
,`TPopKontrId` int(10)
,`Artname` varchar(100)
,`PopNr` int(10)
,`PopName` varchar(150)
,`PopHerkunft` varchar(50)
,`TPopNr` int(10)
,`TPopGemeinde` varchar(255)
,`TPopFlurname` varchar(255)
,`TPopHerkunft` varchar(50)
,`TPopKontrTyp` varchar(50)
,`TPopKontrJahr` smallint(5)
,`TPopKontrDatum` date
,`TPopKontrBearb` varchar(255)
,`TPopKontrZaehleinheit1` varchar(50)
,`TPopKontrMethode1` varchar(50)
,`TPopKontrAnz1` int(10)
,`TPopKontrZaehleinheit2` varchar(50)
,`TPopKontrMethode2` varchar(50)
,`TPopKontrAnz2` int(10)
,`TPopKontrZaehleinheit3` varchar(50)
,`TPopKontrMethode3` varchar(50)
,`TPopKontrAnz3` int(10)
,`TPopKontrJungpfl` int(10)
,`TPopKontrVitalitaet` varchar(255)
,`TPopKontrUeberleb` smallint(5)
,`TPopKontrEntwicklung` varchar(50)
,`TPopKontrUrsach` varchar(255)
,`TPopKontrUrteil` varchar(255)
,`TPopKontrAendUms` varchar(255)
,`TPopKontrAendKontr` varchar(255)
,`TPopKontrTxt` longtext
,`TPopKontrLeb` varchar(255)
,`TPopKontrFlaeche` int(10)
,`TPopKontrLebUmg` varchar(255)
,`TPopKontrStrauchschicht` varchar(255)
,`TPopKontrBodenTyp` varchar(255)
,`TPopKontrBodenAbtrag` varchar(255)
,`TPopKontrWasserhaushalt` varchar(255)
,`TPopKontrHandlungsbedarf` longtext
,`TPopKontrUebFlaeche` int(10)
,`TPopKontrPlan` tinyint(1)
,`TPopKontrVeg` smallint(5)
,`TPopKontrNaBo` smallint(5)
,`TPopKontrUebPfl` smallint(5)
,`TPopKontrJungPflJN` tinyint(1)
,`TPopKontrVegHoeMax` smallint(5)
,`TPopKontrVegHoeMit` smallint(5)
,`TPopKontrGefaehrdung` varchar(255)
,`TPopKontrMutDat` datetime
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vAuswAp`
--
CREATE TABLE IF NOT EXISTS `vAuswAp` (
`ApArtId` int(10)
,`Art` varchar(100)
,`Bearbeitungsstand AP` varchar(50)
,`Start AP im Jahr` smallint(5)
,`Stand Umsetzung AP` varchar(50)
,`Verantwortlich` varchar(255)
,`Letzte Änderung` date
,`Letzte(r) Bearbeiter(in)` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vAuswApArtenAnzMassnInJahr0`
--
CREATE TABLE IF NOT EXISTS `vAuswApArtenAnzMassnInJahr0` (
`ApArtId` int(10)
,`Artname` varchar(100)
,`TPopMassnId` int(10)
,`TPopMassnJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vAuswApArtenBearbMassnInJahr0`
--
CREATE TABLE IF NOT EXISTS `vAuswApArtenBearbMassnInJahr0` (
`AdrName` varchar(255)
,`Art` varchar(100)
,`PopNr` int(10)
,`PopName` varchar(150)
,`TPopNr` int(10)
,`TPopGemeinde` varchar(255)
,`TPopFlurname` varchar(255)
,`TPopMassnJahr` smallint(5)
,`TPopMassnTyp` varchar(50)
,`TPopMassnTxt` varchar(255)
,`TPopMassnDatum` date
,`TPopMassnBemTxt` longtext
,`TPopMassnPlan` tinyint(1)
,`TPopMassnPlanBez` varchar(255)
,`TPopMassnFlaeche` int(10)
,`TPopMassnMarkierung` varchar(255)
,`TPopMassnAnsiedAnzTriebe` int(10)
,`TPopMassnAnsiedAnzPfl` int(10)
,`TPopMassnAnzPflanzstellen` int(10)
,`TPopMassnAnsiedWirtspfl` varchar(255)
,`TPopMassnAnsiedHerkunftPop` varchar(255)
,`TPopMassnAnsiedDatSamm` varchar(50)
,`TPopMassnAnsiedForm` varchar(255)
,`TPopMassnAnsiedPflanzanordnung` varchar(255)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vAuswApArtenMitMassnInJahr0`
--
CREATE TABLE IF NOT EXISTS `vAuswApArtenMitMassnInJahr0` (
`Art` varchar(100)
,`PopNr` int(10)
,`PopName` varchar(150)
,`TPopNr` int(10)
,`TPopGemeinde` varchar(255)
,`TPopFlurname` varchar(255)
,`TPopMassnJahr` smallint(5)
,`TPopMassnTyp` varchar(50)
,`TPopMassnTxt` varchar(255)
,`TPopMassnDatum` date
,`TPopMassnBearb` varchar(255)
,`TPopMassnBemTxt` longtext
,`TPopMassnPlan` tinyint(1)
,`TPopMassnPlanBez` varchar(255)
,`TPopMassnFlaeche` int(10)
,`TPopMassnMarkierung` varchar(255)
,`TPopMassnAnsiedAnzTriebe` int(10)
,`TPopMassnAnsiedAnzPfl` int(10)
,`TPopMassnAnzPflanzstellen` int(10)
,`TPopMassnAnsiedWirtspfl` varchar(255)
,`TPopMassnAnsiedHerkunftPop` varchar(255)
,`TPopMassnAnsiedDatSamm` varchar(50)
,`TPopMassnAnsiedForm` varchar(255)
,`TPopMassnAnsiedPflanzanordnung` varchar(255)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vAuswArtPopTPopMassn0`
--
CREATE TABLE IF NOT EXISTS `vAuswArtPopTPopMassn0` (
`ApArtId` int(10)
,`Art` varchar(100)
,`Aktionsplan Bearbeitungsstand` varchar(50)
,`PopId` int(10)
,`PopNr` int(10)
,`PopName` varchar(150)
,`TPopId` int(10)
,`TPopNr` int(10)
,`TPopFlurname` varchar(255)
,`TPopMassnId` int(10)
,`Jahr` smallint(5)
,`Massnahme` varchar(50)
,`TPopMassnTxt` varchar(255)
,`TPopMassnDatum` date
,`TPopMassnBearb` varchar(255)
,`TPopMassnBemTxt` longtext
,`TPopMassnPlan` tinyint(1)
,`TPopMassnPlanBez` varchar(255)
,`TPopMassnFlaeche` int(10)
,`TPopMassnMarkierung` varchar(255)
,`TPopMassnAnsiedAnzTriebe` int(10)
,`TPopMassnAnsiedAnzPfl` int(10)
,`TPopMassnAnzPflanzstellen` int(10)
,`TPopMassnAnsiedWirtspfl` varchar(255)
,`TPopMassnAnsiedHerkunftPop` varchar(255)
,`TPopMassnAnsiedDatSamm` varchar(50)
,`TPopMassnAnsiedForm` varchar(255)
,`TPopMassnAnsiedPflanzanordnung` varchar(255)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vAuswArtPopTPopMassnBerFuerAktArt0`
--
CREATE TABLE IF NOT EXISTS `vAuswArtPopTPopMassnBerFuerAktArt0` (
`ApArtId` int(10)
,`Art` varchar(100)
,`Aktionsplan-Status` varchar(50)
,`Aktionsplan-Jahr` smallint(5)
,`Aktionsplan-Umsetzung` varchar(50)
,`Population-Nr` int(10)
,`Population-Name` varchar(150)
,`Population-Herkunft` varchar(50)
,`Population - bekannt seit` smallint(5)
,`Teilpopulation-Nr` int(10)
,`Teilpopulation-Gemeinde` varchar(255)
,`Teilpopulation-Flurname` varchar(255)
,`Teilpopulation-X-Koodinate` int(10)
,`Teilpopulation-Y-Koordinate` int(10)
,`Teilpopulation-Radius` smallint(5)
,`Teilpopulation-Hoehe` smallint(5)
,`Teilpopulation-Beschreibung` varchar(255)
,`Teilpopulation-Kataster-Nr` varchar(255)
,`Teilpopulation-Verantwortlich` varchar(255)
,`Teilpopulation-Herkunft` varchar(50)
,`Teilpopulation - Herkunft unklar` tinyint(1)
,`Teilpopulation - Herkunft unklar Begründung` varchar(255)
,`Teilpopulation - Für Bericht relevant` text
,`Teilpopulation - bekannt seit` smallint(5)
,`Teilpopulation-Eigentümer` varchar(255)
,`Teilpopulation-Kontakt` varchar(255)
,`Teilpopulation-Nutzungszone` varchar(255)
,`Teilpopulation-Bewirtschafter` varchar(255)
,`Teilpopulation-Bewirtschaftung` varchar(255)
,`Teilpopulation-Bemerkungen` longtext
,`Massnahmenbericht-Jahr` smallint(5)
,`Massnahmenbericht-Erfolgsberuteilung` varchar(50)
,`Massnahmenbericht-Interpretation` longtext
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vAuswArtPopTPopMassnFuerAktArt0`
--
CREATE TABLE IF NOT EXISTS `vAuswArtPopTPopMassnFuerAktArt0` (
`ApArtId` int(10)
,`Art` varchar(100)
,`Aktionsplan-Status` varchar(50)
,`Aktionsplan-Jahr` smallint(5)
,`Aktionsplan-Umsetzung` varchar(50)
,`PopId` int(10)
,`Population-Nr` int(10)
,`Population-Name` varchar(150)
,`Population-Herkunft` varchar(50)
,`Population - bekannt seit` smallint(5)
,`TPopId` int(10)
,`Teilpopulation-Nr` int(10)
,`Teilpopulation-Gemeinde` varchar(255)
,`Teilpopulation-Flurname` varchar(255)
,`Teilpopulation-X-Koodinate` int(10)
,`Teilpopulation-Y-Koordinate` int(10)
,`Teilpopulation-Radius` smallint(5)
,`Teilpopulation-Höhe` smallint(5)
,`Teilpopulation-Beschreibung` varchar(255)
,`Teilpopulation-Kataster-Nr` varchar(255)
,`Teilpopulation-Verantwortlich` varchar(255)
,`Teilpopulation-Herkunft` varchar(50)
,`Teilpopulation - Herkunft unklar` tinyint(1)
,`Teilpopulation - Herkunft unklar Begründung` varchar(255)
,`Teilpopulation - Für Bericht relevant` text
,`Teilpopulation - bekannt seit` smallint(5)
,`Teilpopulation-Eigentümer` varchar(255)
,`Teilpopulation-Kontakt` varchar(255)
,`Teilpopulation-Nutzungszone` varchar(255)
,`Teilpopulation-Bewirtschafter` varchar(255)
,`Teilpopulation-Bewirtschaftung` varchar(255)
,`Teilpopulation-Bemerkungen` longtext
,`TPopMassnId` int(10)
,`Massnahme-Typ` varchar(50)
,`Massnahme-Beschreibung` varchar(255)
,`Massnahme-Datum` date
,`Massnahme-BearbeiterIn` varchar(255)
,`Massnahme-Bemerkungen` longtext
,`Massnahme-Plan` tinyint(1)
,`Massnahme-Planbezeichnung` varchar(255)
,`Massnahme-Fläche` int(10)
,`Massnahme-Markierung` varchar(255)
,`Massnahme - Ansiedlung Anzahl Triebe` int(10)
,`Massnahme - Ansiedlung Anzahl Pflanzen` int(10)
,`Massnahme - Ansiedlung Anzahl Pflanzstellen` int(10)
,`Massnahme - Ansiedlung Wirtspflanzen` varchar(255)
,`Massnahme - Ansiedlung Herkunftspopulation` varchar(255)
,`Massnahme - Ansiedlung Sammeldatum` varchar(50)
,`Massnahme - Ansiedlung Form` varchar(255)
,`Massnahme - Ansiedlung Pflanzordnung` varchar(255)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vAuswFlurnameArtKontrolle`
--
CREATE TABLE IF NOT EXISTS `vAuswFlurnameArtKontrolle` (
`ApArtId` int(10)
,`PopId` int(10)
,`TPopId` int(10)
,`TPopKontrId` int(10)
,`Gemeinde` varchar(255)
,`Flurname aus Teilpopulation` varchar(255)
,`Bearbeitungsstand AP` varchar(50)
,`Art` varchar(100)
,`PopNr` int(10)
,`TPopNr` int(10)
,`Jahr` smallint(5)
,`Kontrolltyp` varchar(50)
,`TPopKontrDatum` date
,`TPopKontrBearb` varchar(255)
,`TPopKontrZaehleinheit1` varchar(50)
,`TPopKontrMethode1` varchar(50)
,`TPopKontrAnz1` int(10)
,`TPopKontrZaehleinheit2` varchar(50)
,`TPopKontrMethode2` varchar(50)
,`TPopKontrAnz2` int(10)
,`TPopKontrZaehleinheit3` varchar(50)
,`TPopKontrMethode3` varchar(50)
,`TPopKontrAnz3` int(10)
,`TPopKontrJungpfl` int(10)
,`TPopKontrVitalitaet` varchar(255)
,`TPopKontrUeberleb` smallint(5)
,`TPopKontrEntwicklung` int(10)
,`TPopKontrUrsach` varchar(255)
,`TPopKontrUrteil` varchar(255)
,`TPopKontrAendUms` varchar(255)
,`TPopKontrAendKontr` varchar(255)
,`TPopKontrTxt` longtext
,`TPopKontrLeb` varchar(255)
,`TPopKontrFlaeche` int(10)
,`TPopKontrLebUmg` varchar(255)
,`TPopKontrStrauchschicht` varchar(255)
,`TPopKontrBodenTyp` varchar(255)
,`TPopKontrBodenAbtrag` varchar(255)
,`TPopKontrWasserhaushalt` varchar(255)
,`TPopKontrHandlungsbedarf` longtext
,`TPopKontrUebFlaeche` int(10)
,`TPopKontrPlan` tinyint(1)
,`TPopKontrVeg` smallint(5)
,`TPopKontrNaBo` smallint(5)
,`TPopKontrUebPfl` smallint(5)
,`TPopKontrJungPflJN` tinyint(1)
,`TPopKontrVegHoeMax` smallint(5)
,`TPopKontrVegHoeMit` smallint(5)
,`TPopKontrGefaehrdung` varchar(255)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vAuswPopBerAngezArtBestJahr0`
--
CREATE TABLE IF NOT EXISTS `vAuswPopBerAngezArtBestJahr0` (
`ApArtId` int(10)
,`PopId` int(10)
,`PopBerId` int(10)
,`Artname` varchar(100)
,`PopNr` int(10)
,`PopName` varchar(150)
,`PopHerkunft` varchar(50)
,`PopBerJahr` smallint(5)
,`PopBerEntwicklung` varchar(50)
,`PopBerTxt` longtext
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vBeob`
--
CREATE TABLE IF NOT EXISTS `vBeob` (
`NO_NOTE` varbinary(11)
,`ID_EVAB` varchar(255)
,`NO_ISFS` int(11)
,`Artname` varchar(100)
,`PopGuid` varchar(40)
,`PopNr` int(11)
,`TPopGuid` varchar(40)
,`TPopNr` int(11)
,`PROJET` varchar(255)
,`NOM_COMMUNE` varchar(255)
,`DESC_LOCALITE` varchar(255)
,`X` longblob
,`Y` longblob
,`Distanz zur Teilpopulation (m)` double(17,0)
,`Datum` varchar(10)
,`Autor` varchar(255)
,`BeobNichtZuordnen` tinyint(4)
,`BeobBemerkungen` longtext
,`BeobMutWann` date
,`BeobMutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vBeobZuordnungInfospeziesArtAnzMut`
--
CREATE TABLE IF NOT EXISTS `vBeobZuordnungInfospeziesArtAnzMut` (
`Art` varchar(100)
,`BeobMutWer` varchar(20)
,`BeobMutWann` date
,`AnzMut` bigint(21)
,`Tabelle` varchar(28)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vBer`
--
CREATE TABLE IF NOT EXISTS `vBer` (
`AP Id` int(10)
,`AP Art` varchar(100)
,`AP Bearbeitungsstand` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`AP verantwortlich` varchar(255)
,`Ber Id` int(10)
,`Ber ApId` int(10)
,`Ber Autor` varchar(150)
,`Ber Jahr` smallint(5)
,`Ber Titel` varchar(255)
,`Ber URL` varchar(255)
,`Ber MutWann` date
,`Ber MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vBerJb`
--
CREATE TABLE IF NOT EXISTS `vBerJb` (
`ApArtId` int(10)
,`ApStatus` int(10)
,`ApJahr` smallint(5)
,`ApUmsetzung` int(10)
,`ApBearb` int(10)
,`ApGuid` varchar(38)
,`ApArtwert` int(11)
,`MutWann` date
,`MutWer` varchar(20)
,`Art` varchar(100)
,`JBerId` int(10)
,`JBerJahr` smallint(5)
,`JBerSituation` longtext
,`JBerVergleichVorjahrGesamtziel` longtext
,`JBerBeurteilung` int(10)
,`JBerAnalyse` varchar(255)
,`JBerUmsetzung` longtext
,`JBerErfko` longtext
,`JBerATxt` longtext
,`JBerBTxt` longtext
,`JBerCTxt` longtext
,`JBerDTxt` longtext
,`JBerDatum` date
,`JBerBearb` int(10)
,`Bearbeiter` bigint(21) unsigned
,`JbuJahr` smallint(5)
,`JbuBemerkungen` longtext
,`ErsteMassnahmeImJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vBerJbArtD`
--
CREATE TABLE IF NOT EXISTS `vBerJbArtD` (
`ApArtId` int(10)
,`ApStatus` int(10)
,`ApJahr` smallint(5)
,`ApUmsetzung` int(10)
,`ApBearb` int(10)
,`ApGuid` varchar(38)
,`ApArtwert` int(11)
,`MutWann` date
,`MutWer` varchar(20)
,`Art` varchar(100)
,`JBerId` int(10)
,`JBerJahr` smallint(5)
,`JBerSituation` longtext
,`JBerVergleichVorjahrGesamtziel` longtext
,`JBerBeurteilung` int(10)
,`JBerAnalyse` varchar(255)
,`JBerUmsetzung` longtext
,`JBerErfko` longtext
,`JBerATxt` longtext
,`JBerBTxt` longtext
,`JBerCTxt` longtext
,`JBerDTxt` longtext
,`JBerDatum` date
,`JBerBearb` int(10)
,`Bearbeiter` varchar(255)
,`BeurteilTxt` varchar(50)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vBerJbZiel`
--
CREATE TABLE IF NOT EXISTS `vBerJbZiel` (
`ZielId` int(10)
,`ApArtId` int(10)
,`ZielTyp` int(10)
,`ZielJahr` smallint(5)
,`ZielBezeichnung` longtext
,`MutWann` date
,`MutWer` varchar(20)
,`ZieltypTxt` varchar(50)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vBerJbZielBer`
--
CREATE TABLE IF NOT EXISTS `vBerJbZielBer` (
`ZielBerId` int(10)
,`ZielId` int(10)
,`ZielBerJahr` smallint(5)
,`ZielBerErreichung` varchar(255)
,`ZielBerTxt` varchar(255)
,`MutWann` date
,`MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vBerOhneAp`
--
CREATE TABLE IF NOT EXISTS `vBerOhneAp` (
`AP Id` int(10)
,`Ber Id` int(10)
,`Ber ApId` int(10)
,`Ber Autor` varchar(150)
,`Ber Jahr` smallint(5)
,`Ber Titel` varchar(255)
,`Ber URL` varchar(255)
,`Ber MutWann` date
,`Ber MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vBerTPopFuerAngezeigteArt0`
--
CREATE TABLE IF NOT EXISTS `vBerTPopFuerAngezeigteArt0` (
`ApArtId` int(10)
,`PopId` int(10)
,`TPopId` int(10)
,`Artname` varchar(100)
,`ApStatus` varchar(50)
,`ApJahr` smallint(5)
,`ApUmsetzung` varchar(50)
,`PopNr` int(10)
,`PopName` varchar(150)
,`PopHerkunft` varchar(50)
,`PopBekanntSeit` smallint(5)
,`TPopNr` int(10)
,`TPopGemeinde` varchar(255)
,`TPopFlurname` varchar(255)
,`TPopXKoord` int(10)
,`TPopYKoord` int(10)
,`TPopBekanntSeit` smallint(5)
,`TPopHerkunft` varchar(50)
,`TPopApBerichtRelevant` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vErfKrit`
--
CREATE TABLE IF NOT EXISTS `vErfKrit` (
`AP Id` int(10)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`AP verantwortlich` varchar(255)
,`ErfKrit Id` int(10)
,`ErfKrit ApId` int(10)
,`ErfKrit Beurteilung` varchar(50)
,`ErfKrit Kriterien` varchar(255)
,`ErfKrit MutWann` date
,`ErfKrit MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vErfKritOhneAp`
--
CREATE TABLE IF NOT EXISTS `vErfKritOhneAp` (
`AP Id` int(10)
,`ErfKrit Id` int(10)
,`ErfKrit ApId` int(10)
,`ErfKrit Beurteilung` varchar(50)
,`ErfKrit Kriterien` varchar(255)
,`ErfKrit MutWann` date
,`ErfKrit MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vErsteMassnahmeProArt`
--
CREATE TABLE IF NOT EXISTS `vErsteMassnahmeProArt` (
`ApArtId` int(10)
,`MinvonTPopMassnJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vExportNachEvab_Alle`
--
CREATE TABLE IF NOT EXISTS `vExportNachEvab_Alle` (
`Projekt_Id` varchar(36)
,`Projekt_Name` varchar(113)
,`Projekt_Eröffnung` varchar(12)
,`Projekt_Autor` varchar(5)
,`Projekt_Bemerkungen` varchar(155)
,`Raum_Id` varchar(40)
,`Raum_Name` varchar(168)
,`Raum_Bemerkungen` varchar(80)
,`Ort_Id` varchar(40)
,`Ort_Name` varchar(273)
,`Ort_ObergrenzeHöhe` smallint(5)
,`Ort_X` int(10)
,`Ort_Y` int(10)
,`Ort_Genauigkeit` varchar(5)
,`Ort_Gemeinde` varchar(255)
,`Ort_Flurname` varchar(255)
,`Ort_Exposition` varchar(50)
,`Ort_Hangneigung` varchar(50)
,`Ort_Lebensraum` varchar(255)
,`Ort_UmgebungDelarze` varchar(255)
,`Zeit_Id` varchar(40)
,`Zeit_Datum` varchar(22)
,`Zeit_GenauigkeitDatum` varchar(4)
,`Zeit_DeckungMoose` varchar(100)
,`Zeit_DeckungKräuter` varchar(100)
,`Zeit_DeckungSträucher` varchar(255)
,`Zeit_DeckungBäume` varchar(100)
,`Beob_Id` varchar(40)
,`Beob_BeobachterinName` varchar(255)
,`Beob_NR` int(10)
,`Beob_WissenschArtname` varchar(100)
,`Beob_DeutscherArtname` varchar(100)
,`Beob_TypDerMeldung` varchar(15)
,`Beob_Anzahl1` int(10)
,`Beob_Einheit1` varchar(50)
,`Beob_Genauigkeit1` varchar(50)
,`Beob_Anzahl2` int(10)
,`Beob_Einheit2` varchar(50)
,`Beob_Genauigkeit2` varchar(50)
,`Beob_Anzahl3` int(10)
,`Beob_Einheit3` varchar(50)
,`Beob_Genauigkeit3` varchar(50)
,`Beob_Herkunft` text
,`Beob_Vorhandensein` text
,`Beob_Gefährdung` varchar(255)
,`Beob_VitalitätPflanze` varchar(255)
,`Beob_BeschreibungStandort` varchar(255)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vExportNachEvab_Beob`
--
CREATE TABLE IF NOT EXISTS `vExportNachEvab_Beob` (
`Projekt_Id` varchar(36)
,`Raum_Id` varchar(40)
,`Ort_Id` varchar(40)
,`Zeit_Id` varchar(40)
,`Beob_Id` varchar(40)
,`Beob_BeobachterinName` varchar(255)
,`Beob_NR` int(10)
,`Beob_WissenschArtname` varchar(100)
,`Beob_DeutscherArtname` varchar(100)
,`Beob_TypDerMeldung` varchar(15)
,`Beob_Anzahl1` int(10)
,`Beob_Einheit1` varchar(50)
,`Beob_Genauigkeit1` varchar(50)
,`Beob_Anzahl2` int(10)
,`Beob_Einheit2` varchar(50)
,`Beob_Genauigkeit2` varchar(50)
,`Beob_Anzahl3` int(10)
,`Beob_Einheit3` varchar(50)
,`Beob_Genauigkeit3` varchar(50)
,`Beob_Herkunft` text
,`Beob_Vorhandensein` text
,`Beob_Gefährdung` varchar(255)
,`Beob_VitalitätPflanze` varchar(255)
,`Beob_BeschreibungStandort` varchar(255)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vExportNachEvab_Ort`
--
CREATE TABLE IF NOT EXISTS `vExportNachEvab_Ort` (
`Projekt_Id` varchar(36)
,`Raum_Id` varchar(40)
,`Ort_Id` varchar(40)
,`Ort_Name` varchar(273)
,`Ort_ObergrenzeHöhe` smallint(5)
,`Ort_X` int(10)
,`Ort_Y` int(10)
,`Ort_Genauigkeit` varchar(5)
,`Ort_Gemeinde` varchar(255)
,`Ort_Flurname` varchar(255)
,`Ort_Exposition` varchar(50)
,`Ort_Hangneigung` varchar(50)
,`Ort_Lebensraum` varchar(255)
,`Ort_UmgebungDelarze` varchar(255)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vExportNachEvab_Projekt`
--
CREATE TABLE IF NOT EXISTS `vExportNachEvab_Projekt` (
`Projekt_Id` varchar(36)
,`Projekt_Name` varchar(113)
,`Projekt_Eröffnung` varchar(12)
,`Projekt_Autor` varchar(5)
,`Projekt_Bemerkungen` varchar(155)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vExportNachEvab_Raum`
--
CREATE TABLE IF NOT EXISTS `vExportNachEvab_Raum` (
`Projekt_Id` varchar(36)
,`Raum_Id` varchar(40)
,`Raum_Name` varchar(168)
,`Raum_Bemerkungen` varchar(80)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vExportNachEvab_Zeit`
--
CREATE TABLE IF NOT EXISTS `vExportNachEvab_Zeit` (
`Projekt_Id` varchar(36)
,`Raum_Id` varchar(40)
,`Ort_Id` varchar(40)
,`Zeit_Id` varchar(40)
,`Zeit_Datum` varchar(23)
,`Zeit_GenauigkeitDatum` varchar(4)
,`Zeit_DeckungMoose` varchar(100)
,`Zeit_DeckungKräuter` varchar(100)
,`Zeit_DeckungSträucher` varchar(255)
,`Zeit_DeckungBäume` varchar(100)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vFnsKef`
--
CREATE TABLE IF NOT EXISTS `vFnsKef` (
`TaxonomieId` int(7)
,`FnsKefArt2` varchar(2)
,`FnsKefKontrJahr2` varchar(2)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA1lPop`
--
CREATE TABLE IF NOT EXISTS `vJbA1lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA1lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbA1lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA1rPop`
--
CREATE TABLE IF NOT EXISTS `vJbA1rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA1rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbA1rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA2lPop`
--
CREATE TABLE IF NOT EXISTS `vJbA2lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA2lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbA2lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA2rPop`
--
CREATE TABLE IF NOT EXISTS `vJbA2rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA2rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbA2rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA3lPop`
--
CREATE TABLE IF NOT EXISTS `vJbA3lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA3lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbA3lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA3rPop`
--
CREATE TABLE IF NOT EXISTS `vJbA3rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA3rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbA3rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA4lPop`
--
CREATE TABLE IF NOT EXISTS `vJbA4lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA4lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbA4lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA5lPop`
--
CREATE TABLE IF NOT EXISTS `vJbA5lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA5lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbA5lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA6lPop`
--
CREATE TABLE IF NOT EXISTS `vJbA6lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA6lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbA6lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA7lPop`
--
CREATE TABLE IF NOT EXISTS `vJbA7lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA7lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbA7lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA8lPop`
--
CREATE TABLE IF NOT EXISTS `vJbA8lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA8lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbA8lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA9lPop`
--
CREATE TABLE IF NOT EXISTS `vJbA9lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbA9lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbA9lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB1lPop`
--
CREATE TABLE IF NOT EXISTS `vJbB1lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB1lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB1lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB1rPop`
--
CREATE TABLE IF NOT EXISTS `vJbB1rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB1rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB1rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB2lPop`
--
CREATE TABLE IF NOT EXISTS `vJbB2lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB2lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB2lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB2rPop`
--
CREATE TABLE IF NOT EXISTS `vJbB2rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB2rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB2rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB3lPop`
--
CREATE TABLE IF NOT EXISTS `vJbB3lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB3lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB3lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB3rPop`
--
CREATE TABLE IF NOT EXISTS `vJbB3rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB3rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB3rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB4lPop`
--
CREATE TABLE IF NOT EXISTS `vJbB4lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB4lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB4lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB4rPop`
--
CREATE TABLE IF NOT EXISTS `vJbB4rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB4rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB4rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB5lPop`
--
CREATE TABLE IF NOT EXISTS `vJbB5lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB5lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB5lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB5rPop`
--
CREATE TABLE IF NOT EXISTS `vJbB5rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB5rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB5rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB6lPop`
--
CREATE TABLE IF NOT EXISTS `vJbB6lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB6lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB6lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB6rPop`
--
CREATE TABLE IF NOT EXISTS `vJbB6rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB6rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB6rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB7lPop`
--
CREATE TABLE IF NOT EXISTS `vJbB7lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbB7lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbB7lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC1lPop`
--
CREATE TABLE IF NOT EXISTS `vJbC1lPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC1lTPop`
--
CREATE TABLE IF NOT EXISTS `vJbC1lTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC1rPop`
--
CREATE TABLE IF NOT EXISTS `vJbC1rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC1rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbC1rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC3rPop`
--
CREATE TABLE IF NOT EXISTS `vJbC3rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC3rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbC3rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC4rPop`
--
CREATE TABLE IF NOT EXISTS `vJbC4rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC4rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbC4rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC5rPop`
--
CREATE TABLE IF NOT EXISTS `vJbC5rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC5rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbC5rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC6rPop`
--
CREATE TABLE IF NOT EXISTS `vJbC6rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC6rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbC6rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC7rPop`
--
CREATE TABLE IF NOT EXISTS `vJbC7rPop` (
`ApArtId` int(10)
,`PopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbC7rTPop`
--
CREATE TABLE IF NOT EXISTS `vJbC7rTPop` (
`ApArtId` int(10)
,`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJBerOhneAp`
--
CREATE TABLE IF NOT EXISTS `vJBerOhneAp` (
`JBer Id` int(10)
,`JBer ApArtId` int(10)
,`JBer Jahr` smallint(5)
,`JBer Situation` longtext
,`JBer Vergleich Vorjahr-Gesamtziel` longtext
,`JBer Beurteilung` varchar(50)
,`JBer Veraend zum Vorjahr` varchar(2)
,`JBer Analyse` varchar(255)
,`JBer Konsequenzen Umsetzung` longtext
,`JBer Konsequenzen Erfolgskontrolle` longtext
,`JBer Bemerkungen zu A` longtext
,`JBer Bemerkungen zu B` longtext
,`JBer Bemerkungen zu C` longtext
,`JBer Bemerkungen zu D` longtext
,`JBer Datum` date
,`JBer BearbeiterIn` varchar(255)
,`JBer MutWann` date
,`JBer MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUebE`
--
CREATE TABLE IF NOT EXISTS `vJbUebE` (
`JBerId` int(10)
,`ApArtId` int(10)
,`JBerJahr` smallint(5)
,`JBerSituation` longtext
,`JBerVergleichVorjahrGesamtziel` longtext
,`JBerBeurteilung` int(10)
,`JBerVeraenGegenVorjahr` varchar(2)
,`JBerAnalyse` varchar(255)
,`JBerUmsetzung` longtext
,`JBerErfko` longtext
,`JBerATxt` longtext
,`JBerBTxt` longtext
,`JBerCTxt` longtext
,`JBerDTxt` longtext
,`JBerDatum` date
,`JBerBearb` int(10)
,`MutWann` date
,`MutWer` varchar(20)
,`Artname` varchar(100)
,`FnsKefArt2` varchar(2)
,`KefKontrolljahr` smallint(5)
,`FnsKefKontrJahr2` varchar(2)
,`FnsJahrespflanze` smallint(5)
,`FnsJahrespflanze2` varchar(2)
,`AnzahlMassnahmen` decimal(41,0)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUebKm`
--
CREATE TABLE IF NOT EXISTS `vJbUebKm` (
`Artname` varchar(100)
,`FnsKefArt2` varchar(2)
,`FnsKefKontrJahr2` varchar(2)
,`FnsJahrespflanze` smallint(5)
,`FnsJahrespflanze2` varchar(2)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUebMa`
--
CREATE TABLE IF NOT EXISTS `vJbUebMa` (
`Artname` varchar(100)
,`AnzahlMassnahmen` decimal(41,0)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUebMe`
--
CREATE TABLE IF NOT EXISTS `vJbUebMe` (
`JBerId` int(10)
,`ApArtId` int(10)
,`JBerJahr` smallint(5)
,`JBerSituation` longtext
,`JBerVergleichVorjahrGesamtziel` longtext
,`JBerBeurteilung` int(10)
,`JBerVeraenGegenVorjahr` varchar(2)
,`JBerAnalyse` varchar(255)
,`JBerUmsetzung` longtext
,`JBerErfko` longtext
,`JBerATxt` longtext
,`JBerBTxt` longtext
,`JBerCTxt` longtext
,`JBerDTxt` longtext
,`JBerDatum` date
,`JBerBearb` int(10)
,`MutWann` date
,`MutWer` varchar(20)
,`Artname` varchar(100)
,`FnsKefArt2` varchar(2)
,`FnsKefKontrJahr2` varchar(2)
,`FnsJahrespflanze` smallint(5)
,`FnsJahrespflanze2` varchar(2)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUebNe`
--
CREATE TABLE IF NOT EXISTS `vJbUebNe` (
`JBerId` int(10)
,`ApArtId` int(10)
,`JBerJahr` smallint(5)
,`JBerSituation` longtext
,`JBerVergleichVorjahrGesamtziel` longtext
,`JBerBeurteilung` int(10)
,`JBerVeraenGegenVorjahr` varchar(2)
,`JBerAnalyse` varchar(255)
,`JBerUmsetzung` longtext
,`JBerErfko` longtext
,`JBerATxt` longtext
,`JBerBTxt` longtext
,`JBerCTxt` longtext
,`JBerDTxt` longtext
,`JBerDatum` date
,`JBerBearb` int(10)
,`MutWann` date
,`MutWer` varchar(20)
,`Artname` varchar(100)
,`FnsKefArt2` varchar(2)
,`FnsKefKontrJahr2` varchar(2)
,`FnsJahrespflanze` smallint(5)
,`FnsJahrespflanze2` varchar(2)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUebNichtBeurteilt`
--
CREATE TABLE IF NOT EXISTS `vJbUebNichtBeurteilt` (
`ApArtId` int(10)
,`Artname` varchar(100)
,`FnsKefArt2` varchar(2)
,`FnsKefKontrJahr2` varchar(2)
,`FnsJahrespflanze` smallint(5)
,`FnsJahrespflanze2` varchar(2)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUebNichtBeurteilt0`
--
CREATE TABLE IF NOT EXISTS `vJbUebNichtBeurteilt0` (
`ApArtId` int(11)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUebNichtBeurteilt00`
--
CREATE TABLE IF NOT EXISTS `vJbUebNichtBeurteilt00` (
`ApArtId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUebNichtBeurteilt000`
--
CREATE TABLE IF NOT EXISTS `vJbUebNichtBeurteilt000` (
`ApArtId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUebSe`
--
CREATE TABLE IF NOT EXISTS `vJbUebSe` (
`JBerId` int(10)
,`ApArtId` int(10)
,`JBerJahr` smallint(5)
,`JBerSituation` longtext
,`JBerVergleichVorjahrGesamtziel` longtext
,`JBerBeurteilung` int(10)
,`JBerVeraenGegenVorjahr` varchar(2)
,`JBerAnalyse` varchar(255)
,`JBerUmsetzung` longtext
,`JBerErfko` longtext
,`JBerATxt` longtext
,`JBerBTxt` longtext
,`JBerCTxt` longtext
,`JBerDTxt` longtext
,`JBerDatum` date
,`JBerBearb` int(10)
,`MutWann` date
,`MutWer` varchar(20)
,`Artname` varchar(100)
,`FnsKefArt2` varchar(2)
,`FnsKefKontrJahr2` varchar(2)
,`FnsJahrespflanze` smallint(5)
,`FnsJahrespflanze2` varchar(2)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUebUn`
--
CREATE TABLE IF NOT EXISTS `vJbUebUn` (
`JBerId` int(10)
,`ApArtId` int(10)
,`JBerJahr` smallint(5)
,`JBerSituation` longtext
,`JBerVergleichVorjahrGesamtziel` longtext
,`JBerBeurteilung` int(10)
,`JBerVeraenGegenVorjahr` varchar(2)
,`JBerAnalyse` varchar(255)
,`JBerUmsetzung` longtext
,`JBerErfko` longtext
,`JBerATxt` longtext
,`JBerBTxt` longtext
,`JBerCTxt` longtext
,`JBerDTxt` longtext
,`JBerDatum` date
,`JBerBearb` int(10)
,`MutWann` date
,`MutWer` varchar(20)
,`Artname` varchar(100)
,`FnsKefArt2` varchar(2)
,`FnsKefKontrJahr2` varchar(2)
,`FnsJahrespflanze` smallint(5)
,`FnsJahrespflanze2` varchar(2)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUebWe`
--
CREATE TABLE IF NOT EXISTS `vJbUebWe` (
`JBerId` int(10)
,`ApArtId` int(10)
,`JBerJahr` smallint(5)
,`JBerSituation` longtext
,`JBerVergleichVorjahrGesamtziel` longtext
,`JBerBeurteilung` int(10)
,`JBerVeraenGegenVorjahr` varchar(2)
,`JBerAnalyse` varchar(255)
,`JBerUmsetzung` longtext
,`JBerErfko` longtext
,`JBerATxt` longtext
,`JBerBTxt` longtext
,`JBerCTxt` longtext
,`JBerDTxt` longtext
,`JBerDatum` date
,`JBerBearb` int(10)
,`MutWann` date
,`MutWer` varchar(20)
,`Artname` varchar(100)
,`FnsKefArt2` varchar(2)
,`FnsKefKontrJahr2` varchar(2)
,`FnsJahrespflanze` smallint(5)
,`FnsJahrespflanze2` varchar(2)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vJbUeT01`
--
CREATE TABLE IF NOT EXISTS `vJbUeT01` (
`ApArtId` int(10)
,`Artname` varchar(100)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vKontr`
--
CREATE TABLE IF NOT EXISTS `vKontr` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`AP verantwortlich` varchar(255)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Herkunft` varchar(50)
,`Pop bekannt seit` smallint(5)
,`TPopId` int(10)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius m` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop verantwortlich` varchar(255)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`Kontr Guid` varchar(40)
,`Kontr Jahr` smallint(5)
,`Kontr Datum` date
,`Kontr Typ` varchar(50)
,`Kontr BearbeiterIn` varchar(255)
,`Kontr Zaehleinheit 1` varchar(50)
,`Kontr Methode 1` varchar(50)
,`Kontr Anzahl 1` int(10)
,`Kontr Zaehleinheit 2` varchar(50)
,`Kontr Methode 2` varchar(50)
,`Kontr Anzahl 2` int(10)
,`Kontr Zaehleinheit 3` varchar(50)
,`Kontr Methode 3` varchar(50)
,`Kontr Anzahl 3` int(10)
,`Kontr Ueberlebensrate` smallint(5)
,`Kontr Vitalitaet` varchar(255)
,`Kontr Entwicklung` varchar(50)
,`Kontr Ursachen` varchar(255)
,`Kontr Erfolgsbeurteilung` varchar(255)
,`Kontr Aend-Vorschlaege Umsetzung` varchar(255)
,`Kontr Aend-Vorschlaege Kontrolle` varchar(255)
,`Kontr X-Koord` int(10)
,`Kontr Y-Koord` int(10)
,`Kontr Bemerkungen` longtext
,`Kontr Lebensraum Delarze` varchar(255)
,`Kontr angrenzender Lebensraum Delarze` varchar(255)
,`Kontr Vegetationstyp` varchar(100)
,`Kontr Konkurrenz` varchar(100)
,`Kontr Moosschicht` varchar(100)
,`Kontr Krautschicht` varchar(100)
,`Kontr Strauchschicht` varchar(255)
,`Kontr Baumschicht` varchar(100)
,`Kontr Bodentyp` varchar(255)
,`Kontr Boden Kalkgehalt` varchar(100)
,`Kontr Boden Durchlaessigkeit` varchar(100)
,`Kontr Boden Hmusgehalt` varchar(100)
,`Kontr Boden Naehrstoffgehalt` varchar(100)
,`Kontr Oberbodenabtrag` varchar(255)
,`Kontr Wasserhaushalt` varchar(255)
,`TPopKontrIdealBiotopUebereinst` varchar(50)
,`TPopKontrHandlungsbedarf` longtext
,`TPopKontrUebFlaeche` int(10)
,`Kontr Flaeche m2` int(10)
,`Kontr auf Plan eingezeichnet` tinyint(1)
,`Kontr Deckung durch Vegetation` smallint(5)
,`Kontr Deckung nackter Boden` smallint(5)
,`Kontr Deckung durch ueberpruefte Art` smallint(5)
,`Kontr auch junge Pflanzen` tinyint(1)
,`Kontr maximale Veg-hoehe cm` smallint(5)
,`Kontr mittlere Veg-hoehe cm` smallint(5)
,`Kontr Gefaehrdung` varchar(255)
,`MutWann` date
,`MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vKontrAnzProZaehleinheit`
--
CREATE TABLE IF NOT EXISTS `vKontrAnzProZaehleinheit` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`AP verantwortlich` varchar(255)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Herkunft` varchar(50)
,`Pop bekannt seit` smallint(5)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius m` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop verantwortlich` varchar(255)
,`TPop Herkunft` varchar(50)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`Kontr Guid` varchar(40)
,`Kontr Jahr` smallint(5)
,`Kontr Datum` date
,`Kontr Typ` varchar(50)
,`Kontr BearbeiterIn` varchar(255)
,`Kontr Zaehleinheit` varchar(50)
,`Kontr Anzahl` bigint(21)
,`Kontr Ueberlebensrate` smallint(5)
,`Kontr Vitalitaet` varchar(255)
,`Kontr Entwicklung` varchar(50)
,`Kontr Ursachen` varchar(255)
,`Kontr Erfolgsbeurteilung` varchar(255)
,`Kontr Aend-Vorschlaege Umsetzung` varchar(255)
,`Kontr Aend-Vorschlaege Kontrolle` varchar(255)
,`Kontr X-Koord` int(10)
,`Kontr Y-Koord` int(10)
,`Kontr Bemerkungen` longtext
,`Kontr Lebensraum Delarze` varchar(255)
,`Kontr angrenzender Lebensraum Delarze` varchar(255)
,`Kontr Vegetationstyp` varchar(100)
,`Kontr Konkurrenz` varchar(100)
,`Kontr Moosschicht` varchar(100)
,`Kontr Krautschicht` varchar(100)
,`Kontr Strauchschicht` varchar(255)
,`Kontr Baumschicht` varchar(100)
,`Kontr Bodentyp` varchar(255)
,`Kontr Boden Kalkgehalt` varchar(100)
,`Kontr Boden Durchlaessigkeit` varchar(100)
,`Kontr Boden Hmusgehalt` varchar(100)
,`Kontr Boden Naehrstoffgehalt` varchar(100)
,`Kontr Oberbodenabtrag` varchar(255)
,`Kontr Wasserhaushalt` varchar(255)
,`TPopKontrIdealBiotopUebereinst` varchar(50)
,`TPopKontrHandlungsbedarf` longtext
,`TPopKontrUebFlaeche` int(10)
,`Kontr Flaeche m2` int(10)
,`Kontr auf Plan eingezeichnet` tinyint(1)
,`Kontr Deckung durch Vegetation` smallint(5)
,`Kontr Deckung nackter Boden` smallint(5)
,`Kontr Deckung durch ueberpruefte Art` smallint(5)
,`Kontr auch junge Pflanzen` tinyint(1)
,`Kontr maximale Veg-hoehe cm` smallint(5)
,`Kontr mittlere Veg-hoehe cm` smallint(5)
,`Kontr Gefaehrdung` varchar(255)
,`MutWann` date
,`MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vKontrAnzProZaehleinheit0`
--
CREATE TABLE IF NOT EXISTS `vKontrAnzProZaehleinheit0` (
`TPopKontrId` int(11)
,`TPopKontrZaehleinheit` varchar(50)
,`TPopKontrAnz` bigint(21)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vKontrApArtTPopOhneStatus`
--
CREATE TABLE IF NOT EXISTS `vKontrApArtTPopOhneStatus` (
`Art` varchar(100)
,`Bearbeitungsstand AP` varchar(50)
,`PopNr` int(10)
,`PopName` varchar(150)
,`Status Population` varchar(50)
,`TPopNr` int(10)
,`TPopFlurname` varchar(255)
,`Status Teilpopulation` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vKontrFuerGis`
--
CREATE TABLE IF NOT EXISTS `vKontrFuerGis` (
`ApArtId` int(10)
,`Artname` varchar(100)
,`ApStatus` varchar(50)
,`ApJahr` smallint(5)
,`ApUmsetzung` varchar(50)
,`PopGuid` varchar(40)
,`PopNr` int(10)
,`PopName` varchar(150)
,`PopHerkunft` varchar(50)
,`PopBekanntSeit` smallint(5)
,`TPopGuid` varchar(40)
,`TPopNr` int(10)
,`TPopGemeinde` varchar(255)
,`TPopFlurname` varchar(255)
,`TPopXKoord` int(10)
,`TPopYKoord` int(10)
,`TPopBekanntSeit` smallint(5)
,`TPopKontrGuid` varchar(40)
,`TPopKontrJahr` smallint(5)
,`TPopKontrDatum` date
,`TPopKontrTyp` varchar(50)
,`TPopKontrBearb` varchar(255)
,`TPopKontrZaehleinheit1` varchar(50)
,`TPopKontrMethode1` varchar(50)
,`TPopKontrAnz1` int(10)
,`TPopKontrZaehleinheit2` varchar(50)
,`TPopKontrMethode2` varchar(50)
,`TPopKontrAnz2` int(10)
,`TPopKontrZaehleinheit3` varchar(50)
,`TPopKontrMethode3` varchar(50)
,`TPopKontrAnz3` int(10)
,`TPopKontrUeberleb` smallint(5)
,`TPopKontrVitalitaet` varchar(255)
,`TPopKontrEntwicklung` varchar(50)
,`TPopKontrUrsach` varchar(255)
,`TPopKontrUrteil` varchar(255)
,`TPopKontrAendUms` varchar(255)
,`TPopKontrAendKontr` varchar(255)
,`X` int(10)
,`Y` int(10)
,`TPopKontrLeb` varchar(255)
,`TPopKontrFlaeche` int(10)
,`TPopKontrLebUmg` varchar(255)
,`TPopKontrVegTyp` varchar(100)
,`TPopKontrKonkurrenz` varchar(100)
,`TPopKontrMoosschicht` varchar(100)
,`TPopKontrKrautschicht` varchar(100)
,`TPopKontrStrauchschicht` varchar(255)
,`TPopKontrBaumschicht` varchar(100)
,`TPopKontrBodenTyp` varchar(255)
,`TPopKontrBodenKalkgehalt` varchar(100)
,`TPopKontrBodenDurchlaessigkeit` varchar(100)
,`TPopKontrBodenHumus` varchar(100)
,`TPopKontrBodenNaehrstoffgehalt` varchar(100)
,`TPopKontrBodenAbtrag` varchar(255)
,`TPopKontrWasserhaushalt` varchar(255)
,`TPopKontrIdealBiotopUebereinst` varchar(50)
,`TPopKontrUebFlaeche` int(10)
,`TPopKontrPlan` tinyint(1)
,`TPopKontrVeg` smallint(5)
,`TPopKontrNaBo` smallint(5)
,`TPopKontrUebPfl` smallint(5)
,`TPopKontrJungPflJN` tinyint(1)
,`TPopKontrVegHoeMax` smallint(5)
,`TPopKontrVegHoeMit` smallint(5)
,`TPopKontrGefaehrdung` varchar(255)
,`MutWann` date
,`MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vKontrLetzte`
--
CREATE TABLE IF NOT EXISTS `vKontrLetzte` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`AP verantwortlich` varchar(255)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Herkunft` varchar(50)
,`Pop bekannt seit` smallint(5)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius m` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop verantwortlich` varchar(255)
,`TPop Herkunft` varchar(50)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`Kontr Guid` varchar(40)
,`Kontr Jahr` smallint(5)
,`Kontr Datum` date
,`Kontr Typ` varchar(50)
,`Kontr BearbeiterIn` varchar(255)
,`Kontr Zaehleinheit 1` varchar(50)
,`Kontr Methode 1` varchar(50)
,`Kontr Anzahl 1` int(10)
,`Kontr Zaehleinheit 2` varchar(50)
,`Kontr Methode 2` varchar(50)
,`Kontr Anzahl 2` int(10)
,`Kontr Zaehleinheit 3` varchar(50)
,`Kontr Methode 3` varchar(50)
,`Kontr Anzahl 3` int(10)
,`Kontr Ueberlebensrate` smallint(5)
,`Kontr Vitalitaet` varchar(255)
,`Kontr Entwicklung` varchar(50)
,`Kontr Ursachen` varchar(255)
,`Kontr Erfolgsbeurteilung` varchar(255)
,`Kontr Aend-Vorschlaege Umsetzung` varchar(255)
,`Kontr Aend-Vorschlaege Kontrolle` varchar(255)
,`Kontr X-Koord` int(10)
,`Kontr Y-Koord` int(10)
,`Kontr Bemerkungen` longtext
,`Kontr Lebensraum Delarze` varchar(255)
,`Kontr angrenzender Lebensraum Delarze` varchar(255)
,`Kontr Vegetationstyp` varchar(100)
,`Kontr Konkurrenz` varchar(100)
,`Kontr Moosschicht` varchar(100)
,`Kontr Krautschicht` varchar(100)
,`Kontr Strauchschicht` varchar(255)
,`Kontr Baumschicht` varchar(100)
,`Kontr Bodentyp` varchar(255)
,`Kontr Boden Kalkgehalt` varchar(100)
,`Kontr Boden Durchlaessigkeit` varchar(100)
,`Kontr Boden Hmusgehalt` varchar(100)
,`Kontr Boden Naehrstoffgehalt` varchar(100)
,`Kontr Oberbodenabtrag` varchar(255)
,`Kontr Wasserhaushalt` varchar(255)
,`TPopKontrIdealBiotopUebereinst` varchar(50)
,`TPopKontrHandlungsbedarf` longtext
,`TPopKontrUebFlaeche` int(10)
,`Kontr Flaeche m2` int(10)
,`Kontr auf Plan eingezeichnet` tinyint(1)
,`Kontr Deckung durch Vegetation` smallint(5)
,`Kontr Deckung nackter Boden` smallint(5)
,`Kontr Deckung durch ueberpruefte Art` smallint(5)
,`Kontr auch junge Pflanzen` tinyint(1)
,`Kontr maximale Veg-hoehe cm` smallint(5)
,`Kontr mittlere Veg-hoehe cm` smallint(5)
,`Kontr Gefaehrdung` varchar(255)
,`MutWann` date
,`MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vKontrLetzteId`
--
CREATE TABLE IF NOT EXISTS `vKontrLetzteId` (
`ApArtId` int(10)
,`Artname` varchar(100)
,`PopId` int(10)
,`PopNr` int(10)
,`TPopId` int(10)
,`TPopNr` int(10)
,`TPopKontrId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vKontrLetztesJahr`
--
CREATE TABLE IF NOT EXISTS `vKontrLetztesJahr` (
`ApArtId` int(10)
,`Artname` varchar(100)
,`PopId` int(10)
,`PopNr` int(10)
,`TPopId` int(10)
,`TPopNr` int(10)
,`MaxvonTPopKontrJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vKontrOhneTPop`
--
CREATE TABLE IF NOT EXISTS `vKontrOhneTPop` (
`Kontr Guid` varchar(40)
,`Kontr Jahr` smallint(5)
,`Kontr Datum` date
,`Kontr Typ` varchar(50)
,`Kontr BearbeiterIn` varchar(255)
,`Kontr Zaehleinheit 1` varchar(50)
,`Kontr Methode 1` varchar(50)
,`Kontr Anzahl 1` int(10)
,`Kontr Zaehleinheit 2` varchar(50)
,`Kontr Methode 2` varchar(50)
,`Kontr Anzahl 2` int(10)
,`Kontr Zaehleinheit 3` varchar(50)
,`Kontr Methode 3` varchar(50)
,`Kontr Anzahl 3` int(10)
,`Kontr Ueberlebensrate` smallint(5)
,`Kontr Vitalitaet` varchar(255)
,`Kontr Entwicklung` varchar(50)
,`Kontr Ursachen` varchar(255)
,`Kontr Erfolgsbeurteilung` varchar(255)
,`Kontr Aend-Vorschlaege Umsetzung` varchar(255)
,`Kontr Aend-Vorschlaege Kontrolle` varchar(255)
,`Kontr X-Koord` int(10)
,`Kontr Y-Koord` int(10)
,`Kontr Bemerkungen` longtext
,`Kontr Lebensraum Delarze` varchar(255)
,`Kontr angrenzender Lebensraum Delarze` varchar(255)
,`Kontr Vegetationstyp` varchar(100)
,`Kontr Konkurrenz` varchar(100)
,`Kontr Moosschicht` varchar(100)
,`Kontr Krautschicht` varchar(100)
,`Kontr Strauchschicht` varchar(255)
,`Kontr Baumschicht` varchar(100)
,`Kontr Bodentyp` varchar(255)
,`Kontr Boden Kalkgehalt` varchar(100)
,`Kontr Boden Durchlaessigkeit` varchar(100)
,`Kontr Boden Hmusgehalt` varchar(100)
,`Kontr Boden Naehrstoffgehalt` varchar(100)
,`Kontr Oberbodenabtrag` varchar(255)
,`Kontr Wasserhaushalt` varchar(255)
,`TPopKontrIdealBiotopUebereinst` varchar(50)
,`TPopKontrHandlungsbedarf` longtext
,`TPopKontrUebFlaeche` int(10)
,`Kontr Flaeche m2` int(10)
,`Kontr auf Plan eingezeichnet` tinyint(1)
,`Kontr Deckung durch Vegetation` smallint(5)
,`Kontr Deckung nackter Boden` smallint(5)
,`Kontr Deckung durch ueberpruefte Art` smallint(5)
,`Kontr auch junge Pflanzen` tinyint(1)
,`Kontr maximale Veg-hoehe cm` smallint(5)
,`Kontr mittlere Veg-hoehe cm` smallint(5)
,`Kontr Gefaehrdung` varchar(255)
,`MutWann` date
,`MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vKontrTPopKoorLeer`
--
CREATE TABLE IF NOT EXISTS `vKontrTPopKoorLeer` (
`Art` varchar(100)
,`ApStatus_` varchar(50)
,`PopNr` int(10)
,`PopName` varchar(150)
,`TPopNr` int(10)
,`TPopGemeinde` varchar(255)
,`TPopFlurname` varchar(255)
,`TPopXKoord` int(10)
,`TPopYKoord` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vKontrTPopStatusErloschen`
--
CREATE TABLE IF NOT EXISTS `vKontrTPopStatusErloschen` (
`Art` varchar(100)
,`Bearbeitungsstand AP` varchar(50)
,`PopNr` int(10)
,`PopName` varchar(150)
,`TPopNr` int(10)
,`TPopGemeinde` varchar(255)
,`TPopFlurname` varchar(255)
,`TPopHerkunft` int(10)
,`TPopBerEntwicklung` int(10)
,`TPopBerJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vLetzterPopBericht`
--
CREATE TABLE IF NOT EXISTS `vLetzterPopBericht` (
`ApArtId` int(10)
,`PopId` int(10)
,`MaxvonPopBerJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vLetzterPopBericht0`
--
CREATE TABLE IF NOT EXISTS `vLetzterPopBericht0` (
`ApArtId` int(10)
,`PopId` int(10)
,`PopBerJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vLetzterPopMassnBericht`
--
CREATE TABLE IF NOT EXISTS `vLetzterPopMassnBericht` (
`ApArtId` int(10)
,`PopId` int(10)
,`MaxvonPopMassnBerJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vLetzterPopMassnBericht0`
--
CREATE TABLE IF NOT EXISTS `vLetzterPopMassnBericht0` (
`ApArtId` int(10)
,`PopId` int(10)
,`PopMassnBerJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vLetzterTPopBericht`
--
CREATE TABLE IF NOT EXISTS `vLetzterTPopBericht` (
`ApArtId` int(10)
,`TPopId` int(10)
,`MaxvonTPopBerJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vLetzterTPopBericht0`
--
CREATE TABLE IF NOT EXISTS `vLetzterTPopBericht0` (
`ApArtId` int(10)
,`TPopId` int(10)
,`TPopBerJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vLetzterTPopMassnBericht`
--
CREATE TABLE IF NOT EXISTS `vLetzterTPopMassnBericht` (
`ApArtId` int(10)
,`TPopId` int(10)
,`MaxvonTPopMassnBerJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vLetzterTPopMassnBericht0`
--
CREATE TABLE IF NOT EXISTS `vLetzterTPopMassnBericht0` (
`ApArtId` int(10)
,`TPopId` int(10)
,`TPopMassnBerJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vMassn`
--
CREATE TABLE IF NOT EXISTS `vMassn` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`TPopId` int(10)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius (m)` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop Verantwortlich` varchar(255)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`Massn Guid` varchar(40)
,`Massn Jahr` smallint(5)
,`Massn Datum` date
,`Massn Typ` varchar(50)
,`Massn Massnahme` varchar(255)
,`Massn BearbeiterIn` varchar(255)
,`Massn Bemerkungen` longtext
,`Massn Plan vorhanden` tinyint(1)
,`Massn Plan Bezeichnung` varchar(255)
,`Massn Fläche m2` int(10)
,`Massn Form der Ansiedlung` varchar(255)
,`Massn Pflanzanordnung` varchar(255)
,`Massn Markierung` varchar(255)
,`Massn Anz Triebe` int(10)
,`Massn Pflanzen` int(10)
,`Massn Anz Pflanzstellen` int(10)
,`Massn Wirtspflanze` varchar(255)
,`Massn Herkunftspopulation` varchar(255)
,`Massn Sammeldatum` varchar(50)
,`Massn MutWann` date
,`Massn MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vMassnFuerGis`
--
CREATE TABLE IF NOT EXISTS `vMassnFuerGis` (
`ApArtId` int(7)
,`ApArt` varchar(100)
,`ApStatus` varchar(50)
,`ApStartImJahr` smallint(5)
,`ApStandUmsetzung` varchar(50)
,`PopGuid` varchar(40)
,`PopNr` int(10)
,`PopName` varchar(150)
,`PopStatus` varchar(50)
,`PopBekanntSeit` smallint(5)
,`PopXKoordinaten` int(10)
,`PopYKoordinaten` int(10)
,`TPopGuid` varchar(40)
,`TPopNr` int(10)
,`TPopGemeinde` varchar(255)
,`TPopFlurname` varchar(255)
,`TPopStatus` varchar(50)
,`TPopStatusUnklar` tinyint(1)
,`TPopBegründungFuerUnklarenStatus` varchar(255)
,`TPopXKoordinaten` int(10)
,`TPopYKoordinaten` int(10)
,`TPopRadius` smallint(5)
,`TPopHoehe` smallint(5)
,`TPopExposition` varchar(50)
,`TPopKlima` varchar(50)
,`TPopHangneigung` varchar(50)
,`TPopBeschreibung` varchar(255)
,`TPopKatasterNr` varchar(255)
,`TPopVerantwortlich` varchar(255)
,`TPopFuerApBerichtRelevant` int(10)
,`TPopBekanntSeit` smallint(5)
,`TPopEigentümerIn` varchar(255)
,`TPopKontaktVorOrt` varchar(255)
,`TPopNutzungszone` varchar(255)
,`TPopBewirtschafterIn` varchar(255)
,`TPopBewirtschaftung` varchar(255)
,`MassnGuid` varchar(40)
,`MassnJahr` smallint(5)
,`MassnDatum` date
,`MassnTyp` varchar(50)
,`MassnMassnahme` varchar(255)
,`MassnBearbeiterIn` varchar(255)
,`MassnPlanVorhanden` tinyint(1)
,`MassnPlanBezeichnung` varchar(255)
,`MassnFlaeche` int(10)
,`MassnFormDerAnsiedlung` varchar(255)
,`MassnPflanzanordnung` varchar(255)
,`MassnMarkierung` varchar(255)
,`MassnAnzTriebe` int(10)
,`MassnPflanzen` int(10)
,`MassnAnzPflanzstellen` int(10)
,`MassnWirtspflanze` varchar(255)
,`MassnHerkunftspopulation` varchar(255)
,`MassnSammeldatum` varchar(50)
,`MassnMutWann` date
,`MassnMutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vMassnJahre`
--
CREATE TABLE IF NOT EXISTS `vMassnJahre` (
`TPopMassnJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vMassnPolygon`
--
CREATE TABLE IF NOT EXISTS `vMassnPolygon` (
`ApArtId` int(7)
,`ApArt` varchar(100)
,`ApStatus` varchar(50)
,`ApStartImJahr` smallint(5)
,`ApStandUmsetzung` varchar(50)
,`PopGuid` varchar(40)
,`PopNr` int(10)
,`PopName` varchar(150)
,`PopStatus` varchar(50)
,`PopBekanntSeit` smallint(5)
,`PopXKoordinaten` int(10)
,`PopYKoordinaten` int(10)
,`TPopGuid` varchar(40)
,`TPopNr` int(10)
,`TPopGemeinde` varchar(255)
,`TPopFlurname` varchar(255)
,`TPopStatus` varchar(50)
,`TPopStatusUnklar` tinyint(1)
,`TPopBegründungFuerUnklarenStatus` varchar(255)
,`TPopXKoordinaten` int(10)
,`TPopYKoordinaten` int(10)
,`TpmPolyPolygon` polygon
,`TPopRadius` smallint(5)
,`TPopHoehe` smallint(5)
,`TPopExposition` varchar(50)
,`TPopKlima` varchar(50)
,`TPopHangneigung` varchar(50)
,`TPopBeschreibung` varchar(255)
,`TPopKatasterNr` varchar(255)
,`TPopVerantwortlich` varchar(255)
,`TPopFuerApBerichtRelevant` int(10)
,`TPopBekanntSeit` smallint(5)
,`TPopEigentümerIn` varchar(255)
,`TPopKontaktVorOrt` varchar(255)
,`TPopNutzungszone` varchar(255)
,`TPopBewirtschafterIn` varchar(255)
,`TPopBewirtschaftung` varchar(255)
,`MassnGuid` varchar(40)
,`MassnJahr` smallint(5)
,`MassnDatum` date
,`MassnTyp` varchar(50)
,`MassnMassnahme` varchar(255)
,`MassnBearbeiterIn` varchar(255)
,`MassnPlanVorhanden` tinyint(1)
,`MassnPlanBezeichnung` varchar(255)
,`MassnFlaeche` int(10)
,`MassnFormDerAnsiedlung` varchar(255)
,`MassnPflanzanordnung` varchar(255)
,`MassnMarkierung` varchar(255)
,`MassnAnzTriebe` int(10)
,`MassnPflanzen` int(10)
,`MassnAnzPflanzstellen` int(10)
,`MassnWirtspflanze` varchar(255)
,`MassnHerkunftspopulation` varchar(255)
,`MassnSammeldatum` varchar(50)
,`MassnMutWann` date
,`MassnMutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPop`
--
CREATE TABLE IF NOT EXISTS `vPop` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`PopId` int(10)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`Pop MutWann` date
,`Pop MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopAnzKontr`
--
CREATE TABLE IF NOT EXISTS `vPopAnzKontr` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`Anzahl Kontrollen` bigint(21)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopAnzMassn`
--
CREATE TABLE IF NOT EXISTS `vPopAnzMassn` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`Anzahl Massnahmen` bigint(21)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopBer`
--
CREATE TABLE IF NOT EXISTS `vPopBer` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`PopBer Id` int(10)
,`PopBer Jahr` smallint(5)
,`PopBer Entwicklung` varchar(50)
,`PopBer Bemerkungen` longtext
,`PopBer MutWann` date
,`PopBer MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopBerMassnJahre`
--
CREATE TABLE IF NOT EXISTS `vPopBerMassnJahre` (
`PopId` int(11)
,`Jahr` smallint(6)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopBerOhnePop`
--
CREATE TABLE IF NOT EXISTS `vPopBerOhnePop` (
`PopBer Id` int(10)
,`PopBer PopId` int(10)
,`PopBer Jahr` smallint(5)
,`PopBer Entwicklung` varchar(50)
,`PopBer Bemerkungen` longtext
,`PopBer MutWann` date
,`PopBer MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopFuerGis`
--
CREATE TABLE IF NOT EXISTS `vPopFuerGis` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`XKoordinaten` int(10)
,`YKoordinaten` int(10)
,`Pop MutWann` date
,`Pop MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopFuerKml`
--
CREATE TABLE IF NOT EXISTS `vPopFuerKml` (
`Art` varchar(100)
,`Label` int(10)
,`Inhalte` varchar(174)
,`Laengengrad` decimal(59,20)
,`Breitengrad` decimal(59,20)
,`URL` varchar(72)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopFuerKmlNamen`
--
CREATE TABLE IF NOT EXISTS `vPopFuerKmlNamen` (
`Art` varchar(100)
,`Label` varchar(112)
,`Inhalte` varchar(174)
,`Laengengrad` decimal(59,20)
,`Breitengrad` decimal(59,20)
,`URL` varchar(72)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopMassnBer`
--
CREATE TABLE IF NOT EXISTS `vPopMassnBer` (
`AP ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`Pop MutWann` date
,`Pop MutWer` varchar(20)
,`PopMassnBer Id` int(10)
,`PopMassnBer Jahr` smallint(5)
,`PopMassnBer Entwicklung` varchar(50)
,`PopMassnBer Interpretation` longtext
,`PopMassnBer MutWann` date
,`PopMassnBer MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopMassnberAnzMassn`
--
CREATE TABLE IF NOT EXISTS `vPopMassnberAnzMassn` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`MassnBer Jahr` smallint(5)
,`Anz Massnahmen in diesem Jahr` bigint(21)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopMassnberAnzMassn0`
--
CREATE TABLE IF NOT EXISTS `vPopMassnberAnzMassn0` (
`PopId` int(10)
,`PopMassnBerJahr` smallint(5)
,`AnzahlvonTPopMassnId` bigint(21)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopMassnBerOhnePop`
--
CREATE TABLE IF NOT EXISTS `vPopMassnBerOhnePop` (
`PopMassnBer Id` int(10)
,`PopMassnBer PopId` int(10)
,`PopMassnBer Jahr` smallint(5)
,`PopMassnBer Entwicklung` varchar(50)
,`PopMassnBer Interpretation` longtext
,`PopMassnBer MutWann` date
,`PopMassnBer MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopMassnSeitBeginnAp`
--
CREATE TABLE IF NOT EXISTS `vPopMassnSeitBeginnAp` (
`TPopId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopOhneAp`
--
CREATE TABLE IF NOT EXISTS `vPopOhneAp` (
`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`Pop MutWann` date
,`Pop MutWer` varchar(20)
,`ApArtId` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopOhneKoord`
--
CREATE TABLE IF NOT EXISTS `vPopOhneKoord` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`PopId` int(10)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`Pop MutWann` date
,`Pop MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopOhneTPop`
--
CREATE TABLE IF NOT EXISTS `vPopOhneTPop` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`Pop MutWann` date
,`Pop MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPopVonApOhneStatus`
--
CREATE TABLE IF NOT EXISTS `vPopVonApOhneStatus` (
`Art` varchar(100)
,`Bearbeitungsstand AP` int(10)
,`PopNr` int(10)
,`PopName` varchar(150)
,`Status` int(10)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPop_BerMassnJahreVonTPop`
--
CREATE TABLE IF NOT EXISTS `vPop_BerMassnJahreVonTPop` (
`PopId` int(10)
,`Jahr` smallint(6)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vPop_BerUndMassnBer`
--
CREATE TABLE IF NOT EXISTS `vPop_BerUndMassnBer` (
`AP ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`Pop MutWann` date
,`Pop MutWer` varchar(20)
,`Jahr` smallint(6)
,`PopBer Id` int(10)
,`PopBer Jahr` smallint(5)
,`PopBer Entwicklung` varchar(50)
,`PopBer Bemerkungen` longtext
,`PopBer MutWann` date
,`PopBer MutWer` varchar(20)
,`PopMassnBer Id` int(10)
,`PopMassnBer Jahr` smallint(5)
,`PopMassnBer Entwicklung` varchar(50)
,`PopMassnBer Interpretation` longtext
,`PopMassnBer MutWann` date
,`PopMassnBer MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vProgramme`
--
CREATE TABLE IF NOT EXISTS `vProgramme` (
`ApArtId` int(10)
,`AP Art` varchar(100)
,`AP Bearbeitungsstand` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`AP verantwortlich` varchar(255)
,`AP Letzte Änderung` date
,`AP Letzte(r) Bearbeiter(in)` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPop`
--
CREATE TABLE IF NOT EXISTS `vTPop` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`TPopId` int(10)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius (m)` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop Verantwortlich` varchar(255)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`MutWann` date
,`MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopAnzFeldkontr`
--
CREATE TABLE IF NOT EXISTS `vTPopAnzFeldkontr` (
`TPopId` int(10)
,`TPopGuid` varchar(40)
,`Anzahl Feld-Kontrollen` bigint(21)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopAnzFreiwkontr`
--
CREATE TABLE IF NOT EXISTS `vTPopAnzFreiwkontr` (
`TPopId` int(10)
,`TPopGuid` varchar(40)
,`Anzahl Freiwilligen-Kontrollen` bigint(21)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopAnzKontr`
--
CREATE TABLE IF NOT EXISTS `vTPopAnzKontr` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius (m)` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`Anzahl Kontrollen` bigint(21)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopAnzKontrInklLetzteKontr`
--
CREATE TABLE IF NOT EXISTS `vTPopAnzKontrInklLetzteKontr` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius (m)` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`Anzahl Kontrollen` bigint(21)
,`Anzahl Feld-Kontrollen` bigint(20)
,`Anzahl Freiwilligen-Kontrollen` bigint(20)
,`Kontr Guid` varchar(40)
,`Kontr Jahr` smallint(5)
,`Kontr Datum` date
,`Kontr Typ` varchar(50)
,`Kontr BearbeiterIn` varchar(255)
,`Kontr Zaehleinheit 1` varchar(50)
,`Kontr Methode 1` varchar(50)
,`Kontr Anzahl 1` int(10)
,`Kontr Zaehleinheit 2` varchar(50)
,`Kontr Methode 2` varchar(50)
,`Kontr Anzahl 2` int(10)
,`Kontr Zaehleinheit 3` varchar(50)
,`Kontr Methode 3` varchar(50)
,`Kontr Anzahl 3` int(10)
,`Kontr Ueberlebensrate` smallint(5)
,`Kontr Vitalitaet` varchar(255)
,`Kontr Entwicklung` varchar(50)
,`Kontr Ursachen` varchar(255)
,`Kontr Erfolgsbeurteilung` varchar(255)
,`Kontr Aend-Vorschlaege Umsetzung` varchar(255)
,`Kontr Aend-Vorschlaege Kontrolle` varchar(255)
,`Kontr X-Koord` int(10)
,`Kontr Y-Koord` int(10)
,`Kontr Bemerkungen` longtext
,`Kontr Lebensraum Delarze` varchar(255)
,`Kontr angrenzender Lebensraum Delarze` varchar(255)
,`Kontr Vegetationstyp` varchar(100)
,`Kontr Konkurrenz` varchar(100)
,`Kontr Moosschicht` varchar(100)
,`Kontr Krautschicht` varchar(100)
,`Kontr Strauchschicht` varchar(255)
,`Kontr Baumschicht` varchar(100)
,`Kontr Bodentyp` varchar(255)
,`Kontr Boden Kalkgehalt` varchar(100)
,`Kontr Boden Durchlaessigkeit` varchar(100)
,`Kontr Boden Hmusgehalt` varchar(100)
,`Kontr Boden Naehrstoffgehalt` varchar(100)
,`Kontr Oberbodenabtrag` varchar(255)
,`Kontr Wasserhaushalt` varchar(255)
,`TPopKontrIdealBiotopUebereinst` varchar(50)
,`TPopKontrHandlungsbedarf` longtext
,`TPopKontrUebFlaeche` int(10)
,`Kontr Flaeche m2` int(10)
,`Kontr auf Plan eingezeichnet` tinyint(1)
,`Kontr Deckung durch Vegetation` smallint(5)
,`Kontr Deckung nackter Boden` smallint(5)
,`Kontr Deckung durch ueberpruefte Art` smallint(5)
,`Kontr auch junge Pflanzen` tinyint(1)
,`Kontr maximale Veg-hoehe cm` smallint(5)
,`Kontr mittlere Veg-hoehe cm` smallint(5)
,`Kontr Gefaehrdung` varchar(255)
,`MutWann` date
,`MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopAnzMassn`
--
CREATE TABLE IF NOT EXISTS `vTPopAnzMassn` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius (m)` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`Anzahl Massnahmen` bigint(21)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopBer`
--
CREATE TABLE IF NOT EXISTS `vTPopBer` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`TPopId` int(10)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius (m)` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop Verantwortlich` varchar(255)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`TPopBer Id` int(10)
,`TPopBer Jahr` smallint(5)
,`TPopBer Entwicklung` varchar(50)
,`TPopBer Bemerkungen` longtext
,`TPopBer MutWann` date
,`TPopBer MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopBerLetzterBericht`
--
CREATE TABLE IF NOT EXISTS `vTPopBerLetzterBericht` (
`TPopId` int(10)
,`MaxvonTPopBerJahr` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopBerMassnJahre`
--
CREATE TABLE IF NOT EXISTS `vTPopBerMassnJahre` (
`TPopId` int(11)
,`Jahr` smallint(6)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopFuerGis`
--
CREATE TABLE IF NOT EXISTS `vTPopFuerGis` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPopXKoordinaten` int(10)
,`TPopYKoordinaten` int(10)
,`TPop Radius (m)` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop Verantwortlich` varchar(255)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`MutWann` date
,`MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopFuerKml`
--
CREATE TABLE IF NOT EXISTS `vTPopFuerKml` (
`Art` varchar(100)
,`Label` varchar(23)
,`Inhalte` varchar(225)
,`Laengengrad` decimal(59,20)
,`Breitengrad` decimal(59,20)
,`URL` varchar(72)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopFuerKmlNamen`
--
CREATE TABLE IF NOT EXISTS `vTPopFuerKmlNamen` (
`Art` varchar(100)
,`Label` varchar(124)
,`Inhalte` varchar(225)
,`Laengengrad` decimal(59,20)
,`Breitengrad` decimal(59,20)
,`URL` varchar(72)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopKontrBerMassnJahre`
--
CREATE TABLE IF NOT EXISTS `vTPopKontrBerMassnJahre` (
`TPopId` int(11)
,`Jahr` smallint(6)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopMassnBer`
--
CREATE TABLE IF NOT EXISTS `vTPopMassnBer` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`TPopId` int(10)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius (m)` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop Verantwortlich` varchar(255)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`TPopMassnBer Id` int(10)
,`TPopMassnBer Jahr` smallint(5)
,`TPopMassnBer Entwicklung` varchar(50)
,`TPopMassnBer Interpretation` longtext
,`TPopMassnBer MutWann` date
,`TPopMassnBer MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopOhneBekanntSeit`
--
CREATE TABLE IF NOT EXISTS `vTPopOhneBekanntSeit` (
`Art` varchar(100)
,`ApStatus_` varchar(50)
,`PopNr` int(10)
,`PopName` varchar(150)
,`TPopNr` int(10)
,`TPopGemeinde` varchar(255)
,`TPopFlurname` varchar(255)
,`TPopBekanntSeit` smallint(5)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPopOhnePop`
--
CREATE TABLE IF NOT EXISTS `vTPopOhnePop` (
`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius (m)` smallint(5)
,`TPop Höhe üM` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop Verantwortlich` varchar(255)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`MutWann` date
,`MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPop_BerUndMassnBer`
--
CREATE TABLE IF NOT EXISTS `vTPop_BerUndMassnBer` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Status` varchar(50)
,`Pop Status unklar` tinyint(1)
,`Pop Begründung für unklaren Status` varchar(255)
,`Pop bekannt seit` smallint(5)
,`Pop X-Koordinaten` int(10)
,`Pop Y-Koordinaten` int(10)
,`TPopId` int(10)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius (m)` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop Verantwortlich` varchar(255)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`Jahr` smallint(6)
,`TPopBer Id` int(10)
,`TPopBer Jahr` smallint(5)
,`TPopBer Entwicklung` varchar(50)
,`TPopBer Bemerkungen` longtext
,`TPopBer MutWann` date
,`TPopBer MutWer` varchar(20)
,`TPopMassnBer Jahr` smallint(5)
,`TPopMassnBer Entwicklung` varchar(50)
,`TPopMassnBer Interpretation` longtext
,`TPopMassnBer MutWann` date
,`TPopMassnBer MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vTPop_KontrBerMassnBer`
--
CREATE TABLE IF NOT EXISTS `vTPop_KontrBerMassnBer` (
`ApArtId` int(7)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`AP verantwortlich` varchar(255)
,`Pop Guid` varchar(40)
,`Pop Nr` int(10)
,`Pop Name` varchar(150)
,`Pop Herkunft` varchar(50)
,`Pop bekannt seit` smallint(5)
,`TPopId` int(10)
,`TPop Guid` varchar(40)
,`TPop Nr` int(10)
,`TPop Gemeinde` varchar(255)
,`TPop Flurname` varchar(255)
,`TPop Status` varchar(50)
,`TPop Status unklar` tinyint(1)
,`TPop Begründung für unklaren Status` varchar(255)
,`TPop X-Koordinaten` int(10)
,`TPop Y-Koordinaten` int(10)
,`TPop Radius m` smallint(5)
,`TPop Höhe` smallint(5)
,`TPop Exposition` varchar(50)
,`TPop Klima` varchar(50)
,`TPop Hangneigung` varchar(50)
,`TPop Beschreibung` varchar(255)
,`TPop Kataster-Nr` varchar(255)
,`TPop verantwortlich` varchar(255)
,`TPop Herkunft` varchar(50)
,`TPop für AP-Bericht relevant` int(10)
,`TPop bekannt seit` smallint(5)
,`TPop EigentümerIn` varchar(255)
,`TPop Kontakt vor Ort` varchar(255)
,`TPop Nutzungszone` varchar(255)
,`TPop BewirtschafterIn` varchar(255)
,`TPop Bewirtschaftung` varchar(255)
,`Anzahl Kontrollen` bigint(21)
,`Anzahl Feld-Kontrollen` bigint(21)
,`Anzahl Freiwilligen-Kontrollen` bigint(21)
,`Jahr` smallint(6)
,`PopBer Id` int(10)
,`PopBer Jahr` smallint(5)
,`PopBer Entwicklung` varchar(50)
,`PopBer Bemerkungen` longtext
,`PopBer MutWann` date
,`PopBer MutWer` varchar(20)
,`PopMassnBer Id` int(10)
,`PopMassnBer Jahr` smallint(5)
,`PopMassnBer Entwicklung` varchar(50)
,`PopMassnBer Interpretation` longtext
,`PopMassnBer MutWann` date
,`PopMassnBer MutWer` varchar(20)
,`TPopBer Id` int(10)
,`TPopBer Jahr` smallint(5)
,`TPopBer Entwicklung` varchar(50)
,`TPopBer Bemerkungen` longtext
,`TPopBer MutWann` date
,`TPopBer MutWer` varchar(20)
,`TPopMassnBer Id` int(10)
,`TPopMassnBer Jahr` smallint(5)
,`TPopMassnBer Beurteilung` varchar(50)
,`TPopMassnBer Bemerkungen` longtext
,`TPopMassnBer MutWann` date
,`TPopMassnBer MutWer` varchar(20)
,`Kontr Guid` varchar(40)
,`Kontr Jahr` smallint(5)
,`Kontr Datum` date
,`Kontr Typ` varchar(50)
,`Kontr BearbeiterIn` varchar(255)
,`Kontr Zaehleinheit 1` varchar(50)
,`Kontr Methode 1` varchar(50)
,`Kontr Anzahl 1` int(10)
,`Kontr Zaehleinheit 2` varchar(50)
,`Kontr Methode 2` varchar(50)
,`Kontr Anzahl 2` int(10)
,`Kontr Zaehleinheit 3` varchar(50)
,`Kontr Methode 3` varchar(50)
,`Kontr Anzahl 3` int(10)
,`Kontr Ueberlebensrate` smallint(5)
,`Kontr Vitalitaet` varchar(255)
,`Kontr Entwicklung` varchar(50)
,`Kontr Ursachen` varchar(255)
,`Kontr Erfolgsbeurteilung` varchar(255)
,`Kontr Aend-Vorschlaege Umsetzung` varchar(255)
,`Kontr Aend-Vorschlaege Kontrolle` varchar(255)
,`Kontr X-Koord` int(10)
,`Kontr Y-Koord` int(10)
,`Kontr Bemerkungen` longtext
,`Kontr Lebensraum Delarze` varchar(255)
,`Kontr angrenzender Lebensraum Delarze` varchar(255)
,`Kontr Vegetationstyp` varchar(100)
,`Kontr Konkurrenz` varchar(100)
,`Kontr Moosschicht` varchar(100)
,`Kontr Krautschicht` varchar(100)
,`Kontr Strauchschicht` varchar(255)
,`Kontr Baumschicht` varchar(100)
,`Kontr Bodentyp` varchar(255)
,`Kontr Boden Kalkgehalt` varchar(100)
,`Kontr Boden Durchlaessigkeit` varchar(100)
,`Kontr Boden Hmusgehalt` varchar(100)
,`Kontr Boden Naehrstoffgehalt` varchar(100)
,`Kontr Oberbodenabtrag` varchar(255)
,`Kontr Wasserhaushalt` varchar(255)
,`TPopKontrIdealBiotopUebereinst` varchar(50)
,`TPopKontrHandlungsbedarf` longtext
,`TPopKontrUebFlaeche` int(10)
,`Kontr Flaeche m2` int(10)
,`Kontr auf Plan eingezeichnet` tinyint(1)
,`Kontr Deckung durch Vegetation` smallint(5)
,`Kontr Deckung nackter Boden` smallint(5)
,`Kontr Deckung durch ueberpruefte Art` smallint(5)
,`Kontr auch junge Pflanzen` tinyint(1)
,`Kontr maximale Veg-hoehe cm` smallint(5)
,`Kontr mittlere Veg-hoehe cm` smallint(5)
,`Kontr Gefaehrdung` varchar(255)
,`MutWann` date
,`MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vUmwfakt`
--
CREATE TABLE IF NOT EXISTS `vUmwfakt` (
`AP ApArtId` int(10)
,`AP Art` varchar(100)
,`AP Bearbeitungsstand` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`AP verantwortlich` varchar(255)
,`AP Letzte Änderung` date
,`AP Letzte(r) Bearbeiter(in)` varchar(20)
,`Uf ApArtId` int(11)
,`Uf Erstelldatum` date
,`Uf Hoehenlage` text
,`Uf Region` text
,`Uf Exposition` text
,`Uf Besonnung` text
,`Uf Hangneigung` text
,`Uf Bodentyp` text
,`Uf Boden Kalkgehalt` text
,`Uf Boden Durchlaessigkeit` text
,`Uf Boden Humus` text
,`Uf Boden Naehrstoffgehalt` text
,`Uf Wasserhaushalt` text
,`Uf Konkurrenz` text
,`Uf Moosschicht` text
,`Uf Krautschicht` text
,`Uf Strauchschicht` text
,`Uf Baumschicht` text
,`Uf Bemerkungen` text
,`Uf MutWann` date
,`Uf MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vUmwfaktOhneAp`
--
CREATE TABLE IF NOT EXISTS `vUmwfaktOhneAp` (
`AP ApArtId` int(10)
,`Uf ApArtId` int(11)
,`Uf Erstelldatum` date
,`Uf Hoehenlage` text
,`Uf Region` text
,`Uf Exposition` text
,`Uf Besonnung` text
,`Uf Hangneigung` text
,`Uf Bodentyp` text
,`Uf Boden Kalkgehalt` text
,`Uf Boden Durchlaessigkeit` text
,`Uf Boden Humus` text
,`Uf Boden Naehrstoffgehalt` text
,`Uf Wasserhaushalt` text
,`Uf Konkurrenz` text
,`Uf Moosschicht` text
,`Uf Krautschicht` text
,`Uf Strauchschicht` text
,`Uf Baumschicht` text
,`Uf Bemerkungen` text
,`Uf MutWann` date
,`Uf MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vZielBer`
--
CREATE TABLE IF NOT EXISTS `vZielBer` (
`AP Id` int(10)
,`AP Art` varchar(100)
,`AP Status` varchar(50)
,`AP Start im Jahr` smallint(5)
,`AP Stand Umsetzung` varchar(50)
,`AP verantwortlich` varchar(255)
,`Ziel Id` int(10)
,`Ziel Jahr` smallint(5)
,`Ziel Typ` varchar(50)
,`Ziel Beschreibung` longtext
,`ZielBer Id` int(10)
,`ZielBer ZielId` int(10)
,`ZielBer Jahr` smallint(5)
,`ZielBer Erreichung` varchar(255)
,`ZielBer Bemerkungen` varchar(255)
,`ZielBer MutWann` date
,`ZielBer MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Stellvertreter-Struktur des Views `vZielBerOhneZiel`
--
CREATE TABLE IF NOT EXISTS `vZielBerOhneZiel` (
`AP Id` int(10)
,`Ziel Id` int(10)
,`ZielBer Id` int(10)
,`ZielBer ZielId` int(10)
,`ZielBer Jahr` smallint(5)
,`ZielBer Erreichung` varchar(255)
,`ZielBer Bemerkungen` varchar(255)
,`ZielBer MutWann` date
,`ZielBer MutWer` varchar(20)
);
-- --------------------------------------------------------

--
-- Struktur des Views `vApAnzKontr`
--
DROP TABLE IF EXISTS `vApAnzKontr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApAnzKontr` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,count(`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId`) AS `Anzahl Kontrollen` from ((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join ((`alexande_apflora`.`tblPopulation` left join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) left join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) group by `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt`,`alexande_apflora`.`tblAktionsplan`.`ApJahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vApAnzMassn`
--
DROP TABLE IF EXISTS `vApAnzMassn`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApAnzMassn` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,count(`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnId`) AS `Anzahl Massnahmen` from ((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join ((`alexande_apflora`.`tblPopulation` left join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) left join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) group by `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt`,`alexande_apflora`.`tblAktionsplan`.`ApJahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vApAnzMassnBisJahr`
--
DROP TABLE IF EXISTS `vApAnzMassnBisJahr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApAnzMassnBisJahr` AS select `vApMassnJahre`.`ApArtId` AS `ApArtId`,`vApMassnJahre`.`TPopMassnJahr` AS `TPopMassnJahr`,sum(`vApAnzMassnProJahr`.`AnzahlMassnahmen`) AS `AnzahlMassnahmen` from (`vApMassnJahre` join `vApAnzMassnProJahr` on((`vApMassnJahre`.`ApArtId` = `vApAnzMassnProJahr`.`ApArtId`))) where (`vApAnzMassnProJahr`.`TPopMassnJahr` <= `vApMassnJahre`.`TPopMassnJahr`) group by `vApMassnJahre`.`ApArtId`,`vApMassnJahre`.`TPopMassnJahr` order by `vApMassnJahre`.`ApArtId`,`vApMassnJahre`.`TPopMassnJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vApAnzMassnProJahr`
--
DROP TABLE IF EXISTS `vApAnzMassnProJahr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApAnzMassnProJahr` AS select `vApMassnJahre`.`ApArtId` AS `ApArtId`,`vApMassnJahre`.`TPopMassnJahr` AS `TPopMassnJahr`,if((`vApAnzMassnProJahr0`.`AnzahlvonTPopMassnId` is not null),`vApAnzMassnProJahr0`.`AnzahlvonTPopMassnId`,0) AS `AnzahlMassnahmen` from (`vApMassnJahre` left join `vApAnzMassnProJahr0` on(((`vApMassnJahre`.`TPopMassnJahr` = `vApAnzMassnProJahr0`.`TPopMassnJahr`) and (`vApMassnJahre`.`ApArtId` = `vApAnzMassnProJahr0`.`ApArtId`)))) order by `vApMassnJahre`.`ApArtId`,`vApMassnJahre`.`TPopMassnJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vApAnzMassnProJahr0`
--
DROP TABLE IF EXISTS `vApAnzMassnProJahr0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApAnzMassnProJahr0` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` AS `TPopMassnJahr`,count(`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnId`) AS `AnzahlvonTPopMassnId` from (`alexande_apflora`.`tblAktionsplan` join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where ((`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblAktionsplan`.`ApArtId`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` having (`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` is not null) order by `alexande_apflora`.`tblAktionsplan`.`ApArtId`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vApApBerichtRelevant`
--
DROP TABLE IF EXISTS `vApApBerichtRelevant`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApApBerichtRelevant` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId` from (`alexande_apflora`.`tblAktionsplan` join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblAktionsplan`.`ApArtId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vApArtenAnzKontrInJahr`
--
DROP TABLE IF EXISTS `vApArtenAnzKontrInJahr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApArtenAnzKontrInJahr` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId` AS `TPopKontrId`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` AS `TPopKontrJahr` from ((`alexande_apflora`.`tblAktionsplan` join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`))) join (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) group by `alexande_apflora`.`tblAktionsplan`.`ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vApJahresberichte`
--
DROP TABLE IF EXISTS `vApJahresberichte`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApJahresberichte` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblJBer`.`JBerId` AS `JBerId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Name`,`alexande_apflora`.`tblJBer`.`JBerJahr` AS `JBerJahr`,`alexande_apflora`.`tblJBer`.`JBerSituation` AS `JBerSituation`,`alexande_apflora`.`tblJBer`.`JBerVergleichVorjahrGesamtziel` AS `JBerVergleichVorjahrGesamtziel`,`alexande_apflora`.`DomainApErfKrit`.`BeurteilTxt` AS `JBerBeurteilung`,`alexande_apflora`.`tblJBer`.`JBerVeraenGegenVorjahr` AS `JBerVeraenGegenVorjahr`,`alexande_apflora`.`tblJBer`.`JBerAnalyse` AS `JBerAnalyse`,`alexande_apflora`.`tblJBer`.`JBerUmsetzung` AS `JBerUmsetzung`,`alexande_apflora`.`tblJBer`.`JBerErfko` AS `JBerErfko`,`alexande_apflora`.`tblJBer`.`JBerATxt` AS `JBerATxt`,`alexande_apflora`.`tblJBer`.`JBerBTxt` AS `JBerBTxt`,`alexande_apflora`.`tblJBer`.`JBerCTxt` AS `JBerCTxt`,`alexande_apflora`.`tblJBer`.`JBerDTxt` AS `JBerDTxt`,`alexande_apflora`.`tblJBer`.`JBerDatum` AS `JBerDatum`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `JBerBearb` from ((`alexande_apflora`.`tblAktionsplan` join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`))) join ((`alexande_apflora`.`tblJBer` left join `alexande_apflora`.`DomainApErfKrit` on((`alexande_apflora`.`tblJBer`.`JBerBeurteilung` = `alexande_apflora`.`DomainApErfKrit`.`BeurteilId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblJBer`.`JBerBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vApJahresberichteUndMassnahmen`
--
DROP TABLE IF EXISTS `vApJahresberichteUndMassnahmen`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApJahresberichteUndMassnahmen` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `AP Verantwortlich`,`alexande_apflora`.`tblAktionsplan`.`ApArtwert` AS `Artwert`,`vApAnzMassnProJahr`.`TPopMassnJahr` AS `Jahr`,`vApAnzMassnProJahr`.`AnzahlMassnahmen` AS `Anzahl Massnahmen`,`vApAnzMassnBisJahr`.`AnzahlMassnahmen` AS `Anzahl Massnahmen bisher`,if((`alexande_apflora`.`tblJBer`.`JBerJahr` > 0),'Ja','Nein') AS `Bericht erstellt` from (((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) join `vApAnzMassnProJahr` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApAnzMassnProJahr`.`ApArtId`))) join `vApAnzMassnBisJahr` on(((`vApAnzMassnProJahr`.`TPopMassnJahr` = `vApAnzMassnBisJahr`.`TPopMassnJahr`) and (`vApAnzMassnProJahr`.`ApArtId` = `vApAnzMassnBisJahr`.`ApArtId`)))) left join `alexande_apflora`.`tblJBer` on(((`vApAnzMassnBisJahr`.`TPopMassnJahr` = `alexande_apflora`.`tblJBer`.`JBerJahr`) and (`vApAnzMassnBisJahr`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`)))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`vApAnzMassnProJahr`.`TPopMassnJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vApMassnJahre`
--
DROP TABLE IF EXISTS `vApMassnJahre`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApMassnJahre` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`vMassnJahre`.`TPopMassnJahr` AS `TPopMassnJahr` from (`alexande_apflora`.`tblAktionsplan` join `vMassnJahre`) where ((`alexande_apflora`.`tblAktionsplan`.`ApArtId` > 0) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3)) order by `alexande_apflora`.`tblAktionsplan`.`ApArtId`,`vMassnJahre`.`TPopMassnJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vApOhnePop`
--
DROP TABLE IF EXISTS `vApOhnePop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApOhnePop` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `Bearbeitungsstand AP`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `Start AP im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `Stand Umsetzung AP`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Verantwortlich`,`alexande_apflora`.`tblPopulation`.`ApArtId` AS `Population` from (((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where isnull(`alexande_apflora`.`tblPopulation`.`ApArtId`) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vApZiele`
--
DROP TABLE IF EXISTS `vApZiele`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApZiele` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `AP Id`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `AP verantwortlich`,`alexande_apflora`.`tblZiel`.`ZielId` AS `Ziel Id`,`alexande_apflora`.`tblZiel`.`ApArtId` AS `Ziel ApId`,`alexande_apflora`.`tblZiel`.`ZielJahr` AS `Ziel Jahr`,`alexande_apflora`.`DomainZielTyp`.`ZieltypTxt` AS `Ziel Typ`,`alexande_apflora`.`tblZiel`.`ZielBezeichnung` AS `Ziel Beschreibung` from ((`alexande_apflora`.`tblZiel` left join ((((`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblZiel`.`ApArtId`))) left join `alexande_apflora`.`DomainZielTyp` on((`alexande_apflora`.`tblZiel`.`ZielTyp` = `alexande_apflora`.`DomainZielTyp`.`ZieltypId`))) where ((`alexande_apflora`.`tblZiel`.`ZielTyp` = 1) or (`alexande_apflora`.`tblZiel`.`ZielTyp` = 2) or (`alexande_apflora`.`tblZiel`.`ZielTyp` = 1170775556)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblZiel`.`ZielJahr`,`alexande_apflora`.`DomainZielTyp`.`ZieltypTxt`,`alexande_apflora`.`tblZiel`.`ZielTyp`;

-- --------------------------------------------------------

--
-- Struktur des Views `vApZieleOhneAp`
--
DROP TABLE IF EXISTS `vApZieleOhneAp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vApZieleOhneAp` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `AP Id`,`alexande_apflora`.`tblZiel`.`ZielId` AS `Ziel Id`,`alexande_apflora`.`tblZiel`.`ApArtId` AS `Ziel ApId`,`alexande_apflora`.`tblZiel`.`ZielJahr` AS `Ziel Jahr`,`alexande_apflora`.`DomainZielTyp`.`ZieltypTxt` AS `Ziel Typ`,`alexande_apflora`.`tblZiel`.`ZielBezeichnung` AS `Ziel Beschreibung` from ((`alexande_apflora`.`tblZiel` left join ((((`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblZiel`.`ApArtId`))) left join `alexande_apflora`.`DomainZielTyp` on((`alexande_apflora`.`tblZiel`.`ZielTyp` = `alexande_apflora`.`DomainZielTyp`.`ZieltypId`))) where isnull(`alexande_apflora`.`tblAktionsplan`.`ApArtId`) order by `alexande_apflora`.`tblZiel`.`ZielJahr`,`alexande_apflora`.`DomainZielTyp`.`ZieltypTxt`,`alexande_apflora`.`tblZiel`.`ZielTyp`;

-- --------------------------------------------------------

--
-- Struktur des Views `vAssozArten`
--
DROP TABLE IF EXISTS `vAssozArten`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vAssozArten` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Bearbeitungsstand`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `AP verantwortlich`,`alexande_apflora`.`tblAssozArten`.`AaId` AS `AA Id`,`ArtenDb_Arteigenschaften_1`.`Artname` AS `AA Art`,`alexande_apflora`.`tblAssozArten`.`AaBem` AS `AA Bemerkungen`,`alexande_apflora`.`tblAssozArten`.`MutWann` AS `AA MutWann`,`alexande_apflora`.`tblAssozArten`.`MutWer` AS `AA MutWer` from ((`alexande_apflora`.`tblAssozArten` left join ((((`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblAssozArten`.`AaApArtId`))) left join `alexande_beob`.`ArtenDb_Arteigenschaften` `ArtenDb_Arteigenschaften_1` on((`ArtenDb_Arteigenschaften_1`.`TaxonomieId` = `alexande_apflora`.`tblAssozArten`.`AaSisfNr`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vAssozArtenOhneAp`
--
DROP TABLE IF EXISTS `vAssozArtenOhneAp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vAssozArtenOhneAp` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `AP ApArtId`,`alexande_apflora`.`tblAssozArten`.`AaId` AS `AA Id`,`alexande_apflora`.`tblAssozArten`.`AaApArtId` AS `AA ApArtId`,`ArtenDb_Arteigenschaften_1`.`Artname` AS `AA Art`,`alexande_apflora`.`tblAssozArten`.`AaBem` AS `AA Bemerkungen`,`alexande_apflora`.`tblAssozArten`.`MutWann` AS `AA MutWann`,`alexande_apflora`.`tblAssozArten`.`MutWer` AS `AA MutWer` from ((`alexande_apflora`.`tblAssozArten` left join ((((`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblAssozArten`.`AaApArtId`))) left join `alexande_beob`.`ArtenDb_Arteigenschaften` `ArtenDb_Arteigenschaften_1` on((`ArtenDb_Arteigenschaften_1`.`TaxonomieId` = `alexande_apflora`.`tblAssozArten`.`AaSisfNr`))) where isnull(`alexande_apflora`.`tblAktionsplan`.`ApArtId`) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vAuswAnzProTPopAngezArtBestJahr0`
--
DROP TABLE IF EXISTS `vAuswAnzProTPopAngezArtBestJahr0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vAuswAnzProTPopAngezArtBestJahr0` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId` AS `TPopKontrId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `PopHerkunft`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPopFlurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPopHerkunft`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` AS `TPopKontrTyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` AS `TPopKontrJahr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` AS `TPopKontrDatum`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPopKontrBearb`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` AS `TPopKontrZaehleinheit1`,`alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilTxt` AS `TPopKontrMethode1`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz1` AS `TPopKontrAnz1`,`DomainTPopKontrZaehleinheit_1`.`ZaehleinheitTxt` AS `TPopKontrZaehleinheit2`,`DomainTPopKontrMethode_1`.`BeurteilTxt` AS `TPopKontrMethode2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz2` AS `TPopKontrAnz2`,`DomainTPopKontrZaehleinheit_2`.`ZaehleinheitTxt` AS `TPopKontrZaehleinheit3`,`DomainTPopKontrMethode_2`.`BeurteilTxt` AS `TPopKontrMethode3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz3` AS `TPopKontrAnz3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJungpfl` AS `TPopKontrJungpfl`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVitalitaet` AS `TPopKontrVitalitaet`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUeberleb` AS `TPopKontrUeberleb`,`alexande_apflora`.`DomainTPopEntwicklung`.`EntwicklungTxt` AS `TPopKontrEntwicklung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrsach` AS `TPopKontrUrsach`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrteil` AS `TPopKontrUrteil`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendUms` AS `TPopKontrAendUms`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendKontr` AS `TPopKontrAendKontr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTxt` AS `TPopKontrTxt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLeb` AS `TPopKontrLeb`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrFlaeche` AS `TPopKontrFlaeche`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLebUmg` AS `TPopKontrLebUmg`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrStrauchschicht` AS `TPopKontrStrauchschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenTyp` AS `TPopKontrBodenTyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenAbtrag` AS `TPopKontrBodenAbtrag`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrWasserhaushalt` AS `TPopKontrWasserhaushalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrHandlungsbedarf` AS `TPopKontrHandlungsbedarf`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebFlaeche` AS `TPopKontrUebFlaeche`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrPlan` AS `TPopKontrPlan`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVeg` AS `TPopKontrVeg`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrNaBo` AS `TPopKontrNaBo`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebPfl` AS `TPopKontrUebPfl`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJungPflJN` AS `TPopKontrJungPflJN`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMax` AS `TPopKontrVegHoeMax`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMit` AS `TPopKontrVegHoeMit`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGefaehrdung` AS `TPopKontrGefaehrdung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMutDat` AS `TPopKontrMutDat` from (((((((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join (((`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopEntwicklung` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrEntwicklung` = `alexande_apflora`.`DomainTPopEntwicklung`.`EntwicklungCode`)));

-- --------------------------------------------------------

--
-- Struktur des Views `vAuswAp`
--
DROP TABLE IF EXISTS `vAuswAp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vAuswAp` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `Bearbeitungsstand AP`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `Start AP im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `Stand Umsetzung AP`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Verantwortlich`,`alexande_apflora`.`tblAktionsplan`.`MutWann` AS `Letzte Änderung`,`alexande_apflora`.`tblAktionsplan`.`MutWer` AS `Letzte(r) Bearbeiter(in)` from ((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) where (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vAuswApArtenAnzMassnInJahr0`
--
DROP TABLE IF EXISTS `vAuswApArtenAnzMassnInJahr0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vAuswApArtenAnzMassnInJahr0` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnId` AS `TPopMassnId`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` AS `TPopMassnJahr` from ((`alexande_apflora`.`tblAktionsplan` join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`))) join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) group by `alexande_apflora`.`tblAktionsplan`.`ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnId`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vAuswApArtenBearbMassnInJahr0`
--
DROP TABLE IF EXISTS `vAuswApArtenBearbMassnInJahr0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vAuswApArtenBearbMassnInJahr0` AS select `alexande_apflora`.`tblAdresse`.`AdrName` AS `AdrName`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPopFlurname`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` AS `TPopMassnJahr`,`alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypTxt` AS `TPopMassnTyp`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTxt` AS `TPopMassnTxt`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnDatum` AS `TPopMassnDatum`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnBemTxt` AS `TPopMassnBemTxt`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlan` AS `TPopMassnPlan`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlanBez` AS `TPopMassnPlanBez`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnFlaeche` AS `TPopMassnFlaeche`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnMarkierung` AS `TPopMassnMarkierung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzTriebe` AS `TPopMassnAnsiedAnzTriebe`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzPfl` AS `TPopMassnAnsiedAnzPfl`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnzPflanzstellen` AS `TPopMassnAnzPflanzstellen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedWirtspfl` AS `TPopMassnAnsiedWirtspfl`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedHerkunftPop` AS `TPopMassnAnsiedHerkunftPop`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedDatSamm` AS `TPopMassnAnsiedDatSamm`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedForm` AS `TPopMassnAnsiedForm`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedPflanzanordnung` AS `TPopMassnAnsiedPflanzanordnung` from ((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join ((`alexande_apflora`.`tblTeilPopMassnahme` left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) join `alexande_apflora`.`DomainTPopMassnTyp` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTyp` = `alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypCode`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) order by `alexande_apflora`.`tblAdresse`.`AdrName`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vAuswApArtenMitMassnInJahr0`
--
DROP TABLE IF EXISTS `vAuswApArtenMitMassnInJahr0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vAuswApArtenMitMassnInJahr0` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPopFlurname`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` AS `TPopMassnJahr`,`alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypTxt` AS `TPopMassnTyp`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTxt` AS `TPopMassnTxt`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnDatum` AS `TPopMassnDatum`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPopMassnBearb`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnBemTxt` AS `TPopMassnBemTxt`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlan` AS `TPopMassnPlan`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlanBez` AS `TPopMassnPlanBez`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnFlaeche` AS `TPopMassnFlaeche`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnMarkierung` AS `TPopMassnMarkierung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzTriebe` AS `TPopMassnAnsiedAnzTriebe`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzPfl` AS `TPopMassnAnsiedAnzPfl`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnzPflanzstellen` AS `TPopMassnAnzPflanzstellen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedWirtspfl` AS `TPopMassnAnsiedWirtspfl`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedHerkunftPop` AS `TPopMassnAnsiedHerkunftPop`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedDatSamm` AS `TPopMassnAnsiedDatSamm`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedForm` AS `TPopMassnAnsiedForm`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedPflanzanordnung` AS `TPopMassnAnsiedPflanzanordnung` from ((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join ((`alexande_apflora`.`tblTeilPopMassnahme` join `alexande_apflora`.`DomainTPopMassnTyp` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTyp` = `alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vAuswArtPopTPopMassn0`
--
DROP TABLE IF EXISTS `vAuswArtPopTPopMassn0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vAuswArtPopTPopMassn0` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `Aktionsplan Bearbeitungsstand`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPopFlurname`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnId` AS `TPopMassnId`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` AS `Jahr`,`alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypTxt` AS `Massnahme`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTxt` AS `TPopMassnTxt`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnDatum` AS `TPopMassnDatum`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPopMassnBearb`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnBemTxt` AS `TPopMassnBemTxt`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlan` AS `TPopMassnPlan`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlanBez` AS `TPopMassnPlanBez`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnFlaeche` AS `TPopMassnFlaeche`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnMarkierung` AS `TPopMassnMarkierung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzTriebe` AS `TPopMassnAnsiedAnzTriebe`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzPfl` AS `TPopMassnAnsiedAnzPfl`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnzPflanzstellen` AS `TPopMassnAnzPflanzstellen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedWirtspfl` AS `TPopMassnAnsiedWirtspfl`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedHerkunftPop` AS `TPopMassnAnsiedHerkunftPop`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedDatSamm` AS `TPopMassnAnsiedDatSamm`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedForm` AS `TPopMassnAnsiedForm`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedPflanzanordnung` AS `TPopMassnAnsiedPflanzanordnung` from (((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join ((`alexande_apflora`.`tblTeilPopMassnahme` left join `alexande_apflora`.`DomainTPopMassnTyp` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTyp` = `alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr`,`alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypTxt`;

-- --------------------------------------------------------

--
-- Struktur des Views `vAuswArtPopTPopMassnBerFuerAktArt0`
--
DROP TABLE IF EXISTS `vAuswArtPopTPopMassnBerFuerAktArt0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vAuswArtPopTPopMassnBerFuerAktArt0` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `Aktionsplan-Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `Aktionsplan-Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `Aktionsplan-Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Population-Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Population-Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Population-Herkunft`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Population - bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `Teilpopulation-Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `Teilpopulation-Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `Teilpopulation-Flurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `Teilpopulation-X-Koodinate`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `Teilpopulation-Y-Koordinate`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `Teilpopulation-Radius`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `Teilpopulation-Hoehe`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `Teilpopulation-Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `Teilpopulation-Kataster-Nr`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Teilpopulation-Verantwortlich`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `Teilpopulation-Herkunft`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `Teilpopulation - Herkunft unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `Teilpopulation - Herkunft unklar Begründung`,`alexande_apflora`.`DomainTPopApBerichtRelevant`.`DomainTxt` AS `Teilpopulation - Für Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `Teilpopulation - bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `Teilpopulation-Eigentümer`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `Teilpopulation-Kontakt`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `Teilpopulation-Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `Teilpopulation-Bewirtschafter`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `Teilpopulation-Bewirtschaftung`,`alexande_apflora`.`tblTeilpopulation`.`TPopTxt` AS `Teilpopulation-Bemerkungen`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr` AS `Massnahmenbericht-Jahr`,`alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilTxt` AS `Massnahmenbericht-Erfolgsberuteilung`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerTxt` AS `Massnahmenbericht-Interpretation` from ((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) join (((`alexande_apflora`.`tblPopulation` left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) join (((`alexande_apflora`.`tblTeilpopulation` left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilpopulation`.`TPopVerantw` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) left join `alexande_apflora`.`DomainTPopApBerichtRelevant` on((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = `alexande_apflora`.`DomainTPopApBerichtRelevant`.`DomainCode`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join (`alexande_apflora`.`tblTeilPopMassnBericht` join `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung` on((`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerErfolgsbeurteilung` = `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilId`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vAuswArtPopTPopMassnFuerAktArt0`
--
DROP TABLE IF EXISTS `vAuswArtPopTPopMassnFuerAktArt0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vAuswArtPopTPopMassnFuerAktArt0` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `Aktionsplan-Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `Aktionsplan-Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `Aktionsplan-Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Population-Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Population-Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Population-Herkunft`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Population - bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `Teilpopulation-Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `Teilpopulation-Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `Teilpopulation-Flurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `Teilpopulation-X-Koodinate`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `Teilpopulation-Y-Koordinate`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `Teilpopulation-Radius`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `Teilpopulation-Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `Teilpopulation-Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `Teilpopulation-Kataster-Nr`,`tblAdresse_1`.`AdrName` AS `Teilpopulation-Verantwortlich`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `Teilpopulation-Herkunft`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `Teilpopulation - Herkunft unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `Teilpopulation - Herkunft unklar Begründung`,`alexande_apflora`.`DomainTPopApBerichtRelevant`.`DomainTxt` AS `Teilpopulation - Für Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `Teilpopulation - bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `Teilpopulation-Eigentümer`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `Teilpopulation-Kontakt`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `Teilpopulation-Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `Teilpopulation-Bewirtschafter`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `Teilpopulation-Bewirtschaftung`,`alexande_apflora`.`tblTeilpopulation`.`TPopTxt` AS `Teilpopulation-Bemerkungen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnId` AS `TPopMassnId`,`alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypTxt` AS `Massnahme-Typ`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTxt` AS `Massnahme-Beschreibung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnDatum` AS `Massnahme-Datum`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Massnahme-BearbeiterIn`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnBemTxt` AS `Massnahme-Bemerkungen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlan` AS `Massnahme-Plan`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlanBez` AS `Massnahme-Planbezeichnung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnFlaeche` AS `Massnahme-Fläche`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnMarkierung` AS `Massnahme-Markierung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzTriebe` AS `Massnahme - Ansiedlung Anzahl Triebe`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzPfl` AS `Massnahme - Ansiedlung Anzahl Pflanzen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnzPflanzstellen` AS `Massnahme - Ansiedlung Anzahl Pflanzstellen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedWirtspfl` AS `Massnahme - Ansiedlung Wirtspflanzen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedHerkunftPop` AS `Massnahme - Ansiedlung Herkunftspopulation`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedDatSamm` AS `Massnahme - Ansiedlung Sammeldatum`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedForm` AS `Massnahme - Ansiedlung Form`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedPflanzanordnung` AS `Massnahme - Ansiedlung Pflanzordnung` from ((`alexande_beob`.`ArtenDb_Arteigenschaften` join ((`alexande_apflora`.`tblAktionsplan` left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (((`alexande_apflora`.`tblPopulation` left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) join (((`alexande_apflora`.`tblTeilpopulation` left join `alexande_apflora`.`tblAdresse` `tblAdresse_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopVerantw` = `tblAdresse_1`.`AdrId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) left join `alexande_apflora`.`DomainTPopApBerichtRelevant` on((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = `alexande_apflora`.`DomainTPopApBerichtRelevant`.`DomainCode`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join ((`alexande_apflora`.`tblTeilPopMassnahme` left join `alexande_apflora`.`DomainTPopMassnTyp` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTyp` = `alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypTxt`;

-- --------------------------------------------------------

--
-- Struktur des Views `vAuswFlurnameArtKontrolle`
--
DROP TABLE IF EXISTS `vAuswFlurnameArtKontrolle`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vAuswFlurnameArtKontrolle` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId` AS `TPopKontrId`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `Flurname aus Teilpopulation`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `Bearbeitungsstand AP`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` AS `Jahr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` AS `Kontrolltyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` AS `TPopKontrDatum`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPopKontrBearb`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` AS `TPopKontrZaehleinheit1`,`alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilTxt` AS `TPopKontrMethode1`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz1` AS `TPopKontrAnz1`,`DomainTPopKontrZaehleinheit_1`.`ZaehleinheitTxt` AS `TPopKontrZaehleinheit2`,`DomainTPopKontrMethode_1`.`BeurteilTxt` AS `TPopKontrMethode2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz2` AS `TPopKontrAnz2`,`DomainTPopKontrZaehleinheit_2`.`ZaehleinheitTxt` AS `TPopKontrZaehleinheit3`,`DomainTPopKontrMethode_2`.`BeurteilTxt` AS `TPopKontrMethode3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz3` AS `TPopKontrAnz3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJungpfl` AS `TPopKontrJungpfl`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVitalitaet` AS `TPopKontrVitalitaet`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUeberleb` AS `TPopKontrUeberleb`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrEntwicklung` AS `TPopKontrEntwicklung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrsach` AS `TPopKontrUrsach`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrteil` AS `TPopKontrUrteil`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendUms` AS `TPopKontrAendUms`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendKontr` AS `TPopKontrAendKontr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTxt` AS `TPopKontrTxt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLeb` AS `TPopKontrLeb`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrFlaeche` AS `TPopKontrFlaeche`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLebUmg` AS `TPopKontrLebUmg`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrStrauchschicht` AS `TPopKontrStrauchschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenTyp` AS `TPopKontrBodenTyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenAbtrag` AS `TPopKontrBodenAbtrag`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrWasserhaushalt` AS `TPopKontrWasserhaushalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrHandlungsbedarf` AS `TPopKontrHandlungsbedarf`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebFlaeche` AS `TPopKontrUebFlaeche`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrPlan` AS `TPopKontrPlan`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVeg` AS `TPopKontrVeg`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrNaBo` AS `TPopKontrNaBo`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebPfl` AS `TPopKontrUebPfl`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJungPflJN` AS `TPopKontrJungPflJN`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMax` AS `TPopKontrVegHoeMax`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMit` AS `TPopKontrVegHoeMit`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGefaehrdung` AS `TPopKontrGefaehrdung` from ((((((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) where (not((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` like 'Ziel'))) order by `alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp`;

-- --------------------------------------------------------

--
-- Struktur des Views `vAuswPopBerAngezArtBestJahr0`
--
DROP TABLE IF EXISTS `vAuswPopBerAngezArtBestJahr0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vAuswPopBerAngezArtBestJahr0` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblPopBericht`.`PopBerId` AS `PopBerId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `PopHerkunft`,`alexande_apflora`.`tblPopBericht`.`PopBerJahr` AS `PopBerJahr`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt` AS `PopBerEntwicklung`,`alexande_apflora`.`tblPopBericht`.`PopBerTxt` AS `PopBerTxt` from (((`alexande_beob`.`ArtenDb_Arteigenschaften` join ((`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblPopBericht` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopEntwicklung` on((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = `alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungId`)));

-- --------------------------------------------------------

--
-- Struktur des Views `vBeob`
--
DROP TABLE IF EXISTS `vBeob`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vBeob` AS select `alexande_beob`.`tblBeobInfospezies`.`NO_NOTE` AS `NO_NOTE`,'' AS `ID_EVAB`,`alexande_beob`.`tblBeobInfospezies`.`NO_ISFS` AS `NO_ISFS`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `PopGuid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPopGuid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_beob`.`tblBeobInfospezies`.`PROJET` AS `PROJET`,`alexande_beob`.`tblBeobInfospezies`.`NOM_COMMUNE` AS `NOM_COMMUNE`,`alexande_beob`.`tblBeobInfospezies`.`DESC_LOCALITE` AS `DESC_LOCALITE`,`alexande_beob`.`tblBeobInfospezies`.`FNS_XGIS` AS `X`,`alexande_beob`.`tblBeobInfospezies`.`FNS_YGIS` AS `Y`,if(((`alexande_beob`.`tblBeobInfospezies`.`FNS_XGIS` > 0) and (`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` > 0) and (`alexande_beob`.`tblBeobInfospezies`.`FNS_YGIS` > 0) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` > 0)),round(sqrt((((`alexande_beob`.`tblBeobInfospezies`.`FNS_XGIS` - `alexande_apflora`.`tblTeilpopulation`.`TPopXKoord`) * (`alexande_beob`.`tblBeobInfospezies`.`FNS_XGIS` - `alexande_apflora`.`tblTeilpopulation`.`TPopXKoord`)) + ((`alexande_beob`.`tblBeobInfospezies`.`FNS_YGIS` - `alexande_apflora`.`tblTeilpopulation`.`TPopYKoord`) * (`alexande_beob`.`tblBeobInfospezies`.`FNS_YGIS` - `alexande_apflora`.`tblTeilpopulation`.`TPopYKoord`)))),0),NULL) AS `Distanz zur Teilpopulation (m)`,`alexande_beob`.`tblBeobBereitgestellt`.`Datum` AS `Datum`,`alexande_beob`.`tblBeobBereitgestellt`.`Autor` AS `Autor`,`alexande_apflora`.`tblBeobZuordnung`.`BeobNichtZuordnen` AS `BeobNichtZuordnen`,`alexande_apflora`.`tblBeobZuordnung`.`BeobBemerkungen` AS `BeobBemerkungen`,`alexande_apflora`.`tblBeobZuordnung`.`BeobMutWann` AS `BeobMutWann`,`alexande_apflora`.`tblBeobZuordnung`.`BeobMutWer` AS `BeobMutWer` from (((`alexande_beob`.`tblBeobInfospezies` join `alexande_beob`.`tblBeobBereitgestellt` on((`alexande_beob`.`tblBeobInfospezies`.`NO_NOTE` = `alexande_beob`.`tblBeobBereitgestellt`.`NO_NOTE`))) join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`tblBeobInfospezies`.`NO_ISFS` = `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`))) join (`alexande_apflora`.`tblBeobZuordnung` left join (`alexande_apflora`.`tblTeilpopulation` left join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblBeobZuordnung`.`TPopId`))) on((`alexande_beob`.`tblBeobInfospezies`.`NO_NOTE` = `alexande_apflora`.`tblBeobZuordnung`.`NO_NOTE`))) union select '' AS `NO_NOTE`,`alexande_beob`.`tblBeobEvab`.`NO_NOTE_PROJET` AS `ID_EVAB`,`alexande_beob`.`tblBeobEvab`.`NO_ISFS` AS `NO_ISFS`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `PopGuid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPopGuid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_beob`.`tblBeobEvab`.`Projekt_ZH` AS `PROJET`,`alexande_beob`.`tblBeobEvab`.`NOM_COMMUNE` AS `NOM_COMMUNE`,`alexande_beob`.`tblBeobEvab`.`DESC_LOCALITE_` AS `DESC_LOCALITE`,`alexande_beob`.`tblBeobEvab`.`COORDONNEE_FED_E` AS `X`,`alexande_beob`.`tblBeobEvab`.`COORDONNEE_FED_N` AS `Y`,if(((`alexande_beob`.`tblBeobEvab`.`COORDONNEE_FED_E` > 0) and (`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` > 0) and (`alexande_beob`.`tblBeobEvab`.`COORDONNEE_FED_N` > 0) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` > 0)),round(sqrt((((`alexande_beob`.`tblBeobEvab`.`COORDONNEE_FED_E` - `alexande_apflora`.`tblTeilpopulation`.`TPopXKoord`) * (`alexande_beob`.`tblBeobEvab`.`COORDONNEE_FED_E` - `alexande_apflora`.`tblTeilpopulation`.`TPopXKoord`)) + ((`alexande_beob`.`tblBeobEvab`.`COORDONNEE_FED_N` - `alexande_apflora`.`tblTeilpopulation`.`TPopYKoord`) * (`alexande_beob`.`tblBeobEvab`.`COORDONNEE_FED_N` - `alexande_apflora`.`tblTeilpopulation`.`TPopYKoord`)))),0),NULL) AS `Distanz zur Teilpopulation (m)`,`alexande_beob`.`tblBeobBereitgestellt`.`Datum` AS `Datum`,`alexande_beob`.`tblBeobBereitgestellt`.`Autor` AS `Autor`,`alexande_apflora`.`tblBeobZuordnung`.`BeobNichtZuordnen` AS `BeobNichtZuordnen`,`alexande_apflora`.`tblBeobZuordnung`.`BeobBemerkungen` AS `BeobBemerkungen`,`alexande_apflora`.`tblBeobZuordnung`.`BeobMutWann` AS `BeobMutWann`,`alexande_apflora`.`tblBeobZuordnung`.`BeobMutWer` AS `BeobMutWer` from (((`alexande_beob`.`tblBeobBereitgestellt` join `alexande_beob`.`tblBeobEvab` on((`alexande_beob`.`tblBeobBereitgestellt`.`NO_NOTE_PROJET` = `alexande_beob`.`tblBeobEvab`.`NO_NOTE_PROJET`))) join (`alexande_apflora`.`tblBeobZuordnung` left join (`alexande_apflora`.`tblTeilpopulation` left join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblBeobZuordnung`.`TPopId`))) on((`alexande_beob`.`tblBeobEvab`.`NO_NOTE_PROJET` = `alexande_apflora`.`tblBeobZuordnung`.`NO_NOTE`))) join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`tblBeobEvab`.`NO_ISFS` = `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`))) order by `Artname`,`PopNr`,`TPopNr`,`Datum` desc;

-- --------------------------------------------------------

--
-- Struktur des Views `vBeobZuordnungInfospeziesArtAnzMut`
--
DROP TABLE IF EXISTS `vBeobZuordnungInfospeziesArtAnzMut`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vBeobZuordnungInfospeziesArtAnzMut` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`tblBeobZuordnung`.`BeobMutWer` AS `BeobMutWer`,`alexande_apflora`.`tblBeobZuordnung`.`BeobMutWann` AS `BeobMutWann`,count(`alexande_apflora`.`tblBeobZuordnung`.`NO_NOTE`) AS `AnzMut`,'tblBeobZuordnung_Infospezies' AS `Tabelle` from (((`alexande_apflora`.`tblAktionsplan` join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`))) join `alexande_beob`.`tblBeobInfospezies` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_beob`.`tblBeobInfospezies`.`NO_ISFS`))) join `alexande_apflora`.`tblBeobZuordnung` on((`alexande_beob`.`tblBeobInfospezies`.`NO_NOTE` = `alexande_apflora`.`tblBeobZuordnung`.`NO_NOTE`))) group by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblBeobZuordnung`.`BeobMutWer`,`alexande_apflora`.`tblBeobZuordnung`.`BeobMutWann`;

-- --------------------------------------------------------

--
-- Struktur des Views `vBer`
--
DROP TABLE IF EXISTS `vBer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vBer` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `AP Id`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Bearbeitungsstand`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `AP verantwortlich`,`alexande_apflora`.`tblBer`.`BerId` AS `Ber Id`,`alexande_apflora`.`tblBer`.`ApArtId` AS `Ber ApId`,`alexande_apflora`.`tblBer`.`BerAutor` AS `Ber Autor`,`alexande_apflora`.`tblBer`.`BerJahr` AS `Ber Jahr`,`alexande_apflora`.`tblBer`.`BerTitel` AS `Ber Titel`,`alexande_apflora`.`tblBer`.`BerURL` AS `Ber URL`,`alexande_apflora`.`tblBer`.`MutWann` AS `Ber MutWann`,`alexande_apflora`.`tblBer`.`MutWer` AS `Ber MutWer` from (`alexande_apflora`.`tblBer` left join ((((`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblBer`.`ApArtId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vBerJb`
--
DROP TABLE IF EXISTS `vBerJb`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vBerJb` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblAktionsplan`.`ApStatus` AS `ApStatus`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `ApJahr`,`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` AS `ApUmsetzung`,`alexande_apflora`.`tblAktionsplan`.`ApBearb` AS `ApBearb`,`alexande_apflora`.`tblAktionsplan`.`ApGuid` AS `ApGuid`,`alexande_apflora`.`tblAktionsplan`.`ApArtwert` AS `ApArtwert`,`alexande_apflora`.`tblAktionsplan`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblAktionsplan`.`MutWer` AS `MutWer`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`tblJBer`.`JBerId` AS `JBerId`,`alexande_apflora`.`tblJBer`.`JBerJahr` AS `JBerJahr`,`alexande_apflora`.`tblJBer`.`JBerSituation` AS `JBerSituation`,`alexande_apflora`.`tblJBer`.`JBerVergleichVorjahrGesamtziel` AS `JBerVergleichVorjahrGesamtziel`,`alexande_apflora`.`tblJBer`.`JBerBeurteilung` AS `JBerBeurteilung`,`alexande_apflora`.`tblJBer`.`JBerAnalyse` AS `JBerAnalyse`,`alexande_apflora`.`tblJBer`.`JBerUmsetzung` AS `JBerUmsetzung`,`alexande_apflora`.`tblJBer`.`JBerErfko` AS `JBerErfko`,`alexande_apflora`.`tblJBer`.`JBerATxt` AS `JBerATxt`,`alexande_apflora`.`tblJBer`.`JBerBTxt` AS `JBerBTxt`,`alexande_apflora`.`tblJBer`.`JBerCTxt` AS `JBerCTxt`,`alexande_apflora`.`tblJBer`.`JBerDTxt` AS `JBerDTxt`,`alexande_apflora`.`tblJBer`.`JBerDatum` AS `JBerDatum`,`alexande_apflora`.`tblJBer`.`JBerBearb` AS `JBerBearb`,((`alexande_apflora`.`tblAdresse`.`AdrName` & ', ') & `alexande_apflora`.`tblAdresse`.`AdrAdresse`) AS `Bearbeiter`,`alexande_apflora`.`tblJBerUebersicht`.`JbuJahr` AS `JbuJahr`,`alexande_apflora`.`tblJBerUebersicht`.`JbuBemerkungen` AS `JbuBemerkungen`,`vErsteMassnahmeProArt`.`MinvonTPopMassnJahr` AS `ErsteMassnahmeImJahr` from ((`alexande_beob`.`ArtenDb_Arteigenschaften` join (`alexande_apflora`.`tblAktionsplan` left join `vErsteMassnahmeProArt` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vErsteMassnahmeProArt`.`ApArtId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (((`alexande_apflora`.`tblJBer` left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblJBer`.`JBerBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`tblJBerUebersicht` on((`alexande_apflora`.`tblJBer`.`JBerJahr` = `alexande_apflora`.`tblJBerUebersicht`.`JbuJahr`))) join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblJBer`.`JBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`))) where (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vBerJbArtD`
--
DROP TABLE IF EXISTS `vBerJbArtD`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vBerJbArtD` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblAktionsplan`.`ApStatus` AS `ApStatus`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `ApJahr`,`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` AS `ApUmsetzung`,`alexande_apflora`.`tblAktionsplan`.`ApBearb` AS `ApBearb`,`alexande_apflora`.`tblAktionsplan`.`ApGuid` AS `ApGuid`,`alexande_apflora`.`tblAktionsplan`.`ApArtwert` AS `ApArtwert`,`alexande_apflora`.`tblAktionsplan`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblAktionsplan`.`MutWer` AS `MutWer`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`tblJBer`.`JBerId` AS `JBerId`,`alexande_apflora`.`tblJBer`.`JBerJahr` AS `JBerJahr`,`alexande_apflora`.`tblJBer`.`JBerSituation` AS `JBerSituation`,`alexande_apflora`.`tblJBer`.`JBerVergleichVorjahrGesamtziel` AS `JBerVergleichVorjahrGesamtziel`,`alexande_apflora`.`tblJBer`.`JBerBeurteilung` AS `JBerBeurteilung`,`alexande_apflora`.`tblJBer`.`JBerAnalyse` AS `JBerAnalyse`,`alexande_apflora`.`tblJBer`.`JBerUmsetzung` AS `JBerUmsetzung`,`alexande_apflora`.`tblJBer`.`JBerErfko` AS `JBerErfko`,`alexande_apflora`.`tblJBer`.`JBerATxt` AS `JBerATxt`,`alexande_apflora`.`tblJBer`.`JBerBTxt` AS `JBerBTxt`,`alexande_apflora`.`tblJBer`.`JBerCTxt` AS `JBerCTxt`,`alexande_apflora`.`tblJBer`.`JBerDTxt` AS `JBerDTxt`,`alexande_apflora`.`tblJBer`.`JBerDatum` AS `JBerDatum`,`alexande_apflora`.`tblJBer`.`JBerBearb` AS `JBerBearb`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Bearbeiter`,`alexande_apflora`.`DomainApErfKrit`.`BeurteilTxt` AS `BeurteilTxt` from ((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (((`alexande_apflora`.`tblJBer` left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblJBer`.`JBerBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainApErfKrit` on((`alexande_apflora`.`tblJBer`.`JBerBeurteilung` = `alexande_apflora`.`DomainApErfKrit`.`BeurteilId`))) join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblJBer`.`JBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`)));

-- --------------------------------------------------------

--
-- Struktur des Views `vBerJbZiel`
--
DROP TABLE IF EXISTS `vBerJbZiel`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vBerJbZiel` AS select `alexande_apflora`.`tblZiel`.`ZielId` AS `ZielId`,`alexande_apflora`.`tblZiel`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblZiel`.`ZielTyp` AS `ZielTyp`,`alexande_apflora`.`tblZiel`.`ZielJahr` AS `ZielJahr`,`alexande_apflora`.`tblZiel`.`ZielBezeichnung` AS `ZielBezeichnung`,`alexande_apflora`.`tblZiel`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblZiel`.`MutWer` AS `MutWer`,`alexande_apflora`.`DomainZielTyp`.`ZieltypTxt` AS `ZieltypTxt` from (`alexande_apflora`.`tblKonstanten` join (`alexande_apflora`.`tblZiel` join `alexande_apflora`.`DomainZielTyp` on((`alexande_apflora`.`tblZiel`.`ZielTyp` = `alexande_apflora`.`DomainZielTyp`.`ZieltypId`))) on((`alexande_apflora`.`tblKonstanten`.`JBerJahr` = `alexande_apflora`.`tblZiel`.`ZielJahr`))) where ((`alexande_apflora`.`tblZiel`.`ZielTyp` = 1) or (`alexande_apflora`.`tblZiel`.`ZielTyp` = 2) or (`alexande_apflora`.`tblZiel`.`ZielTyp` = 1170775556)) order by `alexande_apflora`.`tblZiel`.`ZielTyp`,`alexande_apflora`.`tblZiel`.`ZielBezeichnung`;

-- --------------------------------------------------------

--
-- Struktur des Views `vBerJbZielBer`
--
DROP TABLE IF EXISTS `vBerJbZielBer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vBerJbZielBer` AS select `alexande_apflora`.`tblZielBericht`.`ZielBerId` AS `ZielBerId`,`alexande_apflora`.`tblZielBericht`.`ZielId` AS `ZielId`,`alexande_apflora`.`tblZielBericht`.`ZielBerJahr` AS `ZielBerJahr`,`alexande_apflora`.`tblZielBericht`.`ZielBerErreichung` AS `ZielBerErreichung`,`alexande_apflora`.`tblZielBericht`.`ZielBerTxt` AS `ZielBerTxt`,`alexande_apflora`.`tblZielBericht`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblZielBericht`.`MutWer` AS `MutWer` from (`alexande_apflora`.`tblZielBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblZielBericht`.`ZielBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`)));

-- --------------------------------------------------------

--
-- Struktur des Views `vBerOhneAp`
--
DROP TABLE IF EXISTS `vBerOhneAp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vBerOhneAp` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `AP Id`,`alexande_apflora`.`tblBer`.`BerId` AS `Ber Id`,`alexande_apflora`.`tblBer`.`ApArtId` AS `Ber ApId`,`alexande_apflora`.`tblBer`.`BerAutor` AS `Ber Autor`,`alexande_apflora`.`tblBer`.`BerJahr` AS `Ber Jahr`,`alexande_apflora`.`tblBer`.`BerTitel` AS `Ber Titel`,`alexande_apflora`.`tblBer`.`BerURL` AS `Ber URL`,`alexande_apflora`.`tblBer`.`MutWann` AS `Ber MutWann`,`alexande_apflora`.`tblBer`.`MutWer` AS `Ber MutWer` from (`alexande_apflora`.`tblBer` left join ((((`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblBer`.`ApArtId`))) where isnull(`alexande_apflora`.`tblAktionsplan`.`ApArtId`) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vBerTPopFuerAngezeigteArt0`
--
DROP TABLE IF EXISTS `vBerTPopFuerAngezeigteArt0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vBerTPopFuerAngezeigteArt0` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `ApStatus`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `ApJahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `ApUmsetzung`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `PopHerkunft`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `PopBekanntSeit`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPopFlurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPopXKoord`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPopYKoord`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPopBekanntSeit`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPopHerkunft`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPopApBerichtRelevant` from (((((`alexande_beob`.`ArtenDb_Arteigenschaften` join ((`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`)));

-- --------------------------------------------------------

--
-- Struktur des Views `vErfKrit`
--
DROP TABLE IF EXISTS `vErfKrit`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vErfKrit` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `AP Id`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `AP verantwortlich`,`alexande_apflora`.`tblErfKrit`.`ErfkritId` AS `ErfKrit Id`,`alexande_apflora`.`tblErfKrit`.`ApArtId` AS `ErfKrit ApId`,`alexande_apflora`.`DomainApErfKrit`.`BeurteilTxt` AS `ErfKrit Beurteilung`,`alexande_apflora`.`tblErfKrit`.`ErfkritTxt` AS `ErfKrit Kriterien`,`alexande_apflora`.`tblErfKrit`.`MutWann` AS `ErfKrit MutWann`,`alexande_apflora`.`tblErfKrit`.`MutWer` AS `ErfKrit MutWer` from ((`alexande_apflora`.`tblErfKrit` left join ((((`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblErfKrit`.`ApArtId`))) left join `alexande_apflora`.`DomainApErfKrit` on((`alexande_apflora`.`tblErfKrit`.`ErfkritErreichungsgrad` = `alexande_apflora`.`DomainApErfKrit`.`BeurteilId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vErfKritOhneAp`
--
DROP TABLE IF EXISTS `vErfKritOhneAp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vErfKritOhneAp` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `AP Id`,`alexande_apflora`.`tblErfKrit`.`ErfkritId` AS `ErfKrit Id`,`alexande_apflora`.`tblErfKrit`.`ApArtId` AS `ErfKrit ApId`,`alexande_apflora`.`DomainApErfKrit`.`BeurteilTxt` AS `ErfKrit Beurteilung`,`alexande_apflora`.`tblErfKrit`.`ErfkritTxt` AS `ErfKrit Kriterien`,`alexande_apflora`.`tblErfKrit`.`MutWann` AS `ErfKrit MutWann`,`alexande_apflora`.`tblErfKrit`.`MutWer` AS `ErfKrit MutWer` from ((`alexande_apflora`.`tblErfKrit` left join ((((`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblErfKrit`.`ApArtId`))) left join `alexande_apflora`.`DomainApErfKrit` on((`alexande_apflora`.`tblErfKrit`.`ErfkritErreichungsgrad` = `alexande_apflora`.`DomainApErfKrit`.`BeurteilId`))) where isnull(`alexande_apflora`.`tblAktionsplan`.`ApArtId`) order by `alexande_apflora`.`DomainApErfKrit`.`BeurteilTxt`,`alexande_apflora`.`tblErfKrit`.`ErfkritTxt`;

-- --------------------------------------------------------

--
-- Struktur des Views `vErsteMassnahmeProArt`
--
DROP TABLE IF EXISTS `vErsteMassnahmeProArt`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vErsteMassnahmeProArt` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,min(`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr`) AS `MinvonTPopMassnJahr` from (((`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) group by `alexande_apflora`.`tblAktionsplan`.`ApArtId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vExportNachEvab_Alle`
--
DROP TABLE IF EXISTS `vExportNachEvab_Alle`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vExportNachEvab_Alle` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`GUID` AS `Projekt_Id`,concat('AP Flora ZH: ',`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`) AS `Projekt_Name`,cast(if((`alexande_apflora`.`tblAktionsplan`.`ApJahr` is not null),concat('01.01.',`alexande_apflora`.`tblAktionsplan`.`ApJahr`),'') as char charset utf8) AS `Projekt_Eröffnung`,'Topos' AS `Projekt_Autor`,cast(concat('Aktionsplan: ',`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt`,if((`alexande_apflora`.`tblAktionsplan`.`ApJahr` is not null),concat('; Start im Jahr: ',`alexande_apflora`.`tblAktionsplan`.`ApJahr`),''),if((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` is not null),concat('; Stand Umsetzung: ',`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt`),'')) as char charset utf8) AS `Projekt_Bemerkungen`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Raum_Id`,cast(concat(`alexande_apflora`.`tblPopulation`.`PopName`,if((`alexande_apflora`.`tblPopulation`.`PopNr` is not null),concat(' (Nr. ',`alexande_apflora`.`tblPopulation`.`PopNr`,')'),'')) as char charset utf8) AS `Raum_Name`,cast(if((`alexande_apflora`.`tblPopulation`.`PopHerkunft` is not null),concat('Status: ',`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt`,if((`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` is not null),concat('; Bekannt seit: ',`alexande_apflora`.`tblPopulation`.`PopBekanntSeit`),'')),'') as char charset utf8) AS `Raum_Bemerkungen`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `Ort_Id`,cast(concat(`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`,if((`alexande_apflora`.`tblTeilpopulation`.`TPopNr` is not null),concat(' (Nr. ',`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,')'),'')) as char charset utf8) AS `Ort_Name`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `Ort_ObergrenzeHöhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `Ort_X`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `Ort_Y`,'+-20m' AS `Ort_Genauigkeit`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `Ort_Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `Ort_Flurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `Ort_Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `Ort_Hangneigung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLeb` AS `Ort_Lebensraum`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLebUmg` AS `Ort_UmgebungDelarze`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`ZeitGuid` AS `Zeit_Id`,cast(if((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null),concat(`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum`,'01.01.',`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`),'') as char charset utf8) AS `Zeit_Datum`,cast(if((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null),'Tag','Jahr') as char charset utf8) AS `Zeit_GenauigkeitDatum`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMoosschicht` AS `Zeit_DeckungMoose`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKrautschicht` AS `Zeit_DeckungKräuter`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrStrauchschicht` AS `Zeit_DeckungSträucher`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBaumschicht` AS `Zeit_DeckungBäume`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGuid` AS `Beob_Id`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Beob_BeobachterinName`,`alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `Beob_NR`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Beob_WissenschArtname`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`NameDeutsch` AS `Beob_DeutscherArtname`,'Feldbeobachtung' AS `Beob_TypDerMeldung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz1` AS `Beob_Anzahl1`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` AS `Beob_Einheit1`,`alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilTxt` AS `Beob_Genauigkeit1`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz2` AS `Beob_Anzahl2`,`DomainTPopKontrZaehleinheit_1`.`ZaehleinheitTxt` AS `Beob_Einheit2`,`DomainTPopKontrMethode_1`.`BeurteilTxt` AS `Beob_Genauigkeit2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz3` AS `Beob_Anzahl3`,`DomainTPopKontrZaehleinheit_2`.`ZaehleinheitTxt` AS `Beob_Einheit3`,`DomainTPopKontrMethode_2`.`BeurteilTxt` AS `Beob_Genauigkeit3`,`DomainPopHerkunft_1`.`ZdsfHerkunft` AS `Beob_Herkunft`,`DomainPopHerkunft_1`.`ZdsfVorhanden` AS `Beob_Vorhandensein`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGefaehrdung` AS `Beob_Gefährdung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVitalitaet` AS `Beob_VitalitätPflanze`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `Beob_BeschreibungStandort` from (((((((((((((((`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) where (((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` is not null) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` is not null) and (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null) and ((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Zwischenbeurteilung') or (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle')) and (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` <> 1198167213)) or ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` is not null) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` is not null) and ((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Zwischenbeurteilung') or (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle')) and (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` <> 1198167213) and (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` is not null))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,concat(`alexande_apflora`.`tblPopulation`.`PopName`,if((`alexande_apflora`.`tblPopulation`.`PopNr` is not null),concat(' (Nr. ',`alexande_apflora`.`tblPopulation`.`PopNr`,')'),'')),concat(`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`,if((`alexande_apflora`.`tblTeilpopulation`.`TPopNr` is not null),concat(' (Nr. ',`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,')'),'')),if((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null),`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum`,concat('01.01.',`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`)),`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vExportNachEvab_Beob`
--
DROP TABLE IF EXISTS `vExportNachEvab_Beob`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vExportNachEvab_Beob` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`GUID` AS `Projekt_Id`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Raum_Id`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `Ort_Id`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`ZeitGuid` AS `Zeit_Id`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGuid` AS `Beob_Id`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Beob_BeobachterinName`,`alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `Beob_NR`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Beob_WissenschArtname`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`NameDeutsch` AS `Beob_DeutscherArtname`,'Feldbeobachtung' AS `Beob_TypDerMeldung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz1` AS `Beob_Anzahl1`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` AS `Beob_Einheit1`,`alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilTxt` AS `Beob_Genauigkeit1`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz2` AS `Beob_Anzahl2`,`DomainTPopKontrZaehleinheit_1`.`ZaehleinheitTxt` AS `Beob_Einheit2`,`DomainTPopKontrMethode_1`.`BeurteilTxt` AS `Beob_Genauigkeit2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz3` AS `Beob_Anzahl3`,`DomainTPopKontrZaehleinheit_2`.`ZaehleinheitTxt` AS `Beob_Einheit3`,`DomainTPopKontrMethode_2`.`BeurteilTxt` AS `Beob_Genauigkeit3`,`DomainPopHerkunft_1`.`ZdsfHerkunft` AS `Beob_Herkunft`,`DomainPopHerkunft_1`.`ZdsfVorhanden` AS `Beob_Vorhandensein`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGefaehrdung` AS `Beob_Gefährdung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVitalitaet` AS `Beob_VitalitätPflanze`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `Beob_BeschreibungStandort` from (((((((((((((((`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) where (((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` is not null) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` is not null)) or ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` is not null) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` is not null))) group by `alexande_beob`.`ArtenDb_Arteigenschaften`.`GUID`,`alexande_apflora`.`tblPopulation`.`PopGuid`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`ZeitGuid`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGuid`,`alexande_apflora`.`tblAdresse`.`AdrName`,`alexande_apflora`.`tblAktionsplan`.`ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`NameDeutsch`,'Feldbeobachtung',`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz1`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt`,`alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilTxt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz2`,`DomainTPopKontrZaehleinheit_1`.`ZaehleinheitTxt`,`DomainTPopKontrMethode_1`.`BeurteilTxt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz3`,`DomainTPopKontrZaehleinheit_2`.`ZaehleinheitTxt`,`DomainTPopKontrMethode_2`.`BeurteilTxt`,`DomainPopHerkunft_1`.`ZdsfHerkunft`,`DomainPopHerkunft_1`.`ZdsfVorhanden`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGefaehrdung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVitalitaet`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` having (((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null) and ((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Zwischenbeurteilung') or (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle')) and (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` <> 1198167213)) or (((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Zwischenbeurteilung') or (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle')) and (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` <> 1198167213) and (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` is not null))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vExportNachEvab_Ort`
--
DROP TABLE IF EXISTS `vExportNachEvab_Ort`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vExportNachEvab_Ort` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`GUID` AS `Projekt_Id`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Raum_Id`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `Ort_Id`,cast(concat(`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`,if((`alexande_apflora`.`tblTeilpopulation`.`TPopNr` is not null),concat(' (Nr. ',`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,')'),'')) as char charset utf8) AS `Ort_Name`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `Ort_ObergrenzeHöhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `Ort_X`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `Ort_Y`,'+-20m' AS `Ort_Genauigkeit`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `Ort_Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `Ort_Flurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `Ort_Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `Ort_Hangneigung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLeb` AS `Ort_Lebensraum`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLebUmg` AS `Ort_UmgebungDelarze` from (((((((((((((((`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) where (((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null) and ((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Zwischenbeurteilung') or (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle')) and (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` <> 1198167213)) or (((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Zwischenbeurteilung') or (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle')) and (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` <> 1198167213) and (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` is not null))) group by `alexande_beob`.`ArtenDb_Arteigenschaften`.`GUID`,`alexande_apflora`.`tblPopulation`.`PopGuid`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid`,concat(`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`,if((`alexande_apflora`.`tblTeilpopulation`.`TPopNr` is not null),concat(' (Nr. ',`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,')'),'')),`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord`,'+-20m',`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLeb`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLebUmg` having (((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` is not null) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` is not null)) or ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` is not null) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` is not null))) order by `alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vExportNachEvab_Projekt`
--
DROP TABLE IF EXISTS `vExportNachEvab_Projekt`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vExportNachEvab_Projekt` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`GUID` AS `Projekt_Id`,concat('AP Flora ZH: ',`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`) AS `Projekt_Name`,cast(if((`alexande_apflora`.`tblAktionsplan`.`ApJahr` is not null),concat('01.01.',`alexande_apflora`.`tblAktionsplan`.`ApJahr`),'') as char charset utf8) AS `Projekt_Eröffnung`,'Topos' AS `Projekt_Autor`,cast(concat('Aktionsplan: ',`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt`,if((`alexande_apflora`.`tblAktionsplan`.`ApJahr` is not null),concat('; Start im Jahr: ',`alexande_apflora`.`tblAktionsplan`.`ApJahr`),''),if((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` is not null),concat('; Stand Umsetzung: ',`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt`),''),'') as char charset utf8) AS `Projekt_Bemerkungen` from (((((((((((((((`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) where (((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null) and ((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Zwischenbeurteilung') or (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle')) and (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` <> 1198167213) and (`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` is not null) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` is not null)) or (((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Zwischenbeurteilung') or (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle')) and (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` <> 1198167213) and (`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` is not null) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` is not null) and (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` is not null))) group by `alexande_beob`.`ArtenDb_Arteigenschaften`.`GUID`,concat('AP Flora ZH: ',`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`),if((`alexande_apflora`.`tblAktionsplan`.`ApJahr` is not null),concat('01.01.',`alexande_apflora`.`tblAktionsplan`.`ApJahr`),''),'Topos',concat('Aktionsplan: ',`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt`,if((`alexande_apflora`.`tblAktionsplan`.`ApJahr` is not null),concat('; Start im Jahr: ',`alexande_apflora`.`tblAktionsplan`.`ApJahr`),''),if((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` is not null),concat('; Stand Umsetzung: ',`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt`),'')) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vExportNachEvab_Raum`
--
DROP TABLE IF EXISTS `vExportNachEvab_Raum`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vExportNachEvab_Raum` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`GUID` AS `Projekt_Id`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Raum_Id`,cast(concat(`alexande_apflora`.`tblPopulation`.`PopName`,if((`alexande_apflora`.`tblPopulation`.`PopNr` is not null),concat(' (Nr. ',`alexande_apflora`.`tblPopulation`.`PopNr`,')'),'')) as char charset utf8) AS `Raum_Name`,cast(if((`alexande_apflora`.`tblPopulation`.`PopHerkunft` is not null),concat('Status: ',`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt`,if((`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` is not null),concat('; Bekannt seit: ',`alexande_apflora`.`tblPopulation`.`PopBekanntSeit`),'')),'') as char charset utf8) AS `Raum_Bemerkungen` from (((((((((((((((`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) where (((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null) and ((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Zwischenbeurteilung') or (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle')) and (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` <> 1198167213) and (`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` is not null) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` is not null)) or (((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Zwischenbeurteilung') or (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle')) and (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` <> 1198167213) and (`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` is not null) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` is not null) and (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` is not null))) group by `alexande_beob`.`ArtenDb_Arteigenschaften`.`GUID`,`alexande_apflora`.`tblPopulation`.`PopGuid`,concat(`alexande_apflora`.`tblPopulation`.`PopName`,if((`alexande_apflora`.`tblPopulation`.`PopNr` is not null),concat(' (Nr. ',`alexande_apflora`.`tblPopulation`.`PopNr`,')'),'')),if((`alexande_apflora`.`tblPopulation`.`PopHerkunft` is not null),concat('Status: ',`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt`,if((`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` is not null),concat('; Bekannt seit: ',`alexande_apflora`.`tblPopulation`.`PopBekanntSeit`),'')),'') order by `alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`tblPopulation`.`PopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vExportNachEvab_Zeit`
--
DROP TABLE IF EXISTS `vExportNachEvab_Zeit`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vExportNachEvab_Zeit` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`GUID` AS `Projekt_Id`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Raum_Id`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `Ort_Id`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`ZeitGuid` AS `Zeit_Id`,cast(if((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null),`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum`,concat(('01.01.' + `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`))) as char charset utf8) AS `Zeit_Datum`,if((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null),'Tag','Jahr') AS `Zeit_GenauigkeitDatum`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMoosschicht` AS `Zeit_DeckungMoose`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKrautschicht` AS `Zeit_DeckungKräuter`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrStrauchschicht` AS `Zeit_DeckungSträucher`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBaumschicht` AS `Zeit_DeckungBäume` from (((((((((((((((`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) where (((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` is not null) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` is not null) and (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null) and ((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Zwischenbeurteilung') or (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle')) and (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` <> 1198167213)) or ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` is not null) and (`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` is not null) and ((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Zwischenbeurteilung') or (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle')) and (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` <> 1198167213) and (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` is not null))) group by `alexande_beob`.`ArtenDb_Arteigenschaften`.`GUID`,`alexande_apflora`.`tblPopulation`.`PopGuid`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`ZeitGuid`,if((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null),`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum`,concat(('01.01.' + `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`))),if((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null),'Tag','Jahr'),`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMoosschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKrautschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrStrauchschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBaumschicht` order by if((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` is not null),`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`);

-- --------------------------------------------------------

--
-- Struktur des Views `vFnsKef`
--
DROP TABLE IF EXISTS `vFnsKef`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vFnsKef` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `TaxonomieId`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`KefArt` = '-1'),'Ja','') AS `FnsKefArt2`,if((round(((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4),0) = ((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4)),'Ja','') AS `FnsKefKontrJahr2` from (`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblKonstanten`) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA1lPop`
--
DROP TABLE IF EXISTS `vJbA1lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA1lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA1lTPop`
--
DROP TABLE IF EXISTS `vJbA1lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA1lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA1rPop`
--
DROP TABLE IF EXISTS `vJbA1rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA1rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblAktionsplan` join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where (((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 1) or (`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 4) or (`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 8)) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA1rTPop`
--
DROP TABLE IF EXISTS `vJbA1rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA1rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblAktionsplan` join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where (((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 1) or (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 4) or (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 8)) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA2lPop`
--
DROP TABLE IF EXISTS `vJbA2lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA2lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 1) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA2lTPop`
--
DROP TABLE IF EXISTS `vJbA2lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA2lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 1) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA2rPop`
--
DROP TABLE IF EXISTS `vJbA2rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA2rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblAktionsplan` join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where (((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 1) or (`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 4)) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA2rTPop`
--
DROP TABLE IF EXISTS `vJbA2rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA2rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblAktionsplan` join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where (((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 1) or (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 4)) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA3lPop`
--
DROP TABLE IF EXISTS `vJbA3lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA3lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 8) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA3lTPop`
--
DROP TABLE IF EXISTS `vJbA3lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA3lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 8) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA3rPop`
--
DROP TABLE IF EXISTS `vJbA3rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA3rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblAktionsplan` join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where ((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 8) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA3rTPop`
--
DROP TABLE IF EXISTS `vJbA3rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA3rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblAktionsplan` join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 8) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA4lPop`
--
DROP TABLE IF EXISTS `vJbA4lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA4lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 2) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA4lTPop`
--
DROP TABLE IF EXISTS `vJbA4lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA4lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 2) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA5lPop`
--
DROP TABLE IF EXISTS `vJbA5lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA5lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 1198167213) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA5lTPop`
--
DROP TABLE IF EXISTS `vJbA5lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA5lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 1198167213) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA6lPop`
--
DROP TABLE IF EXISTS `vJbA6lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA6lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 6) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA6lTPop`
--
DROP TABLE IF EXISTS `vJbA6lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA6lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 6) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA7lPop`
--
DROP TABLE IF EXISTS `vJbA7lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA7lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 9) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA7lTPop`
--
DROP TABLE IF EXISTS `vJbA7lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA7lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 9) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA8lPop`
--
DROP TABLE IF EXISTS `vJbA8lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA8lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where (((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 4) or (`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 1200498803)) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA8lTPop`
--
DROP TABLE IF EXISTS `vJbA8lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA8lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where (((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 4) or (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 1200498803)) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA9lPop`
--
DROP TABLE IF EXISTS `vJbA9lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA9lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = 7) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbA9lTPop`
--
DROP TABLE IF EXISTS `vJbA9lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbA9lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 7) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB1lPop`
--
DROP TABLE IF EXISTS `vJbB1lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB1lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from ((`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblPopBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblPopBericht`.`PopBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB1lTPop`
--
DROP TABLE IF EXISTS `vJbB1lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB1lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join (`alexande_apflora`.`tblTeilPopBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB1rPop`
--
DROP TABLE IF EXISTS `vJbB1rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB1rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblKonstanten` join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblPopBericht` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`)))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11) and (`alexande_apflora`.`tblPopBericht`.`PopBerJahr` <= `alexande_apflora`.`tblKonstanten`.`JBerJahr`)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB1rTPop`
--
DROP TABLE IF EXISTS `vJbB1rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB1rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilPopBericht`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblKonstanten` join (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join `alexande_apflora`.`tblTeilPopBericht` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`)))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11) and (`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` <= `alexande_apflora`.`tblKonstanten`.`JBerJahr`)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilPopBericht`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB2lPop`
--
DROP TABLE IF EXISTS `vJbB2lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB2lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from ((`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblPopBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblPopBericht`.`PopBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = 3) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB2lTPop`
--
DROP TABLE IF EXISTS `vJbB2lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB2lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join (`alexande_apflora`.`tblTeilPopBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 3) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB2rPop`
--
DROP TABLE IF EXISTS `vJbB2rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB2rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (((`vLetzterPopBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterPopBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblPopBericht` on(((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`) and (`vLetzterPopBericht`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`) and (`vLetzterPopBericht`.`MaxvonPopBerJahr` = `alexande_apflora`.`tblPopBericht`.`PopBerJahr`)))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = 3) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB2rTPop`
--
DROP TABLE IF EXISTS `vJbB2rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB2rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblTeilpopulation` join (`alexande_apflora`.`tblTeilPopBericht` join (`alexande_apflora`.`tblPopulation` join `vLetzterTPopBericht` on((`alexande_apflora`.`tblPopulation`.`ApArtId` = `vLetzterTPopBericht`.`ApArtId`))) on(((`alexande_apflora`.`tblTeilPopBericht`.`TPopId` = `vLetzterTPopBericht`.`TPopId`) and (`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` = `vLetzterTPopBericht`.`MaxvonTPopBerJahr`)))) on(((`alexande_apflora`.`tblTeilpopulation`.`PopId` = `alexande_apflora`.`tblPopulation`.`PopId`) and (`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`)))) where ((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 3) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB3lPop`
--
DROP TABLE IF EXISTS `vJbB3lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB3lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from ((`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblPopBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblPopBericht`.`PopBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = 2) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB3lTPop`
--
DROP TABLE IF EXISTS `vJbB3lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB3lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join (`alexande_apflora`.`tblTeilPopBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 2) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB3rPop`
--
DROP TABLE IF EXISTS `vJbB3rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB3rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (((`vLetzterPopBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterPopBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblPopBericht` on(((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`) and (`vLetzterPopBericht`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`) and (`vLetzterPopBericht`.`MaxvonPopBerJahr` = `alexande_apflora`.`tblPopBericht`.`PopBerJahr`)))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = 2) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB3rTPop`
--
DROP TABLE IF EXISTS `vJbB3rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB3rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblTeilpopulation` join (`alexande_apflora`.`tblTeilPopBericht` join (`alexande_apflora`.`tblPopulation` join `vLetzterTPopBericht` on((`alexande_apflora`.`tblPopulation`.`ApArtId` = `vLetzterTPopBericht`.`ApArtId`))) on(((`alexande_apflora`.`tblTeilPopBericht`.`TPopId` = `vLetzterTPopBericht`.`TPopId`) and (`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` = `vLetzterTPopBericht`.`MaxvonTPopBerJahr`)))) on(((`alexande_apflora`.`tblTeilpopulation`.`PopId` = `alexande_apflora`.`tblPopulation`.`PopId`) and (`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`)))) where ((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 2) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB4lPop`
--
DROP TABLE IF EXISTS `vJbB4lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB4lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from ((`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblPopBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblPopBericht`.`PopBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = 1) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB4lTPop`
--
DROP TABLE IF EXISTS `vJbB4lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB4lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join (`alexande_apflora`.`tblTeilPopBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 1) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB4rPop`
--
DROP TABLE IF EXISTS `vJbB4rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB4rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (((`vLetzterPopBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterPopBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblPopBericht` on(((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`) and (`vLetzterPopBericht`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`) and (`vLetzterPopBericht`.`MaxvonPopBerJahr` = `alexande_apflora`.`tblPopBericht`.`PopBerJahr`)))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = 1) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB4rTPop`
--
DROP TABLE IF EXISTS `vJbB4rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB4rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblTeilpopulation` join (`alexande_apflora`.`tblTeilPopBericht` join (`alexande_apflora`.`tblPopulation` join `vLetzterTPopBericht` on((`alexande_apflora`.`tblPopulation`.`ApArtId` = `vLetzterTPopBericht`.`ApArtId`))) on(((`alexande_apflora`.`tblTeilPopBericht`.`TPopId` = `vLetzterTPopBericht`.`TPopId`) and (`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` = `vLetzterTPopBericht`.`MaxvonTPopBerJahr`)))) on(((`alexande_apflora`.`tblTeilpopulation`.`PopId` = `alexande_apflora`.`tblPopulation`.`PopId`) and (`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`)))) where ((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 1) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB5lPop`
--
DROP TABLE IF EXISTS `vJbB5lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB5lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from ((`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblPopBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblPopBericht`.`PopBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where (((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = 4) or (`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = 9)) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB5lTPop`
--
DROP TABLE IF EXISTS `vJbB5lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB5lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join (`alexande_apflora`.`tblTeilPopBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where (((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 4) or (`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 9)) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB5rPop`
--
DROP TABLE IF EXISTS `vJbB5rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB5rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (((`vLetzterPopBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterPopBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblPopBericht` on(((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`) and (`vLetzterPopBericht`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`) and (`vLetzterPopBericht`.`MaxvonPopBerJahr` = `alexande_apflora`.`tblPopBericht`.`PopBerJahr`)))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where (((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = 4) or (`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = 9)) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB5rTPop`
--
DROP TABLE IF EXISTS `vJbB5rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB5rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblTeilpopulation` join (`alexande_apflora`.`tblTeilPopBericht` join (`alexande_apflora`.`tblPopulation` join `vLetzterTPopBericht` on((`alexande_apflora`.`tblPopulation`.`ApArtId` = `vLetzterTPopBericht`.`ApArtId`))) on(((`alexande_apflora`.`tblTeilPopBericht`.`TPopId` = `vLetzterTPopBericht`.`TPopId`) and (`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` = `vLetzterTPopBericht`.`MaxvonTPopBerJahr`)))) on(((`alexande_apflora`.`tblTeilpopulation`.`PopId` = `alexande_apflora`.`tblPopulation`.`PopId`) and (`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`)))) where (((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 4) or (`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 9)) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB6lPop`
--
DROP TABLE IF EXISTS `vJbB6lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB6lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from ((`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblPopBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblPopBericht`.`PopBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = 8) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB6lTPop`
--
DROP TABLE IF EXISTS `vJbB6lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB6lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join (`alexande_apflora`.`tblTeilPopBericht` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 8) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB6rPop`
--
DROP TABLE IF EXISTS `vJbB6rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB6rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (((`vLetzterPopBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterPopBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblPopBericht` on(((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`) and (`vLetzterPopBericht`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`) and (`vLetzterPopBericht`.`MaxvonPopBerJahr` = `alexande_apflora`.`tblPopBericht`.`PopBerJahr`)))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = 8) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB6rTPop`
--
DROP TABLE IF EXISTS `vJbB6rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB6rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblTeilpopulation` join (`alexande_apflora`.`tblTeilPopBericht` join (`alexande_apflora`.`tblPopulation` join `vLetzterTPopBericht` on((`alexande_apflora`.`tblPopulation`.`ApArtId` = `vLetzterTPopBericht`.`ApArtId`))) on(((`alexande_apflora`.`tblTeilPopBericht`.`TPopId` = `vLetzterTPopBericht`.`TPopId`) and (`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` = `vLetzterTPopBericht`.`MaxvonTPopBerJahr`)))) on(((`alexande_apflora`.`tblTeilpopulation`.`PopId` = `alexande_apflora`.`tblPopulation`.`PopId`) and (`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`)))) where ((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 8) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB7lPop`
--
DROP TABLE IF EXISTS `vJbB7lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB7lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbB7lTPop`
--
DROP TABLE IF EXISTS `vJbB7lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbB7lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC1lPop`
--
DROP TABLE IF EXISTS `vJbC1lPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC1lPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join (`alexande_apflora`.`tblTeilPopMassnahme` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC1lTPop`
--
DROP TABLE IF EXISTS `vJbC1lTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC1lTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC1rPop`
--
DROP TABLE IF EXISTS `vJbC1rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC1rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from (`alexande_apflora`.`tblKonstanten` join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`)))) where ((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` <= `alexande_apflora`.`tblKonstanten`.`JBerJahr`) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC1rTPop`
--
DROP TABLE IF EXISTS `vJbC1rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC1rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblKonstanten` join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`)))) where ((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` <= `alexande_apflora`.`tblKonstanten`.`JBerJahr`) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11)) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC3rPop`
--
DROP TABLE IF EXISTS `vJbC3rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC3rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from ((`vLetzterPopMassnBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterPopMassnBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblPopMassnBericht` on(((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`) and (`vLetzterPopMassnBericht`.`MaxvonPopMassnBerJahr` = `alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr`) and (`vLetzterPopMassnBericht`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`)))) where (`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerErfolgsbeurteilung` = 1) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC3rTPop`
--
DROP TABLE IF EXISTS `vJbC3rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC3rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (((`vLetzterTPopMassnBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterTPopMassnBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilPopMassnBericht` on(((`vLetzterTPopMassnBericht`.`MaxvonTPopMassnBerJahr` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr`) and (`vLetzterTPopMassnBericht`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId`)))) join `alexande_apflora`.`tblTeilpopulation` on(((`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId` = `alexande_apflora`.`tblTeilpopulation`.`TPopId`) and (`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`)))) where (`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerErfolgsbeurteilung` = 1) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC4rPop`
--
DROP TABLE IF EXISTS `vJbC4rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC4rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from ((`vLetzterPopMassnBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterPopMassnBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblPopMassnBericht` on(((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`) and (`vLetzterPopMassnBericht`.`MaxvonPopMassnBerJahr` = `alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr`) and (`vLetzterPopMassnBericht`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`)))) where (`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerErfolgsbeurteilung` = 2) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC4rTPop`
--
DROP TABLE IF EXISTS `vJbC4rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC4rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (((`vLetzterTPopMassnBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterTPopMassnBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilPopMassnBericht` on(((`vLetzterTPopMassnBericht`.`MaxvonTPopMassnBerJahr` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr`) and (`vLetzterTPopMassnBericht`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId`)))) join `alexande_apflora`.`tblTeilpopulation` on(((`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId` = `alexande_apflora`.`tblTeilpopulation`.`TPopId`) and (`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`)))) where (`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerErfolgsbeurteilung` = 2) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC5rPop`
--
DROP TABLE IF EXISTS `vJbC5rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC5rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from ((`vLetzterPopMassnBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterPopMassnBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblPopMassnBericht` on(((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`) and (`vLetzterPopMassnBericht`.`MaxvonPopMassnBerJahr` = `alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr`) and (`vLetzterPopMassnBericht`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`)))) where (`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerErfolgsbeurteilung` = 3) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC5rTPop`
--
DROP TABLE IF EXISTS `vJbC5rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC5rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (((`vLetzterTPopMassnBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterTPopMassnBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilPopMassnBericht` on(((`vLetzterTPopMassnBericht`.`MaxvonTPopMassnBerJahr` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr`) and (`vLetzterTPopMassnBericht`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId`)))) join `alexande_apflora`.`tblTeilpopulation` on(((`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId` = `alexande_apflora`.`tblTeilpopulation`.`TPopId`) and (`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`)))) where (`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerErfolgsbeurteilung` = 3) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC6rPop`
--
DROP TABLE IF EXISTS `vJbC6rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC6rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from ((`vLetzterPopMassnBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterPopMassnBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblPopMassnBericht` on(((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`) and (`vLetzterPopMassnBericht`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`) and (`vLetzterPopMassnBericht`.`MaxvonPopMassnBerJahr` = `alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr`)))) where (`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerErfolgsbeurteilung` = 4) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC6rTPop`
--
DROP TABLE IF EXISTS `vJbC6rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC6rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (((`vLetzterTPopMassnBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterTPopMassnBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilPopMassnBericht` on(((`vLetzterTPopMassnBericht`.`MaxvonTPopMassnBerJahr` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr`) and (`vLetzterTPopMassnBericht`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId`)))) join `alexande_apflora`.`tblTeilpopulation` on(((`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId` = `alexande_apflora`.`tblTeilpopulation`.`TPopId`) and (`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`)))) where (`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerErfolgsbeurteilung` = 4) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC7rPop`
--
DROP TABLE IF EXISTS `vJbC7rPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC7rPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId` from ((`vLetzterPopMassnBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterPopMassnBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblPopMassnBericht` on(((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`) and (`vLetzterPopMassnBericht`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`) and (`vLetzterPopMassnBericht`.`MaxvonPopMassnBerJahr` = `alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr`)))) where (`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerErfolgsbeurteilung` = 5) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbC7rTPop`
--
DROP TABLE IF EXISTS `vJbC7rTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbC7rTPop` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId` from (((`vLetzterTPopMassnBericht` join `alexande_apflora`.`tblPopulation` on((`vLetzterTPopMassnBericht`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilPopMassnBericht` on(((`vLetzterTPopMassnBericht`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId`) and (`vLetzterTPopMassnBericht`.`MaxvonTPopMassnBerJahr` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr`)))) join `alexande_apflora`.`tblTeilpopulation` on(((`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId` = `alexande_apflora`.`tblTeilpopulation`.`TPopId`) and (`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`)))) where (`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerErfolgsbeurteilung` = 5) group by `alexande_apflora`.`tblPopulation`.`ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJBerOhneAp`
--
DROP TABLE IF EXISTS `vJBerOhneAp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJBerOhneAp` AS select `alexande_apflora`.`tblJBer`.`JBerId` AS `JBer Id`,`alexande_apflora`.`tblJBer`.`ApArtId` AS `JBer ApArtId`,`alexande_apflora`.`tblJBer`.`JBerJahr` AS `JBer Jahr`,`alexande_apflora`.`tblJBer`.`JBerSituation` AS `JBer Situation`,`alexande_apflora`.`tblJBer`.`JBerVergleichVorjahrGesamtziel` AS `JBer Vergleich Vorjahr-Gesamtziel`,`alexande_apflora`.`DomainApErfKrit`.`BeurteilTxt` AS `JBer Beurteilung`,`alexande_apflora`.`tblJBer`.`JBerVeraenGegenVorjahr` AS `JBer Veraend zum Vorjahr`,`alexande_apflora`.`tblJBer`.`JBerAnalyse` AS `JBer Analyse`,`alexande_apflora`.`tblJBer`.`JBerUmsetzung` AS `JBer Konsequenzen Umsetzung`,`alexande_apflora`.`tblJBer`.`JBerErfko` AS `JBer Konsequenzen Erfolgskontrolle`,`alexande_apflora`.`tblJBer`.`JBerATxt` AS `JBer Bemerkungen zu A`,`alexande_apflora`.`tblJBer`.`JBerBTxt` AS `JBer Bemerkungen zu B`,`alexande_apflora`.`tblJBer`.`JBerCTxt` AS `JBer Bemerkungen zu C`,`alexande_apflora`.`tblJBer`.`JBerDTxt` AS `JBer Bemerkungen zu D`,`alexande_apflora`.`tblJBer`.`JBerDatum` AS `JBer Datum`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `JBer BearbeiterIn`,`alexande_apflora`.`tblJBer`.`MutWann` AS `JBer MutWann`,`alexande_apflora`.`tblJBer`.`MutWer` AS `JBer MutWer` from (((`alexande_apflora`.`tblJBer` left join `alexande_apflora`.`tblAktionsplan` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblJBer`.`JBerBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainApErfKrit` on((`alexande_apflora`.`tblJBer`.`JBerBeurteilung` = `alexande_apflora`.`DomainApErfKrit`.`BeurteilId`))) where isnull(`alexande_apflora`.`tblAktionsplan`.`ApArtId`) order by `alexande_apflora`.`tblJBer`.`ApArtId`,`alexande_apflora`.`tblJBer`.`JBerJahr`,`alexande_apflora`.`tblJBer`.`JBerDatum`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUebE`
--
DROP TABLE IF EXISTS `vJbUebE`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUebE` AS select `alexande_apflora`.`tblJBer`.`JBerId` AS `JBerId`,`alexande_apflora`.`tblJBer`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblJBer`.`JBerJahr` AS `JBerJahr`,`alexande_apflora`.`tblJBer`.`JBerSituation` AS `JBerSituation`,`alexande_apflora`.`tblJBer`.`JBerVergleichVorjahrGesamtziel` AS `JBerVergleichVorjahrGesamtziel`,`alexande_apflora`.`tblJBer`.`JBerBeurteilung` AS `JBerBeurteilung`,`alexande_apflora`.`tblJBer`.`JBerVeraenGegenVorjahr` AS `JBerVeraenGegenVorjahr`,`alexande_apflora`.`tblJBer`.`JBerAnalyse` AS `JBerAnalyse`,`alexande_apflora`.`tblJBer`.`JBerUmsetzung` AS `JBerUmsetzung`,`alexande_apflora`.`tblJBer`.`JBerErfko` AS `JBerErfko`,`alexande_apflora`.`tblJBer`.`JBerATxt` AS `JBerATxt`,`alexande_apflora`.`tblJBer`.`JBerBTxt` AS `JBerBTxt`,`alexande_apflora`.`tblJBer`.`JBerCTxt` AS `JBerCTxt`,`alexande_apflora`.`tblJBer`.`JBerDTxt` AS `JBerDTxt`,`alexande_apflora`.`tblJBer`.`JBerDatum` AS `JBerDatum`,`alexande_apflora`.`tblJBer`.`JBerBearb` AS `JBerBearb`,`alexande_apflora`.`tblJBer`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblJBer`.`MutWer` AS `MutWer`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`KefArt` = -(1)),'Ja','') AS `FnsKefArt2`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr` AS `KefKontrolljahr`,if((round(((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4),0) = ((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4)),'Ja','') AS `FnsKefKontrJahr2`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` AS `FnsJahrespflanze`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` > 0),'Ja','') AS `FnsJahrespflanze2`,`vApAnzMassnBisJahr`.`AnzahlMassnahmen` AS `AnzahlMassnahmen` from (`alexande_apflora`.`tblKonstanten` `tblKonstanten_1` join ((`alexande_beob`.`ArtenDb_Arteigenschaften` join (`alexande_apflora`.`tblAktionsplan` join `vApApBerichtRelevant` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApApBerichtRelevant`.`ApArtId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblKonstanten` join (`alexande_apflora`.`tblJBer` join `vApAnzMassnBisJahr` on((`alexande_apflora`.`tblJBer`.`ApArtId` = `vApAnzMassnBisJahr`.`ApArtId`))) on((`alexande_apflora`.`tblKonstanten`.`JBerJahr` = `alexande_apflora`.`tblJBer`.`JBerJahr`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`))) on((`tblKonstanten_1`.`JBerJahr` = `vApAnzMassnBisJahr`.`TPopMassnJahr`))) where ((`vApAnzMassnBisJahr`.`AnzahlMassnahmen` > 0) and (`alexande_apflora`.`tblJBer`.`JBerBeurteilung` = 1) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUebKm`
--
DROP TABLE IF EXISTS `vJbUebKm`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUebKm` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`KefArt` = -(1)),'Ja','') AS `FnsKefArt2`,if((round(((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4),0) = ((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4)),'Ja','') AS `FnsKefKontrJahr2`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` AS `FnsJahrespflanze`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` > 0),'Ja','') AS `FnsJahrespflanze2` from ((`alexande_beob`.`ArtenDb_Arteigenschaften` join ((`vApAnzMassnBisJahr` `vApAnzMassnBisJahr_1` join `alexande_apflora`.`tblAktionsplan` on((`vApAnzMassnBisJahr_1`.`ApArtId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `vApApBerichtRelevant` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApApBerichtRelevant`.`ApArtId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblJBer` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblJBer`.`JBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on(((`alexande_apflora`.`tblKonstanten`.`JBerJahr` = `vApAnzMassnBisJahr_1`.`TPopMassnJahr`) and (`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`)))) where ((`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) and (`vApAnzMassnBisJahr_1`.`AnzahlMassnahmen` = '0')) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUebMa`
--
DROP TABLE IF EXISTS `vJbUebMa`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUebMa` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,`vApAnzMassnBisJahr`.`AnzahlMassnahmen` AS `AnzahlMassnahmen` from (`alexande_apflora`.`tblKonstanten` join ((`alexande_beob`.`ArtenDb_Arteigenschaften` join (`alexande_apflora`.`tblAktionsplan` join `vApApBerichtRelevant` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApApBerichtRelevant`.`ApArtId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `vApAnzMassnBisJahr` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApAnzMassnBisJahr`.`ApArtId`))) on((`alexande_apflora`.`tblKonstanten`.`JBerJahr` = `vApAnzMassnBisJahr`.`TPopMassnJahr`))) where ((`vApAnzMassnBisJahr`.`AnzahlMassnahmen` > 0) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUebMe`
--
DROP TABLE IF EXISTS `vJbUebMe`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUebMe` AS select `alexande_apflora`.`tblJBer`.`JBerId` AS `JBerId`,`alexande_apflora`.`tblJBer`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblJBer`.`JBerJahr` AS `JBerJahr`,`alexande_apflora`.`tblJBer`.`JBerSituation` AS `JBerSituation`,`alexande_apflora`.`tblJBer`.`JBerVergleichVorjahrGesamtziel` AS `JBerVergleichVorjahrGesamtziel`,`alexande_apflora`.`tblJBer`.`JBerBeurteilung` AS `JBerBeurteilung`,`alexande_apflora`.`tblJBer`.`JBerVeraenGegenVorjahr` AS `JBerVeraenGegenVorjahr`,`alexande_apflora`.`tblJBer`.`JBerAnalyse` AS `JBerAnalyse`,`alexande_apflora`.`tblJBer`.`JBerUmsetzung` AS `JBerUmsetzung`,`alexande_apflora`.`tblJBer`.`JBerErfko` AS `JBerErfko`,`alexande_apflora`.`tblJBer`.`JBerATxt` AS `JBerATxt`,`alexande_apflora`.`tblJBer`.`JBerBTxt` AS `JBerBTxt`,`alexande_apflora`.`tblJBer`.`JBerCTxt` AS `JBerCTxt`,`alexande_apflora`.`tblJBer`.`JBerDTxt` AS `JBerDTxt`,`alexande_apflora`.`tblJBer`.`JBerDatum` AS `JBerDatum`,`alexande_apflora`.`tblJBer`.`JBerBearb` AS `JBerBearb`,`alexande_apflora`.`tblJBer`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblJBer`.`MutWer` AS `MutWer`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,if(('KefArt' = -(1)),'Ja','') AS `FnsKefArt2`,if((round(((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - 'KefKontrolljahr') / 4),0) = ((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - 'KefKontrolljahr') / 4)),'Ja','') AS `FnsKefKontrJahr2`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` AS `FnsJahrespflanze`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` > 0),'Ja','') AS `FnsJahrespflanze2` from (`alexande_apflora`.`tblKonstanten` `tblKonstanten_1` join ((`alexande_beob`.`ArtenDb_Arteigenschaften` join (`alexande_apflora`.`tblAktionsplan` join `vApApBerichtRelevant` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApApBerichtRelevant`.`ApArtId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblJBer` join `vApAnzMassnBisJahr` on((`alexande_apflora`.`tblJBer`.`ApArtId` = `vApAnzMassnBisJahr`.`ApArtId`))) join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblJBer`.`JBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`))) on((`tblKonstanten_1`.`JBerJahr` = `vApAnzMassnBisJahr`.`TPopMassnJahr`))) where ((`alexande_apflora`.`tblJBer`.`JBerBeurteilung` = 5) and (`vApAnzMassnBisJahr`.`AnzahlMassnahmen` > 0) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUebNe`
--
DROP TABLE IF EXISTS `vJbUebNe`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUebNe` AS select `alexande_apflora`.`tblJBer`.`JBerId` AS `JBerId`,`alexande_apflora`.`tblJBer`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblJBer`.`JBerJahr` AS `JBerJahr`,`alexande_apflora`.`tblJBer`.`JBerSituation` AS `JBerSituation`,`alexande_apflora`.`tblJBer`.`JBerVergleichVorjahrGesamtziel` AS `JBerVergleichVorjahrGesamtziel`,`alexande_apflora`.`tblJBer`.`JBerBeurteilung` AS `JBerBeurteilung`,`alexande_apflora`.`tblJBer`.`JBerVeraenGegenVorjahr` AS `JBerVeraenGegenVorjahr`,`alexande_apflora`.`tblJBer`.`JBerAnalyse` AS `JBerAnalyse`,`alexande_apflora`.`tblJBer`.`JBerUmsetzung` AS `JBerUmsetzung`,`alexande_apflora`.`tblJBer`.`JBerErfko` AS `JBerErfko`,`alexande_apflora`.`tblJBer`.`JBerATxt` AS `JBerATxt`,`alexande_apflora`.`tblJBer`.`JBerBTxt` AS `JBerBTxt`,`alexande_apflora`.`tblJBer`.`JBerCTxt` AS `JBerCTxt`,`alexande_apflora`.`tblJBer`.`JBerDTxt` AS `JBerDTxt`,`alexande_apflora`.`tblJBer`.`JBerDatum` AS `JBerDatum`,`alexande_apflora`.`tblJBer`.`JBerBearb` AS `JBerBearb`,`alexande_apflora`.`tblJBer`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblJBer`.`MutWer` AS `MutWer`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`KefArt` = -(1)),'Ja','') AS `FnsKefArt2`,if((round(((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4),0) = ((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4)),'Ja','') AS `FnsKefKontrJahr2`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` AS `FnsJahrespflanze`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` > 0),'Ja','') AS `FnsJahrespflanze2` from (`alexande_apflora`.`tblKonstanten` `tblKonstanten_1` join ((`alexande_beob`.`ArtenDb_Arteigenschaften` join (`alexande_apflora`.`tblAktionsplan` join `vApApBerichtRelevant` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApApBerichtRelevant`.`ApArtId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblJBer` join `vApAnzMassnBisJahr` on((`alexande_apflora`.`tblJBer`.`ApArtId` = `vApAnzMassnBisJahr`.`ApArtId`))) join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblJBer`.`JBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`))) on((`tblKonstanten_1`.`JBerJahr` = `vApAnzMassnBisJahr`.`TPopMassnJahr`))) where ((`alexande_apflora`.`tblJBer`.`JBerBeurteilung` = 3) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) and (`vApAnzMassnBisJahr`.`AnzahlMassnahmen` > 0)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUebNichtBeurteilt`
--
DROP TABLE IF EXISTS `vJbUebNichtBeurteilt`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUebNichtBeurteilt` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,`vFnsKef`.`FnsKefArt2` AS `FnsKefArt2`,`vFnsKef`.`FnsKefKontrJahr2` AS `FnsKefKontrJahr2`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` AS `FnsJahrespflanze`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` > 0),'Ja','') AS `FnsJahrespflanze2` from (((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `vFnsKef` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vFnsKef`.`TaxonomieId`))) join `vJbUebNichtBeurteilt0` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vJbUebNichtBeurteilt0`.`ApArtId`))) where (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUebNichtBeurteilt0`
--
DROP TABLE IF EXISTS `vJbUebNichtBeurteilt0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUebNichtBeurteilt0` AS select `vJbUebNichtBeurteilt000`.`ApArtId` AS `ApArtId` from `vJbUebNichtBeurteilt000` union select `vJbUebNichtBeurteilt00`.`ApArtId` AS `ApArtId` from `vJbUebNichtBeurteilt00`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUebNichtBeurteilt00`
--
DROP TABLE IF EXISTS `vJbUebNichtBeurteilt00`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUebNichtBeurteilt00` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId` from (`alexande_apflora`.`tblKonstanten` `tblKonstanten_1` join (((`alexande_apflora`.`tblAktionsplan` join `vApAnzMassnBisJahr` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApAnzMassnBisJahr`.`ApArtId`))) join `vApApBerichtRelevant` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApApBerichtRelevant`.`ApArtId`))) join (`alexande_apflora`.`tblJBer` join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblJBer`.`JBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`))) on((`tblKonstanten_1`.`JBerJahr` = `vApAnzMassnBisJahr`.`TPopMassnJahr`))) where ((`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) and isnull(`alexande_apflora`.`tblJBer`.`JBerBeurteilung`));

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUebNichtBeurteilt000`
--
DROP TABLE IF EXISTS `vJbUebNichtBeurteilt000`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUebNichtBeurteilt000` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId` from ((((`alexande_apflora`.`tblAktionsplan` join `vApAnzMassnBisJahr` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApAnzMassnBisJahr`.`ApArtId`))) join `vApApBerichtRelevant` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApApBerichtRelevant`.`ApArtId`))) left join `alexande_apflora`.`tblJBer` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`))) join `alexande_apflora`.`tblKonstanten` on((`vApAnzMassnBisJahr`.`TPopMassnJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) where (isnull(`alexande_apflora`.`tblJBer`.`ApArtId`) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3));

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUebSe`
--
DROP TABLE IF EXISTS `vJbUebSe`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUebSe` AS select `alexande_apflora`.`tblJBer`.`JBerId` AS `JBerId`,`alexande_apflora`.`tblJBer`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblJBer`.`JBerJahr` AS `JBerJahr`,`alexande_apflora`.`tblJBer`.`JBerSituation` AS `JBerSituation`,`alexande_apflora`.`tblJBer`.`JBerVergleichVorjahrGesamtziel` AS `JBerVergleichVorjahrGesamtziel`,`alexande_apflora`.`tblJBer`.`JBerBeurteilung` AS `JBerBeurteilung`,`alexande_apflora`.`tblJBer`.`JBerVeraenGegenVorjahr` AS `JBerVeraenGegenVorjahr`,`alexande_apflora`.`tblJBer`.`JBerAnalyse` AS `JBerAnalyse`,`alexande_apflora`.`tblJBer`.`JBerUmsetzung` AS `JBerUmsetzung`,`alexande_apflora`.`tblJBer`.`JBerErfko` AS `JBerErfko`,`alexande_apflora`.`tblJBer`.`JBerATxt` AS `JBerATxt`,`alexande_apflora`.`tblJBer`.`JBerBTxt` AS `JBerBTxt`,`alexande_apflora`.`tblJBer`.`JBerCTxt` AS `JBerCTxt`,`alexande_apflora`.`tblJBer`.`JBerDTxt` AS `JBerDTxt`,`alexande_apflora`.`tblJBer`.`JBerDatum` AS `JBerDatum`,`alexande_apflora`.`tblJBer`.`JBerBearb` AS `JBerBearb`,`alexande_apflora`.`tblJBer`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblJBer`.`MutWer` AS `MutWer`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`KefArt` = -(1)),'Ja','') AS `FnsKefArt2`,if((round(((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4),0) = ((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4)),'Ja','') AS `FnsKefKontrJahr2`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` AS `FnsJahrespflanze`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` > 0),'Ja','') AS `FnsJahrespflanze2` from (`alexande_apflora`.`tblKonstanten` `tblKonstanten_1` join ((`alexande_beob`.`ArtenDb_Arteigenschaften` join (`alexande_apflora`.`tblAktionsplan` join `vApApBerichtRelevant` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApApBerichtRelevant`.`ApArtId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblJBer` join `vApAnzMassnBisJahr` on((`alexande_apflora`.`tblJBer`.`ApArtId` = `vApAnzMassnBisJahr`.`ApArtId`))) join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblJBer`.`JBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`))) on((`tblKonstanten_1`.`JBerJahr` = `vApAnzMassnBisJahr`.`TPopMassnJahr`))) where ((`alexande_apflora`.`tblJBer`.`JBerBeurteilung` = 4) and (`vApAnzMassnBisJahr`.`AnzahlMassnahmen` > 0) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUebUn`
--
DROP TABLE IF EXISTS `vJbUebUn`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUebUn` AS select `alexande_apflora`.`tblJBer`.`JBerId` AS `JBerId`,`alexande_apflora`.`tblJBer`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblJBer`.`JBerJahr` AS `JBerJahr`,`alexande_apflora`.`tblJBer`.`JBerSituation` AS `JBerSituation`,`alexande_apflora`.`tblJBer`.`JBerVergleichVorjahrGesamtziel` AS `JBerVergleichVorjahrGesamtziel`,`alexande_apflora`.`tblJBer`.`JBerBeurteilung` AS `JBerBeurteilung`,`alexande_apflora`.`tblJBer`.`JBerVeraenGegenVorjahr` AS `JBerVeraenGegenVorjahr`,`alexande_apflora`.`tblJBer`.`JBerAnalyse` AS `JBerAnalyse`,`alexande_apflora`.`tblJBer`.`JBerUmsetzung` AS `JBerUmsetzung`,`alexande_apflora`.`tblJBer`.`JBerErfko` AS `JBerErfko`,`alexande_apflora`.`tblJBer`.`JBerATxt` AS `JBerATxt`,`alexande_apflora`.`tblJBer`.`JBerBTxt` AS `JBerBTxt`,`alexande_apflora`.`tblJBer`.`JBerCTxt` AS `JBerCTxt`,`alexande_apflora`.`tblJBer`.`JBerDTxt` AS `JBerDTxt`,`alexande_apflora`.`tblJBer`.`JBerDatum` AS `JBerDatum`,`alexande_apflora`.`tblJBer`.`JBerBearb` AS `JBerBearb`,`alexande_apflora`.`tblJBer`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblJBer`.`MutWer` AS `MutWer`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`KefArt` = -(1)),'Ja','') AS `FnsKefArt2`,if((round(((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4),0) = ((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4)),'Ja','') AS `FnsKefKontrJahr2`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` AS `FnsJahrespflanze`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` > 0),'Ja','') AS `FnsJahrespflanze2` from (`alexande_apflora`.`tblKonstanten` `tblKonstanten_1` join ((`alexande_beob`.`ArtenDb_Arteigenschaften` join (`alexande_apflora`.`tblAktionsplan` join `vApApBerichtRelevant` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApApBerichtRelevant`.`ApArtId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblJBer` join `vApAnzMassnBisJahr` on((`alexande_apflora`.`tblJBer`.`ApArtId` = `vApAnzMassnBisJahr`.`ApArtId`))) join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblJBer`.`JBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`))) on((`tblKonstanten_1`.`JBerJahr` = `vApAnzMassnBisJahr`.`TPopMassnJahr`))) where ((`alexande_apflora`.`tblJBer`.`JBerBeurteilung` = 1168274204) and (`vApAnzMassnBisJahr`.`AnzahlMassnahmen` > 0) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUebWe`
--
DROP TABLE IF EXISTS `vJbUebWe`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUebWe` AS select `alexande_apflora`.`tblJBer`.`JBerId` AS `JBerId`,`alexande_apflora`.`tblJBer`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblJBer`.`JBerJahr` AS `JBerJahr`,`alexande_apflora`.`tblJBer`.`JBerSituation` AS `JBerSituation`,`alexande_apflora`.`tblJBer`.`JBerVergleichVorjahrGesamtziel` AS `JBerVergleichVorjahrGesamtziel`,`alexande_apflora`.`tblJBer`.`JBerBeurteilung` AS `JBerBeurteilung`,`alexande_apflora`.`tblJBer`.`JBerVeraenGegenVorjahr` AS `JBerVeraenGegenVorjahr`,`alexande_apflora`.`tblJBer`.`JBerAnalyse` AS `JBerAnalyse`,`alexande_apflora`.`tblJBer`.`JBerUmsetzung` AS `JBerUmsetzung`,`alexande_apflora`.`tblJBer`.`JBerErfko` AS `JBerErfko`,`alexande_apflora`.`tblJBer`.`JBerATxt` AS `JBerATxt`,`alexande_apflora`.`tblJBer`.`JBerBTxt` AS `JBerBTxt`,`alexande_apflora`.`tblJBer`.`JBerCTxt` AS `JBerCTxt`,`alexande_apflora`.`tblJBer`.`JBerDTxt` AS `JBerDTxt`,`alexande_apflora`.`tblJBer`.`JBerDatum` AS `JBerDatum`,`alexande_apflora`.`tblJBer`.`JBerBearb` AS `JBerBearb`,`alexande_apflora`.`tblJBer`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblJBer`.`MutWer` AS `MutWer`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`KefArt` = -(1)),'Ja','') AS `FnsKefArt2`,if((round(((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4),0) = ((`alexande_apflora`.`tblKonstanten`.`JBerJahr` - `alexande_beob`.`ArtenDb_Arteigenschaften`.`KefKontrolljahr`) / 4)),'Ja','') AS `FnsKefKontrJahr2`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` AS `FnsJahrespflanze`,if((`alexande_beob`.`ArtenDb_Arteigenschaften`.`FnsJahresartJahr` > 0),'Ja','') AS `FnsJahrespflanze2` from (`alexande_apflora`.`tblKonstanten` `tblKonstanten_1` join ((`alexande_beob`.`ArtenDb_Arteigenschaften` join (`alexande_apflora`.`tblAktionsplan` join `vApApBerichtRelevant` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApApBerichtRelevant`.`ApArtId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblJBer` join `vApAnzMassnBisJahr` on((`alexande_apflora`.`tblJBer`.`ApArtId` = `vApAnzMassnBisJahr`.`ApArtId`))) join `alexande_apflora`.`tblKonstanten` on((`alexande_apflora`.`tblJBer`.`JBerJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblJBer`.`ApArtId`))) on((`tblKonstanten_1`.`JBerJahr` = `vApAnzMassnBisJahr`.`TPopMassnJahr`))) where ((`alexande_apflora`.`tblJBer`.`JBerBeurteilung` = 6) and (`vApAnzMassnBisJahr`.`AnzahlMassnahmen` > 0) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vJbUeT01`
--
DROP TABLE IF EXISTS `vJbUeT01`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vJbUeT01` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname` from (((`alexande_beob`.`ArtenDb_Arteigenschaften` join (`alexande_apflora`.`tblAktionsplan` join `vApApBerichtRelevant` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApApBerichtRelevant`.`ApArtId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `vApAnzMassnBisJahr` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `vApAnzMassnBisJahr`.`ApArtId`))) join `alexande_apflora`.`tblKonstanten` on((`vApAnzMassnBisJahr`.`TPopMassnJahr` = `alexande_apflora`.`tblKonstanten`.`JBerJahr`))) where ((`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) and (`vApAnzMassnBisJahr`.`AnzahlMassnahmen` > '0')) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vKontr`
--
DROP TABLE IF EXISTS `vKontr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vKontr` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`tblAdresse_1`.`AdrName` AS `AP verantwortlich`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Herkunft`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPop X-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius m`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`tblAdresse_2`.`AdrName` AS `TPop verantwortlich`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGuid` AS `Kontr Guid`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` AS `Kontr Jahr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` AS `Kontr Datum`,`alexande_apflora`.`DomainTPopFeldkontrTyp`.`DomainTxt` AS `Kontr Typ`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Kontr BearbeiterIn`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` AS `Kontr Zaehleinheit 1`,`alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilTxt` AS `Kontr Methode 1`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz1` AS `Kontr Anzahl 1`,`DomainTPopKontrZaehleinheit_1`.`ZaehleinheitTxt` AS `Kontr Zaehleinheit 2`,`DomainTPopKontrMethode_2`.`BeurteilTxt` AS `Kontr Methode 2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz2` AS `Kontr Anzahl 2`,`DomainTPopKontrZaehleinheit_2`.`ZaehleinheitTxt` AS `Kontr Zaehleinheit 3`,`DomainTPopKontrMethode_1`.`BeurteilTxt` AS `Kontr Methode 3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz3` AS `Kontr Anzahl 3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUeberleb` AS `Kontr Ueberlebensrate`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVitalitaet` AS `Kontr Vitalitaet`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt` AS `Kontr Entwicklung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrsach` AS `Kontr Ursachen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrteil` AS `Kontr Erfolgsbeurteilung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendUms` AS `Kontr Aend-Vorschlaege Umsetzung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendKontr` AS `Kontr Aend-Vorschlaege Kontrolle`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `Kontr X-Koord`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `Kontr Y-Koord`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTxt` AS `Kontr Bemerkungen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLeb` AS `Kontr Lebensraum Delarze`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLebUmg` AS `Kontr angrenzender Lebensraum Delarze`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegTyp` AS `Kontr Vegetationstyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKonkurrenz` AS `Kontr Konkurrenz`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMoosschicht` AS `Kontr Moosschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKrautschicht` AS `Kontr Krautschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrStrauchschicht` AS `Kontr Strauchschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBaumschicht` AS `Kontr Baumschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenTyp` AS `Kontr Bodentyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenKalkgehalt` AS `Kontr Boden Kalkgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenDurchlaessigkeit` AS `Kontr Boden Durchlaessigkeit`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenHumus` AS `Kontr Boden Hmusgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenNaehrstoffgehalt` AS `Kontr Boden Naehrstoffgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenAbtrag` AS `Kontr Oberbodenabtrag`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrWasserhaushalt` AS `Kontr Wasserhaushalt`,`alexande_apflora`.`DomainTPopKontrIdBiotUebereinst`.`DomainTxt` AS `TPopKontrIdealBiotopUebereinst`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrHandlungsbedarf` AS `TPopKontrHandlungsbedarf`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebFlaeche` AS `TPopKontrUebFlaeche`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrFlaeche` AS `Kontr Flaeche m2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrPlan` AS `Kontr auf Plan eingezeichnet`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVeg` AS `Kontr Deckung durch Vegetation`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrNaBo` AS `Kontr Deckung nackter Boden`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebPfl` AS `Kontr Deckung durch ueberpruefte Art`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJungPflJN` AS `Kontr auch junge Pflanzen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMax` AS `Kontr maximale Veg-hoehe cm`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMit` AS `Kontr mittlere Veg-hoehe cm`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGefaehrdung` AS `Kontr Gefaehrdung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`MutWer` AS `MutWer` from ((((((((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join ((((((`alexande_apflora`.`tblTeilPopFeldkontrolle` left join `alexande_apflora`.`DomainTPopFeldkontrTyp` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = `alexande_apflora`.`DomainTPopFeldkontrTyp`.`DomainTxt`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainPopEntwicklung` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrEntwicklung` = `alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungId`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrIdBiotUebereinst` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrIdealBiotopUebereinst` = `alexande_apflora`.`DomainTPopKontrIdBiotUebereinst`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` `tblAdresse_1` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `tblAdresse_1`.`AdrId`))) left join `alexande_apflora`.`tblAdresse` `tblAdresse_2` on((`tblAdresse_2`.`AdrId` = `alexande_apflora`.`tblTeilpopulation`.`TPopVerantw`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`DomainPopHerkunft_1`.`HerkunftId` = `alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vKontrAnzProZaehleinheit`
--
DROP TABLE IF EXISTS `vKontrAnzProZaehleinheit`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vKontrAnzProZaehleinheit` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`tblAdresse_1`.`AdrName` AS `AP verantwortlich`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Herkunft`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPop X-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius m`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`tblAdresse_2`.`AdrName` AS `TPop verantwortlich`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Herkunft`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGuid` AS `Kontr Guid`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` AS `Kontr Jahr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` AS `Kontr Datum`,`alexande_apflora`.`DomainTPopFeldkontrTyp`.`DomainTxt` AS `Kontr Typ`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Kontr BearbeiterIn`,`vKontrAnzProZaehleinheit0`.`TPopKontrZaehleinheit` AS `Kontr Zaehleinheit`,`vKontrAnzProZaehleinheit0`.`TPopKontrAnz` AS `Kontr Anzahl`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUeberleb` AS `Kontr Ueberlebensrate`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVitalitaet` AS `Kontr Vitalitaet`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt` AS `Kontr Entwicklung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrsach` AS `Kontr Ursachen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrteil` AS `Kontr Erfolgsbeurteilung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendUms` AS `Kontr Aend-Vorschlaege Umsetzung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendKontr` AS `Kontr Aend-Vorschlaege Kontrolle`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `Kontr X-Koord`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `Kontr Y-Koord`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTxt` AS `Kontr Bemerkungen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLeb` AS `Kontr Lebensraum Delarze`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLebUmg` AS `Kontr angrenzender Lebensraum Delarze`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegTyp` AS `Kontr Vegetationstyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKonkurrenz` AS `Kontr Konkurrenz`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMoosschicht` AS `Kontr Moosschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKrautschicht` AS `Kontr Krautschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrStrauchschicht` AS `Kontr Strauchschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBaumschicht` AS `Kontr Baumschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenTyp` AS `Kontr Bodentyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenKalkgehalt` AS `Kontr Boden Kalkgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenDurchlaessigkeit` AS `Kontr Boden Durchlaessigkeit`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenHumus` AS `Kontr Boden Hmusgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenNaehrstoffgehalt` AS `Kontr Boden Naehrstoffgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenAbtrag` AS `Kontr Oberbodenabtrag`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrWasserhaushalt` AS `Kontr Wasserhaushalt`,`alexande_apflora`.`DomainTPopKontrIdBiotUebereinst`.`DomainTxt` AS `TPopKontrIdealBiotopUebereinst`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrHandlungsbedarf` AS `TPopKontrHandlungsbedarf`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebFlaeche` AS `TPopKontrUebFlaeche`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrFlaeche` AS `Kontr Flaeche m2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrPlan` AS `Kontr auf Plan eingezeichnet`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVeg` AS `Kontr Deckung durch Vegetation`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrNaBo` AS `Kontr Deckung nackter Boden`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebPfl` AS `Kontr Deckung durch ueberpruefte Art`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJungPflJN` AS `Kontr auch junge Pflanzen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMax` AS `Kontr maximale Veg-hoehe cm`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMit` AS `Kontr mittlere Veg-hoehe cm`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGefaehrdung` AS `Kontr Gefaehrdung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`MutWer` AS `MutWer` from (((((((((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join ((((((`alexande_apflora`.`tblTeilPopFeldkontrolle` left join `alexande_apflora`.`DomainTPopFeldkontrTyp` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = `alexande_apflora`.`DomainTPopFeldkontrTyp`.`DomainTxt`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainPopEntwicklung` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrEntwicklung` = `alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungId`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrIdBiotUebereinst` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrIdealBiotopUebereinst` = `alexande_apflora`.`DomainTPopKontrIdBiotUebereinst`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` `tblAdresse_1` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `tblAdresse_1`.`AdrId`))) left join `alexande_apflora`.`tblAdresse` `tblAdresse_2` on((`tblAdresse_2`.`AdrId` = `alexande_apflora`.`tblTeilpopulation`.`TPopVerantw`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`DomainPopHerkunft_1`.`HerkunftId` = `alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft`))) join `vKontrAnzProZaehleinheit0` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId` = `vKontrAnzProZaehleinheit0`.`TPopKontrId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vKontrAnzProZaehleinheit0`
--
DROP TABLE IF EXISTS `vKontrAnzProZaehleinheit0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vKontrAnzProZaehleinheit0` AS select `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId` AS `TPopKontrId`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` AS `TPopKontrZaehleinheit`,count(`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz1`) AS `TPopKontrAnz` from (`alexande_apflora`.`tblTeilPopFeldkontrolle` join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) group by `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` union select `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId` AS `TPopKontrId`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` AS `TPopKontrZaehleinheit`,count(`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz2`) AS `TPopKontrAnz` from (`alexande_apflora`.`tblTeilPopFeldkontrolle` join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) group by `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` union select `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId` AS `TPopKontrId`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` AS `TPopKontrZaehleinheit`,count(`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz3`) AS `TPopKontrAnz` from (`alexande_apflora`.`tblTeilPopFeldkontrolle` join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) group by `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` order by `TPopKontrId`,`TPopKontrZaehleinheit`;

-- --------------------------------------------------------

--
-- Struktur des Views `vKontrApArtTPopOhneStatus`
--
DROP TABLE IF EXISTS `vKontrApArtTPopOhneStatus`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vKontrApArtTPopOhneStatus` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `Bearbeitungsstand AP`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Status Population`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPopFlurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` AS `Status Teilpopulation` from ((`alexande_apflora`.`DomainApBearbeitungsstand` join (`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) on((`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode` = `alexande_apflora`.`tblAktionsplan`.`ApStatus`))) join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where (isnull(`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft`) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` = 3)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vKontrFuerGis`
--
DROP TABLE IF EXISTS `vKontrFuerGis`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vKontrFuerGis` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `ApStatus`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `ApJahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `ApUmsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `PopGuid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `PopHerkunft`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `PopBekanntSeit`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPopGuid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPopFlurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPopXKoord`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPopYKoord`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPopBekanntSeit`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGuid` AS `TPopKontrGuid`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` AS `TPopKontrJahr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` AS `TPopKontrDatum`,`alexande_apflora`.`DomainTPopFeldkontrTyp`.`DomainTxt` AS `TPopKontrTyp`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPopKontrBearb`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` AS `TPopKontrZaehleinheit1`,`alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilTxt` AS `TPopKontrMethode1`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz1` AS `TPopKontrAnz1`,`DomainTPopKontrZaehleinheit_1`.`ZaehleinheitTxt` AS `TPopKontrZaehleinheit2`,`DomainTPopKontrMethode_2`.`BeurteilTxt` AS `TPopKontrMethode2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz2` AS `TPopKontrAnz2`,`DomainTPopKontrZaehleinheit_2`.`ZaehleinheitTxt` AS `TPopKontrZaehleinheit3`,`DomainTPopKontrMethode_1`.`BeurteilTxt` AS `TPopKontrMethode3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz3` AS `TPopKontrAnz3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUeberleb` AS `TPopKontrUeberleb`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVitalitaet` AS `TPopKontrVitalitaet`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt` AS `TPopKontrEntwicklung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrsach` AS `TPopKontrUrsach`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrteil` AS `TPopKontrUrteil`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendUms` AS `TPopKontrAendUms`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendKontr` AS `TPopKontrAendKontr`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `X`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `Y`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLeb` AS `TPopKontrLeb`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrFlaeche` AS `TPopKontrFlaeche`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLebUmg` AS `TPopKontrLebUmg`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegTyp` AS `TPopKontrVegTyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKonkurrenz` AS `TPopKontrKonkurrenz`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMoosschicht` AS `TPopKontrMoosschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKrautschicht` AS `TPopKontrKrautschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrStrauchschicht` AS `TPopKontrStrauchschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBaumschicht` AS `TPopKontrBaumschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenTyp` AS `TPopKontrBodenTyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenKalkgehalt` AS `TPopKontrBodenKalkgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenDurchlaessigkeit` AS `TPopKontrBodenDurchlaessigkeit`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenHumus` AS `TPopKontrBodenHumus`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenNaehrstoffgehalt` AS `TPopKontrBodenNaehrstoffgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenAbtrag` AS `TPopKontrBodenAbtrag`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrWasserhaushalt` AS `TPopKontrWasserhaushalt`,`alexande_apflora`.`DomainTPopKontrIdBiotUebereinst`.`DomainTxt` AS `TPopKontrIdealBiotopUebereinst`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebFlaeche` AS `TPopKontrUebFlaeche`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrPlan` AS `TPopKontrPlan`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVeg` AS `TPopKontrVeg`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrNaBo` AS `TPopKontrNaBo`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebPfl` AS `TPopKontrUebPfl`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJungPflJN` AS `TPopKontrJungPflJN`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMax` AS `TPopKontrVegHoeMax`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMit` AS `TPopKontrVegHoeMit`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGefaehrdung` AS `TPopKontrGefaehrdung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`MutWer` AS `MutWer` from (((((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join ((((((`alexande_apflora`.`tblTeilPopFeldkontrolle` left join `alexande_apflora`.`DomainTPopFeldkontrTyp` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = `alexande_apflora`.`DomainTPopFeldkontrTyp`.`DomainTxt`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainPopEntwicklung` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrEntwicklung` = `alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungId`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrIdBiotUebereinst` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrIdealBiotopUebereinst` = `alexande_apflora`.`DomainTPopKontrIdBiotUebereinst`.`DomainCode`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum`;

-- --------------------------------------------------------

--
-- Struktur des Views `vKontrLetzte`
--
DROP TABLE IF EXISTS `vKontrLetzte`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vKontrLetzte` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`tblAdresse_1`.`AdrName` AS `AP verantwortlich`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Herkunft`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPop X-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius m`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`tblAdresse_2`.`AdrName` AS `TPop verantwortlich`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Herkunft`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGuid` AS `Kontr Guid`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` AS `Kontr Jahr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` AS `Kontr Datum`,`alexande_apflora`.`DomainTPopFeldkontrTyp`.`DomainTxt` AS `Kontr Typ`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Kontr BearbeiterIn`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` AS `Kontr Zaehleinheit 1`,`alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilTxt` AS `Kontr Methode 1`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz1` AS `Kontr Anzahl 1`,`DomainTPopKontrZaehleinheit_1`.`ZaehleinheitTxt` AS `Kontr Zaehleinheit 2`,`DomainTPopKontrMethode_2`.`BeurteilTxt` AS `Kontr Methode 2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz2` AS `Kontr Anzahl 2`,`DomainTPopKontrZaehleinheit_2`.`ZaehleinheitTxt` AS `Kontr Zaehleinheit 3`,`DomainTPopKontrMethode_1`.`BeurteilTxt` AS `Kontr Methode 3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz3` AS `Kontr Anzahl 3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUeberleb` AS `Kontr Ueberlebensrate`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVitalitaet` AS `Kontr Vitalitaet`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt` AS `Kontr Entwicklung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrsach` AS `Kontr Ursachen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrteil` AS `Kontr Erfolgsbeurteilung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendUms` AS `Kontr Aend-Vorschlaege Umsetzung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendKontr` AS `Kontr Aend-Vorschlaege Kontrolle`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `Kontr X-Koord`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `Kontr Y-Koord`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTxt` AS `Kontr Bemerkungen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLeb` AS `Kontr Lebensraum Delarze`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLebUmg` AS `Kontr angrenzender Lebensraum Delarze`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegTyp` AS `Kontr Vegetationstyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKonkurrenz` AS `Kontr Konkurrenz`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMoosschicht` AS `Kontr Moosschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKrautschicht` AS `Kontr Krautschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrStrauchschicht` AS `Kontr Strauchschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBaumschicht` AS `Kontr Baumschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenTyp` AS `Kontr Bodentyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenKalkgehalt` AS `Kontr Boden Kalkgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenDurchlaessigkeit` AS `Kontr Boden Durchlaessigkeit`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenHumus` AS `Kontr Boden Hmusgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenNaehrstoffgehalt` AS `Kontr Boden Naehrstoffgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenAbtrag` AS `Kontr Oberbodenabtrag`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrWasserhaushalt` AS `Kontr Wasserhaushalt`,`alexande_apflora`.`DomainTPopKontrIdBiotUebereinst`.`DomainTxt` AS `TPopKontrIdealBiotopUebereinst`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrHandlungsbedarf` AS `TPopKontrHandlungsbedarf`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebFlaeche` AS `TPopKontrUebFlaeche`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrFlaeche` AS `Kontr Flaeche m2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrPlan` AS `Kontr auf Plan eingezeichnet`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVeg` AS `Kontr Deckung durch Vegetation`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrNaBo` AS `Kontr Deckung nackter Boden`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebPfl` AS `Kontr Deckung durch ueberpruefte Art`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJungPflJN` AS `Kontr auch junge Pflanzen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMax` AS `Kontr maximale Veg-hoehe cm`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMit` AS `Kontr mittlere Veg-hoehe cm`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGefaehrdung` AS `Kontr Gefaehrdung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`MutWer` AS `MutWer` from (`vKontrLetzteId` join ((((((((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join ((((((`alexande_apflora`.`tblTeilPopFeldkontrolle` left join `alexande_apflora`.`DomainTPopFeldkontrTyp` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = `alexande_apflora`.`DomainTPopFeldkontrTyp`.`DomainTxt`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainPopEntwicklung` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrEntwicklung` = `alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungId`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrIdBiotUebereinst` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrIdealBiotopUebereinst` = `alexande_apflora`.`DomainTPopKontrIdBiotUebereinst`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` `tblAdresse_1` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `tblAdresse_1`.`AdrId`))) left join `alexande_apflora`.`tblAdresse` `tblAdresse_2` on((`tblAdresse_2`.`AdrId` = `alexande_apflora`.`tblTeilpopulation`.`TPopVerantw`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`DomainPopHerkunft_1`.`HerkunftId` = `alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft`))) on((`vKontrLetzteId`.`TPopKontrId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vKontrLetzteId`
--
DROP TABLE IF EXISTS `vKontrLetzteId`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vKontrLetzteId` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,max(`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId`) AS `TPopKontrId` from ((`alexande_beob`.`ArtenDb_Arteigenschaften` join (((`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `vKontrLetztesJahr` on(((`vKontrLetztesJahr`.`MaxvonTPopKontrJahr` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`) and (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId` = `vKontrLetztesJahr`.`TPopId`)))) group by `alexande_apflora`.`tblAktionsplan`.`ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopId`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vKontrLetztesJahr`
--
DROP TABLE IF EXISTS `vKontrLetztesJahr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vKontrLetztesJahr` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Artname`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,max(`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`) AS `MaxvonTPopKontrJahr` from (`alexande_beob`.`ArtenDb_Arteigenschaften` join (((`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) where ((not((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` like 'Ziel'))) and (not((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` like 'Zwischenziel')))) group by `alexande_apflora`.`tblAktionsplan`.`ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopId`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` having (max(`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`) is not null) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vKontrOhneTPop`
--
DROP TABLE IF EXISTS `vKontrOhneTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vKontrOhneTPop` AS select `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGuid` AS `Kontr Guid`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` AS `Kontr Jahr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` AS `Kontr Datum`,`alexande_apflora`.`DomainTPopFeldkontrTyp`.`DomainTxt` AS `Kontr Typ`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Kontr BearbeiterIn`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` AS `Kontr Zaehleinheit 1`,`alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilTxt` AS `Kontr Methode 1`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz1` AS `Kontr Anzahl 1`,`DomainTPopKontrZaehleinheit_1`.`ZaehleinheitTxt` AS `Kontr Zaehleinheit 2`,`DomainTPopKontrMethode_2`.`BeurteilTxt` AS `Kontr Methode 2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz2` AS `Kontr Anzahl 2`,`DomainTPopKontrZaehleinheit_2`.`ZaehleinheitTxt` AS `Kontr Zaehleinheit 3`,`DomainTPopKontrMethode_1`.`BeurteilTxt` AS `Kontr Methode 3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz3` AS `Kontr Anzahl 3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUeberleb` AS `Kontr Ueberlebensrate`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVitalitaet` AS `Kontr Vitalitaet`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt` AS `Kontr Entwicklung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrsach` AS `Kontr Ursachen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrteil` AS `Kontr Erfolgsbeurteilung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendUms` AS `Kontr Aend-Vorschlaege Umsetzung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendKontr` AS `Kontr Aend-Vorschlaege Kontrolle`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `Kontr X-Koord`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `Kontr Y-Koord`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTxt` AS `Kontr Bemerkungen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLeb` AS `Kontr Lebensraum Delarze`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLebUmg` AS `Kontr angrenzender Lebensraum Delarze`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegTyp` AS `Kontr Vegetationstyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKonkurrenz` AS `Kontr Konkurrenz`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMoosschicht` AS `Kontr Moosschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKrautschicht` AS `Kontr Krautschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrStrauchschicht` AS `Kontr Strauchschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBaumschicht` AS `Kontr Baumschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenTyp` AS `Kontr Bodentyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenKalkgehalt` AS `Kontr Boden Kalkgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenDurchlaessigkeit` AS `Kontr Boden Durchlaessigkeit`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenHumus` AS `Kontr Boden Hmusgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenNaehrstoffgehalt` AS `Kontr Boden Naehrstoffgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenAbtrag` AS `Kontr Oberbodenabtrag`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrWasserhaushalt` AS `Kontr Wasserhaushalt`,`alexande_apflora`.`DomainTPopKontrIdBiotUebereinst`.`DomainTxt` AS `TPopKontrIdealBiotopUebereinst`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrHandlungsbedarf` AS `TPopKontrHandlungsbedarf`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebFlaeche` AS `TPopKontrUebFlaeche`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrFlaeche` AS `Kontr Flaeche m2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrPlan` AS `Kontr auf Plan eingezeichnet`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVeg` AS `Kontr Deckung durch Vegetation`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrNaBo` AS `Kontr Deckung nackter Boden`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebPfl` AS `Kontr Deckung durch ueberpruefte Art`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJungPflJN` AS `Kontr auch junge Pflanzen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMax` AS `Kontr maximale Veg-hoehe cm`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMit` AS `Kontr mittlere Veg-hoehe cm`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGefaehrdung` AS `Kontr Gefaehrdung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`MutWer` AS `MutWer` from (((((((((((`alexande_apflora`.`tblTeilPopFeldkontrolle` left join `alexande_apflora`.`DomainTPopFeldkontrTyp` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = `alexande_apflora`.`DomainTPopFeldkontrTyp`.`DomainTxt`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainPopEntwicklung` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrEntwicklung` = `alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungId`))) left join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrIdBiotUebereinst` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrIdealBiotopUebereinst` = `alexande_apflora`.`DomainTPopKontrIdBiotUebereinst`.`DomainCode`))) where isnull(`alexande_apflora`.`tblTeilpopulation`.`TPopId`);

-- --------------------------------------------------------

--
-- Struktur des Views `vKontrTPopKoorLeer`
--
DROP TABLE IF EXISTS `vKontrTPopKoorLeer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vKontrTPopKoorLeer` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `ApStatus_`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPopFlurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPopXKoord`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPopYKoord` from (((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where ((isnull(`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord`) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3)) or (isnull(`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord`) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vKontrTPopStatusErloschen`
--
DROP TABLE IF EXISTS `vKontrTPopStatusErloschen`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vKontrTPopStatusErloschen` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `Bearbeitungsstand AP`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPopFlurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` AS `TPopHerkunft`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` AS `TPopBerEntwicklung`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` AS `TPopBerJahr` from (((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join (`alexande_apflora`.`tblTeilPopBericht` join `vTPopBerLetzterBericht` on(((`alexande_apflora`.`tblTeilPopBericht`.`TPopId` = `vTPopBerLetzterBericht`.`TPopId`) and (`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` = `vTPopBerLetzterBericht`.`MaxvonTPopBerJahr`)))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) where (((`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) and ((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 4) or (`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = 7)) and (`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` <> 8)) or ((`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3) and (not((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` like 4))) and (not((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` like 7))) and (`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = 8))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vLetzterPopBericht`
--
DROP TABLE IF EXISTS `vLetzterPopBericht`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vLetzterPopBericht` AS select `vLetzterPopBericht0`.`ApArtId` AS `ApArtId`,`vLetzterPopBericht0`.`PopId` AS `PopId`,max(`vLetzterPopBericht0`.`PopBerJahr`) AS `MaxvonPopBerJahr` from `vLetzterPopBericht0` group by `vLetzterPopBericht0`.`ApArtId`,`vLetzterPopBericht0`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vLetzterPopBericht0`
--
DROP TABLE IF EXISTS `vLetzterPopBericht0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vLetzterPopBericht0` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblPopBericht`.`PopBerJahr` AS `PopBerJahr` from (`alexande_apflora`.`tblKonstanten` join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblPopBericht` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`)))) where ((`alexande_apflora`.`tblPopBericht`.`PopBerJahr` <= `alexande_apflora`.`tblKonstanten`.`JBerJahr`) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11));

-- --------------------------------------------------------

--
-- Struktur des Views `vLetzterPopMassnBericht`
--
DROP TABLE IF EXISTS `vLetzterPopMassnBericht`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vLetzterPopMassnBericht` AS select `vLetzterPopMassnBericht0`.`ApArtId` AS `ApArtId`,`vLetzterPopMassnBericht0`.`PopId` AS `PopId`,max(`vLetzterPopMassnBericht0`.`PopMassnBerJahr`) AS `MaxvonPopMassnBerJahr` from `vLetzterPopMassnBericht0` group by `vLetzterPopMassnBericht0`.`ApArtId`,`vLetzterPopMassnBericht0`.`PopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vLetzterPopMassnBericht0`
--
DROP TABLE IF EXISTS `vLetzterPopMassnBericht0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vLetzterPopMassnBericht0` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr` AS `PopMassnBerJahr` from (`alexande_apflora`.`tblKonstanten` join (((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblPopMassnBericht` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`))) join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`)))) where ((`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr` <= `alexande_apflora`.`tblKonstanten`.`JBerJahr`) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` <= `alexande_apflora`.`tblKonstanten`.`JBerJahr`) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11));

-- --------------------------------------------------------

--
-- Struktur des Views `vLetzterTPopBericht`
--
DROP TABLE IF EXISTS `vLetzterTPopBericht`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vLetzterTPopBericht` AS select `vLetzterTPopBericht0`.`ApArtId` AS `ApArtId`,`vLetzterTPopBericht0`.`TPopId` AS `TPopId`,max(`vLetzterTPopBericht0`.`TPopBerJahr`) AS `MaxvonTPopBerJahr` from `vLetzterTPopBericht0` group by `vLetzterTPopBericht0`.`ApArtId`,`vLetzterTPopBericht0`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vLetzterTPopBericht0`
--
DROP TABLE IF EXISTS `vLetzterTPopBericht0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vLetzterTPopBericht0` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` AS `TPopBerJahr` from (`alexande_apflora`.`tblKonstanten` join (`alexande_apflora`.`tblAktionsplan` join (`alexande_apflora`.`tblPopulation` join (`alexande_apflora`.`tblTeilpopulation` join `alexande_apflora`.`tblTeilPopBericht` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`))) on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`)))) where ((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` <= `alexande_apflora`.`tblKonstanten`.`JBerJahr`) and (`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` >= `alexande_apflora`.`tblAktionsplan`.`ApJahr`) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11));

-- --------------------------------------------------------

--
-- Struktur des Views `vLetzterTPopMassnBericht`
--
DROP TABLE IF EXISTS `vLetzterTPopMassnBericht`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vLetzterTPopMassnBericht` AS select `vLetzterTPopMassnBericht0`.`ApArtId` AS `ApArtId`,`vLetzterTPopMassnBericht0`.`TPopId` AS `TPopId`,max(`vLetzterTPopMassnBericht0`.`TPopMassnBerJahr`) AS `MaxvonTPopMassnBerJahr` from `vLetzterTPopMassnBericht0` group by `vLetzterTPopMassnBericht0`.`ApArtId`,`vLetzterTPopMassnBericht0`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vLetzterTPopMassnBericht0`
--
DROP TABLE IF EXISTS `vLetzterTPopMassnBericht0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vLetzterTPopMassnBericht0` AS select `alexande_apflora`.`tblPopulation`.`ApArtId` AS `ApArtId`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr` AS `TPopMassnBerJahr` from (`alexande_apflora`.`tblKonstanten` join (((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopMassnBericht` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId`))) join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`)))) where ((`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr` <= `alexande_apflora`.`tblKonstanten`.`JBerJahr`) and (`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` = 1) and (`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` <= `alexande_apflora`.`tblKonstanten`.`JBerJahr`) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 10) and (`alexande_apflora`.`tblPopulation`.`PopHerkunft` <> 11));

-- --------------------------------------------------------

--
-- Struktur des Views `vMassn`
--
DROP TABLE IF EXISTS `vMassn`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vMassn` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPop X-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius (m)`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPop Verantwortlich`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnGuid` AS `Massn Guid`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` AS `Massn Jahr`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnDatum` AS `Massn Datum`,`alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypTxt` AS `Massn Typ`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTxt` AS `Massn Massnahme`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Massn BearbeiterIn`,cast(`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnBemTxt` as char charset utf8) AS `Massn Bemerkungen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlan` AS `Massn Plan vorhanden`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlanBez` AS `Massn Plan Bezeichnung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnFlaeche` AS `Massn Fläche m2`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedForm` AS `Massn Form der Ansiedlung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedPflanzanordnung` AS `Massn Pflanzanordnung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnMarkierung` AS `Massn Markierung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzTriebe` AS `Massn Anz Triebe`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzPfl` AS `Massn Pflanzen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnzPflanzstellen` AS `Massn Anz Pflanzstellen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedWirtspfl` AS `Massn Wirtspflanze`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedHerkunftPop` AS `Massn Herkunftspopulation`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedDatSamm` AS `Massn Sammeldatum`,`alexande_apflora`.`tblTeilPopMassnahme`.`MutWann` AS `Massn MutWann`,`alexande_apflora`.`tblTeilPopMassnahme`.`MutWer` AS `Massn MutWer` from (((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join (`alexande_apflora`.`tblTeilPopMassnahme` left join `alexande_apflora`.`DomainTPopMassnTyp` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTyp` = `alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypCode`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnDatum`,`alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypTxt`;

-- --------------------------------------------------------

--
-- Struktur des Views `vMassnFuerGis`
--
DROP TABLE IF EXISTS `vMassnFuerGis`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vMassnFuerGis` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `ApArt`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `ApStatus`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `ApStartImJahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `ApStandUmsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `PopGuid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `PopStatus`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `PopBekanntSeit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `PopXKoordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `PopYKoordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPopGuid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPopFlurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPopStatus`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPopStatusUnklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPopBegründungFuerUnklarenStatus`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPopXKoordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPopYKoordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPopRadius`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPopHoehe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPopExposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPopKlima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPopHangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPopBeschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPopKatasterNr`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPopVerantwortlich`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPopFuerApBerichtRelevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPopBekanntSeit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPopEigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPopKontaktVorOrt`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPopNutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPopBewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPopBewirtschaftung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnGuid` AS `MassnGuid`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` AS `MassnJahr`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnDatum` AS `MassnDatum`,`alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypTxt` AS `MassnTyp`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTxt` AS `MassnMassnahme`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `MassnBearbeiterIn`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlan` AS `MassnPlanVorhanden`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlanBez` AS `MassnPlanBezeichnung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnFlaeche` AS `MassnFlaeche`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedForm` AS `MassnFormDerAnsiedlung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedPflanzanordnung` AS `MassnPflanzanordnung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnMarkierung` AS `MassnMarkierung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzTriebe` AS `MassnAnzTriebe`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzPfl` AS `MassnPflanzen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnzPflanzstellen` AS `MassnAnzPflanzstellen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedWirtspfl` AS `MassnWirtspflanze`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedHerkunftPop` AS `MassnHerkunftspopulation`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedDatSamm` AS `MassnSammeldatum`,`alexande_apflora`.`tblTeilPopMassnahme`.`MutWann` AS `MassnMutWann`,`alexande_apflora`.`tblTeilPopMassnahme`.`MutWer` AS `MassnMutWer` from (((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join (`alexande_apflora`.`tblTeilPopMassnahme` left join `alexande_apflora`.`DomainTPopMassnTyp` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTyp` = `alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypCode`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnDatum`,`alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypTxt`;

-- --------------------------------------------------------

--
-- Struktur des Views `vMassnJahre`
--
DROP TABLE IF EXISTS `vMassnJahre`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vMassnJahre` AS select `alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` AS `TPopMassnJahr` from `alexande_apflora`.`tblTeilPopMassnahme` group by `alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` having (`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` between 1900 and 2100) order by `alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vMassnPolygon`
--
DROP TABLE IF EXISTS `vMassnPolygon`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vMassnPolygon` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `ApArt`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `ApStatus`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `ApStartImJahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `ApStandUmsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `PopGuid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `PopStatus`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `PopBekanntSeit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `PopXKoordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `PopYKoordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPopGuid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPopFlurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPopStatus`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPopStatusUnklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPopBegründungFuerUnklarenStatus`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPopXKoordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPopYKoordinaten`,`alexande_apflora`.`tpm_polygon`.`TpmPolyPolygon` AS `TpmPolyPolygon`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPopRadius`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPopHoehe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPopExposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPopKlima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPopHangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPopBeschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPopKatasterNr`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPopVerantwortlich`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPopFuerApBerichtRelevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPopBekanntSeit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPopEigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPopKontaktVorOrt`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPopNutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPopBewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPopBewirtschaftung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnGuid` AS `MassnGuid`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` AS `MassnJahr`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnDatum` AS `MassnDatum`,`alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypTxt` AS `MassnTyp`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTxt` AS `MassnMassnahme`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `MassnBearbeiterIn`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlan` AS `MassnPlanVorhanden`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnPlanBez` AS `MassnPlanBezeichnung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnFlaeche` AS `MassnFlaeche`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedForm` AS `MassnFormDerAnsiedlung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedPflanzanordnung` AS `MassnPflanzanordnung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnMarkierung` AS `MassnMarkierung`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzTriebe` AS `MassnAnzTriebe`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedAnzPfl` AS `MassnPflanzen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnzPflanzstellen` AS `MassnAnzPflanzstellen`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedWirtspfl` AS `MassnWirtspflanze`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedHerkunftPop` AS `MassnHerkunftspopulation`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnAnsiedDatSamm` AS `MassnSammeldatum`,`alexande_apflora`.`tblTeilPopMassnahme`.`MutWann` AS `MassnMutWann`,`alexande_apflora`.`tblTeilPopMassnahme`.`MutWer` AS `MassnMutWer` from ((((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join (`alexande_apflora`.`tblTeilPopMassnahme` left join `alexande_apflora`.`DomainTPopMassnTyp` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnTyp` = `alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypCode`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) join `alexande_apflora`.`tpm_polygon` on((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnGuid` = `alexande_apflora`.`tpm_polygon`.`TPopMassnGuid`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr`,`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnDatum`,`alexande_apflora`.`DomainTPopMassnTyp`.`MassnTypTxt`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPop`
--
DROP TABLE IF EXISTS `vPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPop` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblPopulation`.`MutWann` AS `Pop MutWann`,`alexande_apflora`.`tblPopulation`.`MutWer` AS `Pop MutWer` from (((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopAnzKontr`
--
DROP TABLE IF EXISTS `vPopAnzKontr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopAnzKontr` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,count(`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId`) AS `Anzahl Kontrollen` from (((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblPopulation` left join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) left join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) group by `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt`,`alexande_apflora`.`tblAktionsplan`.`ApJahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt`,`alexande_apflora`.`tblPopulation`.`PopGuid`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit`,`alexande_apflora`.`tblPopulation`.`PopXKoord`,`alexande_apflora`.`tblPopulation`.`PopYKoord` order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopAnzMassn`
--
DROP TABLE IF EXISTS `vPopAnzMassn`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopAnzMassn` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,count(`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnId`) AS `Anzahl Massnahmen` from (((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblPopulation` left join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) left join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) group by `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt`,`alexande_apflora`.`tblAktionsplan`.`ApJahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt`,`alexande_apflora`.`tblPopulation`.`PopGuid`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit`,`alexande_apflora`.`tblPopulation`.`PopXKoord`,`alexande_apflora`.`tblPopulation`.`PopYKoord` order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopBer`
--
DROP TABLE IF EXISTS `vPopBer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopBer` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblPopBericht`.`PopBerId` AS `PopBer Id`,`alexande_apflora`.`tblPopBericht`.`PopBerJahr` AS `PopBer Jahr`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt` AS `PopBer Entwicklung`,`alexande_apflora`.`tblPopBericht`.`PopBerTxt` AS `PopBer Bemerkungen`,`alexande_apflora`.`tblPopBericht`.`MutWann` AS `PopBer MutWann`,`alexande_apflora`.`tblPopBericht`.`MutWer` AS `PopBer MutWer` from (((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) join `alexande_apflora`.`tblPopBericht` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`))) left join `alexande_apflora`.`DomainPopEntwicklung` on((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = `alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopBericht`.`PopBerJahr`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopBerMassnJahre`
--
DROP TABLE IF EXISTS `vPopBerMassnJahre`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopBerMassnJahre` AS select `alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblPopBericht`.`PopBerJahr` AS `Jahr` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblPopBericht` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`))) union select `alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr` AS `Jahr` from (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblPopMassnBericht` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`))) order by `Jahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopBerOhnePop`
--
DROP TABLE IF EXISTS `vPopBerOhnePop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopBerOhnePop` AS select `alexande_apflora`.`tblPopBericht`.`PopBerId` AS `PopBer Id`,`alexande_apflora`.`tblPopBericht`.`PopId` AS `PopBer PopId`,`alexande_apflora`.`tblPopBericht`.`PopBerJahr` AS `PopBer Jahr`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt` AS `PopBer Entwicklung`,`alexande_apflora`.`tblPopBericht`.`PopBerTxt` AS `PopBer Bemerkungen`,`alexande_apflora`.`tblPopBericht`.`MutWann` AS `PopBer MutWann`,`alexande_apflora`.`tblPopBericht`.`MutWer` AS `PopBer MutWer` from ((`alexande_apflora`.`tblPopBericht` left join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`))) left join `alexande_apflora`.`DomainPopEntwicklung` on((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = `alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungId`))) where isnull(`alexande_apflora`.`tblPopulation`.`PopId`) order by `alexande_apflora`.`tblPopBericht`.`PopBerJahr`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopFuerGis`
--
DROP TABLE IF EXISTS `vPopFuerGis`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopFuerGis` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `XKoordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `YKoordinaten`,`alexande_apflora`.`tblPopulation`.`MutWann` AS `Pop MutWann`,`alexande_apflora`.`tblPopulation`.`MutWer` AS `Pop MutWer` from (((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) where ((`alexande_apflora`.`tblPopulation`.`PopXKoord` > 0) and (`alexande_apflora`.`tblPopulation`.`PopYKoord` > 0)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopFuerKml`
--
DROP TABLE IF EXISTS `vPopFuerKml`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopFuerKml` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Label`,cast(left(concat('Population: ',`alexande_apflora`.`tblPopulation`.`PopNr`,' ',`alexande_apflora`.`tblPopulation`.`PopName`),225) as char charset utf8) AS `Inhalte`,((((((2.6779094 + (4.728982 * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000))) + ((0.791484 * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000))) + (((0.1306 * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000))) - (((0.0436 * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000))) * 100) / 36) AS `Laengengrad`,(((((((16.9023892 + (3.238272 * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000))) - ((0.270978 * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000))) - ((0.002528 * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000))) - (((0.0447 * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000))) - (((0.014 * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000))) * 100) / 36) AS `Breitengrad`,cast(concat('http://www.apflora.barbalex.ch/index.html?ap=',`alexande_apflora`.`tblAktionsplan`.`ApArtId`,'&pop=',`alexande_apflora`.`tblPopulation`.`PopId`) as char charset utf8) AS `URL` from ((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where ((`alexande_apflora`.`tblPopulation`.`PopYKoord` > 0) and (`alexande_apflora`.`tblPopulation`.`PopXKoord` > 0)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopFuerKmlNamen`
--
DROP TABLE IF EXISTS `vPopFuerKmlNamen`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopFuerKmlNamen` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,cast(concat(`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,' ',`alexande_apflora`.`tblPopulation`.`PopNr`) as char charset utf8) AS `Label`,cast(left(concat('Population: ',`alexande_apflora`.`tblPopulation`.`PopNr`,' ',`alexande_apflora`.`tblPopulation`.`PopName`),225) as char charset utf8) AS `Inhalte`,((((((2.6779094 + (4.728982 * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000))) + ((0.791484 * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000))) + (((0.1306 * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000))) - (((0.0436 * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000))) * 100) / 36) AS `Laengengrad`,(((((((16.9023892 + (3.238272 * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000))) - ((0.270978 * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000))) - ((0.002528 * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000))) - (((0.0447 * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000))) - (((0.014 * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblPopulation`.`PopYKoord` - 200000) / 1000000))) * 100) / 36) AS `Breitengrad`,cast(concat('http://www.apflora.barbalex.ch/index.html?ap=',`alexande_apflora`.`tblAktionsplan`.`ApArtId`,'&pop=',`alexande_apflora`.`tblPopulation`.`PopId`) as char charset utf8) AS `URL` from ((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where ((`alexande_apflora`.`tblPopulation`.`PopYKoord` > 0) and (`alexande_apflora`.`tblPopulation`.`PopXKoord` > 0)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopMassnBer`
--
DROP TABLE IF EXISTS `vPopMassnBer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopMassnBer` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `AP ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblPopulation`.`MutWann` AS `Pop MutWann`,`alexande_apflora`.`tblPopulation`.`MutWer` AS `Pop MutWer`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerId` AS `PopMassnBer Id`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr` AS `PopMassnBer Jahr`,`alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilTxt` AS `PopMassnBer Entwicklung`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerTxt` AS `PopMassnBer Interpretation`,`alexande_apflora`.`tblPopMassnBericht`.`MutWann` AS `PopMassnBer MutWann`,`alexande_apflora`.`tblPopMassnBericht`.`MutWer` AS `PopMassnBer MutWer` from (((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) join `alexande_apflora`.`tblPopMassnBericht` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`))) left join `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung` on((`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerErfolgsbeurteilung` = `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopMassnberAnzMassn`
--
DROP TABLE IF EXISTS `vPopMassnberAnzMassn`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopMassnberAnzMassn` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`vPopMassnberAnzMassn0`.`PopMassnBerJahr` AS `MassnBer Jahr`,`vPopMassnberAnzMassn0`.`AnzahlvonTPopMassnId` AS `Anz Massnahmen in diesem Jahr` from ((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) join `vPopMassnberAnzMassn0` on((`alexande_apflora`.`tblPopulation`.`PopId` = `vPopMassnberAnzMassn0`.`PopId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`vPopMassnberAnzMassn0`.`PopMassnBerJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopMassnberAnzMassn0`
--
DROP TABLE IF EXISTS `vPopMassnberAnzMassn0`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopMassnberAnzMassn0` AS select `alexande_apflora`.`tblPopMassnBericht`.`PopId` AS `PopId`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr` AS `PopMassnBerJahr`,count(`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnId`) AS `AnzahlvonTPopMassnId` from (`alexande_apflora`.`tblPopMassnBericht` join (`alexande_apflora`.`tblTeilpopulation` left join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblPopMassnBericht`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where ((`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` = `alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr`) or isnull(`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr`)) group by `alexande_apflora`.`tblPopMassnBericht`.`PopId`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr` order by `alexande_apflora`.`tblPopMassnBericht`.`PopId`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopMassnBerOhnePop`
--
DROP TABLE IF EXISTS `vPopMassnBerOhnePop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopMassnBerOhnePop` AS select `alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerId` AS `PopMassnBer Id`,`alexande_apflora`.`tblPopMassnBericht`.`PopId` AS `PopMassnBer PopId`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr` AS `PopMassnBer Jahr`,`alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilTxt` AS `PopMassnBer Entwicklung`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerTxt` AS `PopMassnBer Interpretation`,`alexande_apflora`.`tblPopMassnBericht`.`MutWann` AS `PopMassnBer MutWann`,`alexande_apflora`.`tblPopMassnBericht`.`MutWer` AS `PopMassnBer MutWer` from ((`alexande_apflora`.`tblPopMassnBericht` left join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`))) left join `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung` on((`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerErfolgsbeurteilung` = `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilId`))) where isnull(`alexande_apflora`.`tblPopulation`.`PopId`) order by `alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr`,`alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilTxt`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopMassnSeitBeginnAp`
--
DROP TABLE IF EXISTS `vPopMassnSeitBeginnAp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopMassnSeitBeginnAp` AS select `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId` AS `TPopId` from (`alexande_apflora`.`tblAktionsplan` join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where (`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnJahr` >= `alexande_apflora`.`tblAktionsplan`.`ApJahr`) group by `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopOhneAp`
--
DROP TABLE IF EXISTS `vPopOhneAp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopOhneAp` AS select `alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblPopulation`.`MutWann` AS `Pop MutWann`,`alexande_apflora`.`tblPopulation`.`MutWer` AS `Pop MutWer`,`alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId` from ((`alexande_apflora`.`tblPopulation` left join `alexande_apflora`.`tblAktionsplan` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) where isnull(`alexande_apflora`.`tblAktionsplan`.`ApArtId`) order by `alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`tblPopulation`.`PopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopOhneKoord`
--
DROP TABLE IF EXISTS `vPopOhneKoord`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopOhneKoord` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopId` AS `PopId`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblPopulation`.`MutWann` AS `Pop MutWann`,`alexande_apflora`.`tblPopulation`.`MutWer` AS `Pop MutWer` from (((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) where (isnull(`alexande_apflora`.`tblPopulation`.`PopXKoord`) or isnull(`alexande_apflora`.`tblPopulation`.`PopYKoord`)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopOhneTPop`
--
DROP TABLE IF EXISTS `vPopOhneTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopOhneTPop` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblPopulation`.`MutWann` AS `Pop MutWann`,`alexande_apflora`.`tblPopulation`.`MutWer` AS `Pop MutWer` from ((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) where isnull(`alexande_apflora`.`tblTeilpopulation`.`TPopId`) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPopVonApOhneStatus`
--
DROP TABLE IF EXISTS `vPopVonApOhneStatus`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPopVonApOhneStatus` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`tblAktionsplan`.`ApStatus` AS `Bearbeitungsstand AP`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`tblPopulation`.`PopHerkunft` AS `Status` from (`alexande_beob`.`ArtenDb_Arteigenschaften` join (`alexande_apflora`.`tblAktionsplan` join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) where ((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = 3) and isnull(`alexande_apflora`.`tblPopulation`.`PopHerkunft`)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPop_BerMassnJahreVonTPop`
--
DROP TABLE IF EXISTS `vPop_BerMassnJahreVonTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPop_BerMassnJahreVonTPop` AS select `alexande_apflora`.`tblTeilpopulation`.`PopId` AS `PopId`,`vTPopBerMassnJahre`.`Jahr` AS `Jahr` from (`vTPopBerMassnJahre` join `alexande_apflora`.`tblTeilpopulation` on((`vTPopBerMassnJahre`.`TPopId` = `alexande_apflora`.`tblTeilpopulation`.`TPopId`))) group by `alexande_apflora`.`tblTeilpopulation`.`PopId`,`vTPopBerMassnJahre`.`Jahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vPop_BerUndMassnBer`
--
DROP TABLE IF EXISTS `vPop_BerUndMassnBer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vPop_BerUndMassnBer` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `AP ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblPopulation`.`MutWann` AS `Pop MutWann`,`alexande_apflora`.`tblPopulation`.`MutWer` AS `Pop MutWer`,`vPopBerMassnJahre`.`Jahr` AS `Jahr`,`alexande_apflora`.`tblPopBericht`.`PopBerId` AS `PopBer Id`,`alexande_apflora`.`tblPopBericht`.`PopBerJahr` AS `PopBer Jahr`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt` AS `PopBer Entwicklung`,`alexande_apflora`.`tblPopBericht`.`PopBerTxt` AS `PopBer Bemerkungen`,`alexande_apflora`.`tblPopBericht`.`MutWann` AS `PopBer MutWann`,`alexande_apflora`.`tblPopBericht`.`MutWer` AS `PopBer MutWer`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerId` AS `PopMassnBer Id`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr` AS `PopMassnBer Jahr`,`alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilTxt` AS `PopMassnBer Entwicklung`,`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerTxt` AS `PopMassnBer Interpretation`,`alexande_apflora`.`tblPopMassnBericht`.`MutWann` AS `PopMassnBer MutWann`,`alexande_apflora`.`tblPopMassnBericht`.`MutWer` AS `PopMassnBer MutWer` from ((((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `vPopBerMassnJahre` on((`alexande_apflora`.`tblPopulation`.`PopId` = `vPopBerMassnJahre`.`PopId`))) left join (`alexande_apflora`.`tblPopMassnBericht` left join `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung` on((`alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerErfolgsbeurteilung` = `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilId`))) on(((`vPopBerMassnJahre`.`Jahr` = `alexande_apflora`.`tblPopMassnBericht`.`PopMassnBerJahr`) and (`vPopBerMassnJahre`.`PopId` = `alexande_apflora`.`tblPopMassnBericht`.`PopId`)))) left join (`alexande_apflora`.`tblPopBericht` left join `alexande_apflora`.`DomainPopEntwicklung` on((`alexande_apflora`.`tblPopBericht`.`PopBerEntwicklung` = `alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungId`))) on(((`vPopBerMassnJahre`.`Jahr` = `alexande_apflora`.`tblPopBericht`.`PopBerJahr`) and (`vPopBerMassnJahre`.`PopId` = `alexande_apflora`.`tblPopBericht`.`PopId`)))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`vPopBerMassnJahre`.`Jahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vProgramme`
--
DROP TABLE IF EXISTS `vProgramme`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vProgramme` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Bearbeitungsstand`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `AP verantwortlich`,`alexande_apflora`.`tblAktionsplan`.`MutWann` AS `AP Letzte Änderung`,`alexande_apflora`.`tblAktionsplan`.`MutWer` AS `AP Letzte(r) Bearbeiter(in)` from ((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPop`
--
DROP TABLE IF EXISTS `vTPop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPop` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPop X-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius (m)`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPop Verantwortlich`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,`alexande_apflora`.`tblTeilpopulation`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblTeilpopulation`.`MutWer` AS `MutWer` from (((((((`alexande_apflora`.`tblTeilpopulation` left join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) left join (`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilpopulation`.`TPopVerantw` = `alexande_apflora`.`tblAdresse`.`AdrId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopAnzFeldkontr`
--
DROP TABLE IF EXISTS `vTPopAnzFeldkontr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopAnzFeldkontr` AS select `alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPopGuid`,count(`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId`) AS `Anzahl Feld-Kontrollen` from (`alexande_apflora`.`tblTeilpopulation` left join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) where (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` <> 'Freiwilligen-Erfolgskontrolle') group by `alexande_apflora`.`tblTeilpopulation`.`TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopAnzFreiwkontr`
--
DROP TABLE IF EXISTS `vTPopAnzFreiwkontr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopAnzFreiwkontr` AS select `alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPopGuid`,count(`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId`) AS `Anzahl Freiwilligen-Kontrollen` from (`alexande_apflora`.`tblTeilpopulation` left join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) where (`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = 'Freiwilligen-Erfolgskontrolle') group by `alexande_apflora`.`tblTeilpopulation`.`TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopAnzKontr`
--
DROP TABLE IF EXISTS `vTPopAnzKontr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopAnzKontr` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPop X-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius (m)`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,count(`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrId`) AS `Anzahl Kontrollen` from (((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) left join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) group by `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt`,`alexande_apflora`.`tblAktionsplan`.`ApJahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt`,`alexande_apflora`.`tblPopulation`.`PopGuid`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit`,`alexande_apflora`.`tblPopulation`.`PopXKoord`,`alexande_apflora`.`tblPopulation`.`PopYKoord`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`,`DomainPopHerkunft_1`.`HerkunftTxt`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopAnzKontrInklLetzteKontr`
--
DROP TABLE IF EXISTS `vTPopAnzKontrInklLetzteKontr`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopAnzKontrInklLetzteKontr` AS select `vTPopAnzKontr`.`ApArtId` AS `ApArtId`,`vTPopAnzKontr`.`AP Art` AS `AP Art`,`vTPopAnzKontr`.`AP Status` AS `AP Status`,`vTPopAnzKontr`.`AP Start im Jahr` AS `AP Start im Jahr`,`vTPopAnzKontr`.`AP Stand Umsetzung` AS `AP Stand Umsetzung`,`vTPopAnzKontr`.`Pop Guid` AS `Pop Guid`,`vTPopAnzKontr`.`Pop Nr` AS `Pop Nr`,`vTPopAnzKontr`.`Pop Name` AS `Pop Name`,`vTPopAnzKontr`.`Pop Status` AS `Pop Status`,`vTPopAnzKontr`.`Pop bekannt seit` AS `Pop bekannt seit`,`vTPopAnzKontr`.`Pop X-Koordinaten` AS `Pop X-Koordinaten`,`vTPopAnzKontr`.`Pop Y-Koordinaten` AS `Pop Y-Koordinaten`,`vTPopAnzKontr`.`TPop Guid` AS `TPop Guid`,`vTPopAnzKontr`.`TPop Nr` AS `TPop Nr`,`vTPopAnzKontr`.`TPop Gemeinde` AS `TPop Gemeinde`,`vTPopAnzKontr`.`TPop Flurname` AS `TPop Flurname`,`vTPopAnzKontr`.`TPop Status` AS `TPop Status`,`vTPopAnzKontr`.`TPop Status unklar` AS `TPop Status unklar`,`vTPopAnzKontr`.`TPop Begründung für unklaren Status` AS `TPop Begründung für unklaren Status`,`vTPopAnzKontr`.`TPop X-Koordinaten` AS `TPop X-Koordinaten`,`vTPopAnzKontr`.`TPop Y-Koordinaten` AS `TPop Y-Koordinaten`,`vTPopAnzKontr`.`TPop Radius (m)` AS `TPop Radius (m)`,`vTPopAnzKontr`.`TPop Höhe` AS `TPop Höhe`,`vTPopAnzKontr`.`TPop Exposition` AS `TPop Exposition`,`vTPopAnzKontr`.`TPop Klima` AS `TPop Klima`,`vTPopAnzKontr`.`TPop Hangneigung` AS `TPop Hangneigung`,`vTPopAnzKontr`.`TPop Beschreibung` AS `TPop Beschreibung`,`vTPopAnzKontr`.`TPop Kataster-Nr` AS `TPop Kataster-Nr`,`vTPopAnzKontr`.`TPop für AP-Bericht relevant` AS `TPop für AP-Bericht relevant`,`vTPopAnzKontr`.`TPop bekannt seit` AS `TPop bekannt seit`,`vTPopAnzKontr`.`TPop EigentümerIn` AS `TPop EigentümerIn`,`vTPopAnzKontr`.`TPop Kontakt vor Ort` AS `TPop Kontakt vor Ort`,`vTPopAnzKontr`.`TPop Nutzungszone` AS `TPop Nutzungszone`,`vTPopAnzKontr`.`TPop BewirtschafterIn` AS `TPop BewirtschafterIn`,`vTPopAnzKontr`.`TPop Bewirtschaftung` AS `TPop Bewirtschaftung`,`vTPopAnzKontr`.`Anzahl Kontrollen` AS `Anzahl Kontrollen`,if((`vTPopAnzFeldkontr`.`Anzahl Feld-Kontrollen` > 0),`vTPopAnzFeldkontr`.`Anzahl Feld-Kontrollen`,0) AS `Anzahl Feld-Kontrollen`,if((`vTPopAnzFreiwkontr`.`Anzahl Freiwilligen-Kontrollen` > 0),`vTPopAnzFreiwkontr`.`Anzahl Freiwilligen-Kontrollen`,0) AS `Anzahl Freiwilligen-Kontrollen`,`vKontrLetzte`.`Kontr Guid` AS `Kontr Guid`,`vKontrLetzte`.`Kontr Jahr` AS `Kontr Jahr`,`vKontrLetzte`.`Kontr Datum` AS `Kontr Datum`,`vKontrLetzte`.`Kontr Typ` AS `Kontr Typ`,`vKontrLetzte`.`Kontr BearbeiterIn` AS `Kontr BearbeiterIn`,`vKontrLetzte`.`Kontr Zaehleinheit 1` AS `Kontr Zaehleinheit 1`,`vKontrLetzte`.`Kontr Methode 1` AS `Kontr Methode 1`,`vKontrLetzte`.`Kontr Anzahl 1` AS `Kontr Anzahl 1`,`vKontrLetzte`.`Kontr Zaehleinheit 2` AS `Kontr Zaehleinheit 2`,`vKontrLetzte`.`Kontr Methode 2` AS `Kontr Methode 2`,`vKontrLetzte`.`Kontr Anzahl 2` AS `Kontr Anzahl 2`,`vKontrLetzte`.`Kontr Zaehleinheit 3` AS `Kontr Zaehleinheit 3`,`vKontrLetzte`.`Kontr Methode 3` AS `Kontr Methode 3`,`vKontrLetzte`.`Kontr Anzahl 3` AS `Kontr Anzahl 3`,`vKontrLetzte`.`Kontr Ueberlebensrate` AS `Kontr Ueberlebensrate`,`vKontrLetzte`.`Kontr Vitalitaet` AS `Kontr Vitalitaet`,`vKontrLetzte`.`Kontr Entwicklung` AS `Kontr Entwicklung`,`vKontrLetzte`.`Kontr Ursachen` AS `Kontr Ursachen`,`vKontrLetzte`.`Kontr Erfolgsbeurteilung` AS `Kontr Erfolgsbeurteilung`,`vKontrLetzte`.`Kontr Aend-Vorschlaege Umsetzung` AS `Kontr Aend-Vorschlaege Umsetzung`,`vKontrLetzte`.`Kontr Aend-Vorschlaege Kontrolle` AS `Kontr Aend-Vorschlaege Kontrolle`,`vKontrLetzte`.`Kontr X-Koord` AS `Kontr X-Koord`,`vKontrLetzte`.`Kontr Y-Koord` AS `Kontr Y-Koord`,`vKontrLetzte`.`Kontr Bemerkungen` AS `Kontr Bemerkungen`,`vKontrLetzte`.`Kontr Lebensraum Delarze` AS `Kontr Lebensraum Delarze`,`vKontrLetzte`.`Kontr angrenzender Lebensraum Delarze` AS `Kontr angrenzender Lebensraum Delarze`,`vKontrLetzte`.`Kontr Vegetationstyp` AS `Kontr Vegetationstyp`,`vKontrLetzte`.`Kontr Konkurrenz` AS `Kontr Konkurrenz`,`vKontrLetzte`.`Kontr Moosschicht` AS `Kontr Moosschicht`,`vKontrLetzte`.`Kontr Krautschicht` AS `Kontr Krautschicht`,`vKontrLetzte`.`Kontr Strauchschicht` AS `Kontr Strauchschicht`,`vKontrLetzte`.`Kontr Baumschicht` AS `Kontr Baumschicht`,`vKontrLetzte`.`Kontr Bodentyp` AS `Kontr Bodentyp`,`vKontrLetzte`.`Kontr Boden Kalkgehalt` AS `Kontr Boden Kalkgehalt`,`vKontrLetzte`.`Kontr Boden Durchlaessigkeit` AS `Kontr Boden Durchlaessigkeit`,`vKontrLetzte`.`Kontr Boden Hmusgehalt` AS `Kontr Boden Hmusgehalt`,`vKontrLetzte`.`Kontr Boden Naehrstoffgehalt` AS `Kontr Boden Naehrstoffgehalt`,`vKontrLetzte`.`Kontr Oberbodenabtrag` AS `Kontr Oberbodenabtrag`,`vKontrLetzte`.`Kontr Wasserhaushalt` AS `Kontr Wasserhaushalt`,`vKontrLetzte`.`TPopKontrIdealBiotopUebereinst` AS `TPopKontrIdealBiotopUebereinst`,`vKontrLetzte`.`TPopKontrHandlungsbedarf` AS `TPopKontrHandlungsbedarf`,`vKontrLetzte`.`TPopKontrUebFlaeche` AS `TPopKontrUebFlaeche`,`vKontrLetzte`.`Kontr Flaeche m2` AS `Kontr Flaeche m2`,`vKontrLetzte`.`Kontr auf Plan eingezeichnet` AS `Kontr auf Plan eingezeichnet`,`vKontrLetzte`.`Kontr Deckung durch Vegetation` AS `Kontr Deckung durch Vegetation`,`vKontrLetzte`.`Kontr Deckung nackter Boden` AS `Kontr Deckung nackter Boden`,`vKontrLetzte`.`Kontr Deckung durch ueberpruefte Art` AS `Kontr Deckung durch ueberpruefte Art`,`vKontrLetzte`.`Kontr auch junge Pflanzen` AS `Kontr auch junge Pflanzen`,`vKontrLetzte`.`Kontr maximale Veg-hoehe cm` AS `Kontr maximale Veg-hoehe cm`,`vKontrLetzte`.`Kontr mittlere Veg-hoehe cm` AS `Kontr mittlere Veg-hoehe cm`,`vKontrLetzte`.`Kontr Gefaehrdung` AS `Kontr Gefaehrdung`,`vKontrLetzte`.`MutWann` AS `MutWann`,`vKontrLetzte`.`MutWer` AS `MutWer` from (((`vTPopAnzKontr` left join `vKontrLetzte` on((`vTPopAnzKontr`.`TPop Guid` = `vKontrLetzte`.`TPop Guid`))) left join `vTPopAnzFeldkontr` on((`vTPopAnzKontr`.`TPop Guid` = `vTPopAnzFeldkontr`.`TPopGuid`))) left join `vTPopAnzFreiwkontr` on((`vTPopAnzKontr`.`TPop Guid` = `vTPopAnzFreiwkontr`.`TPopGuid`)));

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopAnzMassn`
--
DROP TABLE IF EXISTS `vTPopAnzMassn`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopAnzMassn` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPop X-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius (m)`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,count(`alexande_apflora`.`tblTeilPopMassnahme`.`TPopMassnId`) AS `Anzahl Massnahmen` from ((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join ((`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) left join `alexande_apflora`.`tblTeilPopMassnahme` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnahme`.`TPopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) group by `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt`,`alexande_apflora`.`tblAktionsplan`.`ApJahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt`,`alexande_apflora`.`tblPopulation`.`PopGuid`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit`,`alexande_apflora`.`tblPopulation`.`PopXKoord`,`alexande_apflora`.`tblPopulation`.`PopYKoord`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`,`DomainPopHerkunft_1`.`HerkunftTxt`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopBer`
--
DROP TABLE IF EXISTS `vTPopBer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopBer` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPop X-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius (m)`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPop Verantwortlich`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerId` AS `TPopBer Id`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` AS `TPopBer Jahr`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt` AS `TPopBer Entwicklung`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerTxt` AS `TPopBer Bemerkungen`,`alexande_apflora`.`tblTeilPopBericht`.`MutWann` AS `TPopBer MutWann`,`alexande_apflora`.`tblTeilPopBericht`.`MutWer` AS `TPopBer MutWer` from ((`alexande_apflora`.`tblTeilPopBericht` left join (((((((`alexande_apflora`.`tblTeilpopulation` left join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) left join (`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilpopulation`.`TPopVerantw` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`))) left join `alexande_apflora`.`DomainPopEntwicklung` on((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = `alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopBerLetzterBericht`
--
DROP TABLE IF EXISTS `vTPopBerLetzterBericht`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopBerLetzterBericht` AS select `alexande_apflora`.`tblTeilPopBericht`.`TPopId` AS `TPopId`,max(`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr`) AS `MaxvonTPopBerJahr` from `alexande_apflora`.`tblTeilPopBericht` group by `alexande_apflora`.`tblTeilPopBericht`.`TPopId`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopBerMassnJahre`
--
DROP TABLE IF EXISTS `vTPopBerMassnJahre`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopBerMassnJahre` AS select `alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` AS `Jahr` from (`alexande_apflora`.`tblTeilpopulation` join `alexande_apflora`.`tblTeilPopBericht` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`))) union select `alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr` AS `Jahr` from (`alexande_apflora`.`tblTeilpopulation` join `alexande_apflora`.`tblTeilPopMassnBericht` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId`))) order by `Jahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopFuerGis`
--
DROP TABLE IF EXISTS `vTPopFuerGis`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopFuerGis` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPopXKoordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPopYKoordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius (m)`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPop Verantwortlich`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,`alexande_apflora`.`tblTeilpopulation`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblTeilpopulation`.`MutWer` AS `MutWer` from (((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilpopulation`.`TPopVerantw` = `alexande_apflora`.`tblAdresse`.`AdrId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` > 0) and (`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` > 0)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopFuerKml`
--
DROP TABLE IF EXISTS `vTPopFuerKml`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopFuerKml` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,cast(concat(`alexande_apflora`.`tblPopulation`.`PopNr`,'/',`alexande_apflora`.`tblTeilpopulation`.`TPopNr`) as char charset utf8) AS `Label`,cast(left(concat('Population: ',`alexande_apflora`.`tblPopulation`.`PopNr`,' ',`alexande_apflora`.`tblPopulation`.`PopName`,'<br /> Teilpopulation: ',`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,' ',`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,' ',`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`),225) as char charset utf8) AS `Inhalte`,((((((2.6779094 + (4.728982 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000))) + ((0.791484 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000))) + (((0.1306 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000))) - (((0.0436 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000))) * 100) / 36) AS `Laengengrad`,(((((((16.9023892 + (3.238272 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000))) - ((0.270978 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000))) - ((0.002528 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000))) - (((0.0447 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000))) - (((0.014 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000))) * 100) / 36) AS `Breitengrad`,cast(concat('http://www.apflora.barbalex.ch/index.html?ap=',`alexande_apflora`.`tblAktionsplan`.`ApArtId`,'&pop=',`alexande_apflora`.`tblTeilpopulation`.`TPopId`) as char charset utf8) AS `URL` from ((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` > 0) and (`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` > 0)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopFuerKmlNamen`
--
DROP TABLE IF EXISTS `vTPopFuerKmlNamen`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopFuerKmlNamen` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,cast(concat(`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,' ',`alexande_apflora`.`tblPopulation`.`PopNr`,'/',`alexande_apflora`.`tblTeilpopulation`.`TPopNr`) as char charset utf8) AS `Label`,cast(left(concat('Population: ',`alexande_apflora`.`tblPopulation`.`PopNr`,' ',`alexande_apflora`.`tblPopulation`.`PopName`,'<br /> Teilpopulation: ',`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,' ',`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,' ',`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`),225) as char charset utf8) AS `Inhalte`,((((((2.6779094 + (4.728982 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000))) + ((0.791484 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000))) + (((0.1306 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000))) - (((0.0436 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000))) * 100) / 36) AS `Laengengrad`,(((((((16.9023892 + (3.238272 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000))) - ((0.270978 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000))) - ((0.002528 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000))) - (((0.0447 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` - 600000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000))) - (((0.014 * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000)) * ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` - 200000) / 1000000))) * 100) / 36) AS `Breitengrad`,cast(concat('http://www.apflora.barbalex.ch/index.html?ap=',`alexande_apflora`.`tblAktionsplan`.`ApArtId`,'&pop=',`alexande_apflora`.`tblTeilpopulation`.`TPopId`) as char charset utf8) AS `URL` from ((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where ((`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` > 0) and (`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` > 0)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopKontrBerMassnJahre`
--
DROP TABLE IF EXISTS `vTPopKontrBerMassnJahre`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopKontrBerMassnJahre` AS select `alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` AS `Jahr` from (`alexande_apflora`.`tblTeilpopulation` join `alexande_apflora`.`tblTeilPopBericht` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`))) union select `alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr` AS `Jahr` from (`alexande_apflora`.`tblTeilpopulation` join `alexande_apflora`.`tblTeilPopMassnBericht` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId`))) union select `alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` AS `Jahr` from (`alexande_apflora`.`tblTeilpopulation` join `alexande_apflora`.`tblTeilPopFeldkontrolle` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`))) order by `Jahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopMassnBer`
--
DROP TABLE IF EXISTS `vTPopMassnBer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopMassnBer` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPop X-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius (m)`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPop Verantwortlich`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerId` AS `TPopMassnBer Id`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr` AS `TPopMassnBer Jahr`,`alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilTxt` AS `TPopMassnBer Entwicklung`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerTxt` AS `TPopMassnBer Interpretation`,`alexande_apflora`.`tblTeilPopMassnBericht`.`MutWann` AS `TPopMassnBer MutWann`,`alexande_apflora`.`tblTeilPopMassnBericht`.`MutWer` AS `TPopMassnBer MutWer` from (((((((((`alexande_apflora`.`tblTeilpopulation` left join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) left join (`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilpopulation`.`TPopVerantw` = `alexande_apflora`.`tblAdresse`.`AdrId`))) join `alexande_apflora`.`tblTeilPopMassnBericht` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId`))) left join `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung` on((`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerErfolgsbeurteilung` = `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopOhneBekanntSeit`
--
DROP TABLE IF EXISTS `vTPopOhneBekanntSeit`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopOhneBekanntSeit` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `ApStatus_`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `PopNr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPopFlurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPopBekanntSeit` from (((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) where (isnull(`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit`) and (`alexande_apflora`.`tblAktionsplan`.`ApStatus` between 1 and 3)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblPopulation`.`PopName`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPopOhnePop`
--
DROP TABLE IF EXISTS `vTPopOhnePop`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPopOhnePop` AS select `alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPop X-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius (m)`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe üM`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPop Verantwortlich`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,`alexande_apflora`.`tblTeilpopulation`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblTeilpopulation`.`MutWer` AS `MutWer` from (((`alexande_apflora`.`tblTeilpopulation` left join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilpopulation`.`TPopVerantw` = `alexande_apflora`.`tblAdresse`.`AdrId`))) where isnull(`alexande_apflora`.`tblPopulation`.`PopId`) order by `alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPop_BerUndMassnBer`
--
DROP TABLE IF EXISTS `vTPop_BerUndMassnBer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPop_BerUndMassnBer` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Status`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklar` AS `Pop Status unklar`,`alexande_apflora`.`tblPopulation`.`PopHerkunftUnklarBegruendung` AS `Pop Begründung für unklaren Status`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblPopulation`.`PopXKoord` AS `Pop X-Koordinaten`,`alexande_apflora`.`tblPopulation`.`PopYKoord` AS `Pop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPop X-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius (m)`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `TPop Verantwortlich`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,`vTPopBerMassnJahre`.`Jahr` AS `Jahr`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerId` AS `TPopBer Id`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` AS `TPopBer Jahr`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt` AS `TPopBer Entwicklung`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerTxt` AS `TPopBer Bemerkungen`,`alexande_apflora`.`tblTeilPopBericht`.`MutWann` AS `TPopBer MutWann`,`alexande_apflora`.`tblTeilPopBericht`.`MutWer` AS `TPopBer MutWer`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr` AS `TPopMassnBer Jahr`,`alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilTxt` AS `TPopMassnBer Entwicklung`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerTxt` AS `TPopMassnBer Interpretation`,`alexande_apflora`.`tblTeilPopMassnBericht`.`MutWann` AS `TPopMassnBer MutWann`,`alexande_apflora`.`tblTeilPopMassnBericht`.`MutWer` AS `TPopMassnBer MutWer` from ((((((((((((`alexande_apflora`.`tblTeilpopulation` left join `alexande_apflora`.`tblPopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) left join (`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft` = `DomainPopHerkunft_1`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilpopulation`.`TPopVerantw` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `vTPopBerMassnJahre` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `vTPopBerMassnJahre`.`TPopId`))) left join `alexande_apflora`.`tblTeilPopMassnBericht` on(((`vTPopBerMassnJahre`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId`) and (`vTPopBerMassnJahre`.`Jahr` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr`)))) left join `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung` on((`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerErfolgsbeurteilung` = `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilId`))) left join `alexande_apflora`.`tblTeilPopBericht` on(((`vTPopBerMassnJahre`.`Jahr` = `alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr`) and (`vTPopBerMassnJahre`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`)))) left join `alexande_apflora`.`DomainPopEntwicklung` on((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = `alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`,`vTPopBerMassnJahre`.`Jahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vTPop_KontrBerMassnBer`
--
DROP TABLE IF EXISTS `vTPop_KontrBerMassnBer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vTPop_KontrBerMassnBer` AS select `alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` AS `ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`tblAdresse_1`.`AdrName` AS `AP verantwortlich`,`alexande_apflora`.`tblPopulation`.`PopGuid` AS `Pop Guid`,`alexande_apflora`.`tblPopulation`.`PopNr` AS `Pop Nr`,`alexande_apflora`.`tblPopulation`.`PopName` AS `Pop Name`,`alexande_apflora`.`DomainPopHerkunft`.`HerkunftTxt` AS `Pop Herkunft`,`alexande_apflora`.`tblPopulation`.`PopBekanntSeit` AS `Pop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopId` AS `TPopId`,`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` AS `TPop Guid`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr` AS `TPop Nr`,`alexande_apflora`.`tblTeilpopulation`.`TPopGemeinde` AS `TPop Gemeinde`,`alexande_apflora`.`tblTeilpopulation`.`TPopFlurname` AS `TPop Flurname`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklar` AS `TPop Status unklar`,`alexande_apflora`.`tblTeilpopulation`.`TPopHerkunftUnklarBegruendung` AS `TPop Begründung für unklaren Status`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `TPop X-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `TPop Y-Koordinaten`,`alexande_apflora`.`tblTeilpopulation`.`TPopRadius` AS `TPop Radius m`,`alexande_apflora`.`tblTeilpopulation`.`TPopHoehe` AS `TPop Höhe`,`alexande_apflora`.`tblTeilpopulation`.`TPopExposition` AS `TPop Exposition`,`alexande_apflora`.`tblTeilpopulation`.`TPopKlima` AS `TPop Klima`,`alexande_apflora`.`tblTeilpopulation`.`TPopNeigung` AS `TPop Hangneigung`,`alexande_apflora`.`tblTeilpopulation`.`TPopBeschr` AS `TPop Beschreibung`,`alexande_apflora`.`tblTeilpopulation`.`TPopKatNr` AS `TPop Kataster-Nr`,`tblAdresse_2`.`AdrName` AS `TPop verantwortlich`,`DomainPopHerkunft_1`.`HerkunftTxt` AS `TPop Herkunft`,`alexande_apflora`.`tblTeilpopulation`.`TPopApBerichtRelevant` AS `TPop für AP-Bericht relevant`,`alexande_apflora`.`tblTeilpopulation`.`TPopBekanntSeit` AS `TPop bekannt seit`,`alexande_apflora`.`tblTeilpopulation`.`TPopEigen` AS `TPop EigentümerIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopKontakt` AS `TPop Kontakt vor Ort`,`alexande_apflora`.`tblTeilpopulation`.`TPopNutzungszone` AS `TPop Nutzungszone`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschafterIn` AS `TPop BewirtschafterIn`,`alexande_apflora`.`tblTeilpopulation`.`TPopBewirtschaftung` AS `TPop Bewirtschaftung`,`vTPopAnzKontr`.`Anzahl Kontrollen` AS `Anzahl Kontrollen`,`vTPopAnzFeldkontr`.`Anzahl Feld-Kontrollen` AS `Anzahl Feld-Kontrollen`,`vTPopAnzFreiwkontr`.`Anzahl Freiwilligen-Kontrollen` AS `Anzahl Freiwilligen-Kontrollen`,`vTPopKontrBerMassnJahre`.`Jahr` AS `Jahr`,`vPopBer`.`PopBer Id` AS `PopBer Id`,`vPopBer`.`PopBer Jahr` AS `PopBer Jahr`,`vPopBer`.`PopBer Entwicklung` AS `PopBer Entwicklung`,`vPopBer`.`PopBer Bemerkungen` AS `PopBer Bemerkungen`,`vPopBer`.`PopBer MutWann` AS `PopBer MutWann`,`vPopBer`.`PopBer MutWer` AS `PopBer MutWer`,`vPopMassnBer`.`PopMassnBer Id` AS `PopMassnBer Id`,`vPopMassnBer`.`PopMassnBer Jahr` AS `PopMassnBer Jahr`,`vPopMassnBer`.`PopMassnBer Entwicklung` AS `PopMassnBer Entwicklung`,`vPopMassnBer`.`PopMassnBer Interpretation` AS `PopMassnBer Interpretation`,`vPopMassnBer`.`PopMassnBer MutWann` AS `PopMassnBer MutWann`,`vPopMassnBer`.`PopMassnBer MutWer` AS `PopMassnBer MutWer`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerId` AS `TPopBer Id`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr` AS `TPopBer Jahr`,`DomainPopEntwicklung_1`.`EntwicklungTxt` AS `TPopBer Entwicklung`,`alexande_apflora`.`tblTeilPopBericht`.`TPopBerTxt` AS `TPopBer Bemerkungen`,`alexande_apflora`.`tblTeilPopBericht`.`MutWann` AS `TPopBer MutWann`,`alexande_apflora`.`tblTeilPopBericht`.`MutWer` AS `TPopBer MutWer`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerId` AS `TPopMassnBer Id`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr` AS `TPopMassnBer Jahr`,`alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilTxt` AS `TPopMassnBer Beurteilung`,`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerTxt` AS `TPopMassnBer Bemerkungen`,`alexande_apflora`.`tblTeilPopMassnBericht`.`MutWann` AS `TPopMassnBer MutWann`,`alexande_apflora`.`tblTeilPopMassnBericht`.`MutWer` AS `TPopMassnBer MutWer`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGuid` AS `Kontr Guid`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr` AS `Kontr Jahr`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrDatum` AS `Kontr Datum`,`alexande_apflora`.`DomainTPopFeldkontrTyp`.`DomainTxt` AS `Kontr Typ`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `Kontr BearbeiterIn`,`alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitTxt` AS `Kontr Zaehleinheit 1`,`alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilTxt` AS `Kontr Methode 1`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz1` AS `Kontr Anzahl 1`,`DomainTPopKontrZaehleinheit_1`.`ZaehleinheitTxt` AS `Kontr Zaehleinheit 2`,`DomainTPopKontrMethode_2`.`BeurteilTxt` AS `Kontr Methode 2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz2` AS `Kontr Anzahl 2`,`DomainTPopKontrZaehleinheit_2`.`ZaehleinheitTxt` AS `Kontr Zaehleinheit 3`,`DomainTPopKontrMethode_1`.`BeurteilTxt` AS `Kontr Methode 3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAnz3` AS `Kontr Anzahl 3`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUeberleb` AS `Kontr Ueberlebensrate`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVitalitaet` AS `Kontr Vitalitaet`,`alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungTxt` AS `Kontr Entwicklung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrsach` AS `Kontr Ursachen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUrteil` AS `Kontr Erfolgsbeurteilung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendUms` AS `Kontr Aend-Vorschlaege Umsetzung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrAendKontr` AS `Kontr Aend-Vorschlaege Kontrolle`,`alexande_apflora`.`tblTeilpopulation`.`TPopXKoord` AS `Kontr X-Koord`,`alexande_apflora`.`tblTeilpopulation`.`TPopYKoord` AS `Kontr Y-Koord`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTxt` AS `Kontr Bemerkungen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLeb` AS `Kontr Lebensraum Delarze`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrLebUmg` AS `Kontr angrenzender Lebensraum Delarze`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegTyp` AS `Kontr Vegetationstyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKonkurrenz` AS `Kontr Konkurrenz`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMoosschicht` AS `Kontr Moosschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrKrautschicht` AS `Kontr Krautschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrStrauchschicht` AS `Kontr Strauchschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBaumschicht` AS `Kontr Baumschicht`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenTyp` AS `Kontr Bodentyp`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenKalkgehalt` AS `Kontr Boden Kalkgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenDurchlaessigkeit` AS `Kontr Boden Durchlaessigkeit`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenHumus` AS `Kontr Boden Hmusgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenNaehrstoffgehalt` AS `Kontr Boden Naehrstoffgehalt`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBodenAbtrag` AS `Kontr Oberbodenabtrag`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrWasserhaushalt` AS `Kontr Wasserhaushalt`,`alexande_apflora`.`DomainTPopKontrIdBiotUebereinst`.`DomainTxt` AS `TPopKontrIdealBiotopUebereinst`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrHandlungsbedarf` AS `TPopKontrHandlungsbedarf`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebFlaeche` AS `TPopKontrUebFlaeche`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrFlaeche` AS `Kontr Flaeche m2`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrPlan` AS `Kontr auf Plan eingezeichnet`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVeg` AS `Kontr Deckung durch Vegetation`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrNaBo` AS `Kontr Deckung nackter Boden`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrUebPfl` AS `Kontr Deckung durch ueberpruefte Art`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJungPflJN` AS `Kontr auch junge Pflanzen`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMax` AS `Kontr maximale Veg-hoehe cm`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrVegHoeMit` AS `Kontr mittlere Veg-hoehe cm`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrGefaehrdung` AS `Kontr Gefaehrdung`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`MutWann` AS `MutWann`,`alexande_apflora`.`tblTeilPopFeldkontrolle`.`MutWer` AS `MutWer` from (((((((((((((((((((`alexande_beob`.`ArtenDb_Arteigenschaften` join `alexande_apflora`.`tblAktionsplan` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) join (`alexande_apflora`.`tblPopulation` join `alexande_apflora`.`tblTeilpopulation` on((`alexande_apflora`.`tblPopulation`.`PopId` = `alexande_apflora`.`tblTeilpopulation`.`PopId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblPopulation`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`DomainPopHerkunft` on((`alexande_apflora`.`tblPopulation`.`PopHerkunft` = `alexande_apflora`.`DomainPopHerkunft`.`HerkunftId`))) left join `alexande_apflora`.`tblAdresse` `tblAdresse_1` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `tblAdresse_1`.`AdrId`))) left join `alexande_apflora`.`tblAdresse` `tblAdresse_2` on((`tblAdresse_2`.`AdrId` = `alexande_apflora`.`tblTeilpopulation`.`TPopVerantw`))) left join `alexande_apflora`.`DomainPopHerkunft` `DomainPopHerkunft_1` on((`DomainPopHerkunft_1`.`HerkunftId` = `alexande_apflora`.`tblTeilpopulation`.`TPopHerkunft`))) left join `vTPopAnzKontr` on((`alexande_apflora`.`tblTeilpopulation`.`TPopGuid` = `vTPopAnzKontr`.`TPop Guid`))) left join `vTPopAnzFreiwkontr` on((`vTPopAnzFreiwkontr`.`TPopId` = `alexande_apflora`.`tblTeilpopulation`.`TPopId`))) left join `vTPopAnzFeldkontr` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `vTPopAnzFeldkontr`.`TPopId`))) left join `vTPopKontrBerMassnJahre` on((`alexande_apflora`.`tblTeilpopulation`.`TPopId` = `vTPopKontrBerMassnJahre`.`TPopId`))) left join ((((((((((`alexande_apflora`.`tblTeilPopFeldkontrolle` left join `alexande_apflora`.`DomainTPopFeldkontrTyp` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrTyp` = `alexande_apflora`.`DomainTPopFeldkontrTyp`.`DomainTxt`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit1` = `alexande_apflora`.`DomainTPopKontrZaehleinheit`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit2` = `DomainTPopKontrZaehleinheit_1`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainTPopKontrZaehleinheit` `DomainTPopKontrZaehleinheit_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrZaehleinheit3` = `DomainTPopKontrZaehleinheit_2`.`ZaehleinheitCode`))) left join `alexande_apflora`.`DomainPopEntwicklung` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrEntwicklung` = `alexande_apflora`.`DomainPopEntwicklung`.`EntwicklungId`))) left join `alexande_apflora`.`DomainTPopKontrMethode` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode1` = `alexande_apflora`.`DomainTPopKontrMethode`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_2` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode2` = `DomainTPopKontrMethode_2`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrMethode` `DomainTPopKontrMethode_1` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrMethode3` = `DomainTPopKontrMethode_1`.`BeurteilCode`))) left join `alexande_apflora`.`DomainTPopKontrIdBiotUebereinst` on((`alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrIdealBiotopUebereinst` = `alexande_apflora`.`DomainTPopKontrIdBiotUebereinst`.`DomainCode`))) on(((`vTPopKontrBerMassnJahre`.`TPopId` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopId`) and (`vTPopKontrBerMassnJahre`.`Jahr` = `alexande_apflora`.`tblTeilPopFeldkontrolle`.`TPopKontrJahr`)))) left join `vPopBer` on((`vTPopKontrBerMassnJahre`.`Jahr` = `vPopBer`.`PopBer Jahr`))) left join `vPopMassnBer` on((`vTPopKontrBerMassnJahre`.`Jahr` = `vPopMassnBer`.`PopMassnBer Jahr`))) left join `alexande_apflora`.`tblTeilPopMassnBericht` on(((`vTPopKontrBerMassnJahre`.`TPopId` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopId`) and (`vTPopKontrBerMassnJahre`.`Jahr` = `alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerJahr`)))) left join `alexande_apflora`.`tblTeilPopBericht` on(((`vTPopKontrBerMassnJahre`.`TPopId` = `alexande_apflora`.`tblTeilPopBericht`.`TPopId`) and (`vTPopKontrBerMassnJahre`.`Jahr` = `alexande_apflora`.`tblTeilPopBericht`.`TPopBerJahr`)))) left join `alexande_apflora`.`DomainPopEntwicklung` `DomainPopEntwicklung_1` on((`alexande_apflora`.`tblTeilPopBericht`.`TPopBerEntwicklung` = `DomainPopEntwicklung_1`.`EntwicklungId`))) left join `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung` on((`alexande_apflora`.`tblTeilPopMassnBericht`.`TPopMassnBerErfolgsbeurteilung` = `alexande_apflora`.`DomainTPopMassnErfolgsbeurteilung`.`BeurteilId`))) where ((`vPopBer`.`Pop Guid` = `alexande_apflora`.`tblPopulation`.`PopGuid`) and (`vPopMassnBer`.`Pop Guid` = `alexande_apflora`.`tblPopulation`.`PopGuid`)) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblPopulation`.`PopNr`,`alexande_apflora`.`tblTeilpopulation`.`TPopNr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vUmwfakt`
--
DROP TABLE IF EXISTS `vUmwfakt`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vUmwfakt` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `AP ApArtId`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Bearbeitungsstand`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `AP verantwortlich`,`alexande_apflora`.`tblAktionsplan`.`MutWann` AS `AP Letzte Änderung`,`alexande_apflora`.`tblAktionsplan`.`MutWer` AS `AP Letzte(r) Bearbeiter(in)`,`alexande_apflora`.`tblUmweltFaktoren`.`UfApArtId` AS `Uf ApArtId`,`alexande_apflora`.`tblUmweltFaktoren`.`UfErstelldatum` AS `Uf Erstelldatum`,`alexande_apflora`.`tblUmweltFaktoren`.`UfHoehenlage` AS `Uf Hoehenlage`,`alexande_apflora`.`tblUmweltFaktoren`.`UfRegion` AS `Uf Region`,`alexande_apflora`.`tblUmweltFaktoren`.`UfExposition` AS `Uf Exposition`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBesonnung` AS `Uf Besonnung`,`alexande_apflora`.`tblUmweltFaktoren`.`UfHangneigung` AS `Uf Hangneigung`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBodenTyp` AS `Uf Bodentyp`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBodenKalkgehalt` AS `Uf Boden Kalkgehalt`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBodenDurchlaessigkeit` AS `Uf Boden Durchlaessigkeit`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBodenHumus` AS `Uf Boden Humus`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBodenNaehrstoffgehalt` AS `Uf Boden Naehrstoffgehalt`,`alexande_apflora`.`tblUmweltFaktoren`.`UfWasserhaushalt` AS `Uf Wasserhaushalt`,`alexande_apflora`.`tblUmweltFaktoren`.`UfKonkurrenz` AS `Uf Konkurrenz`,`alexande_apflora`.`tblUmweltFaktoren`.`UfMoosschicht` AS `Uf Moosschicht`,`alexande_apflora`.`tblUmweltFaktoren`.`UfKrautschicht` AS `Uf Krautschicht`,`alexande_apflora`.`tblUmweltFaktoren`.`UfStrauchschicht` AS `Uf Strauchschicht`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBaumschicht` AS `Uf Baumschicht`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBemerkungen` AS `Uf Bemerkungen`,`alexande_apflora`.`tblUmweltFaktoren`.`MutWann` AS `Uf MutWann`,`alexande_apflora`.`tblUmweltFaktoren`.`MutWer` AS `Uf MutWer` from (`alexande_apflora`.`tblUmweltFaktoren` left join ((((`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblUmweltFaktoren`.`UfApArtId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblUmweltFaktoren`.`UfErstelldatum`;

-- --------------------------------------------------------

--
-- Struktur des Views `vUmwfaktOhneAp`
--
DROP TABLE IF EXISTS `vUmwfaktOhneAp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vUmwfaktOhneAp` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `AP ApArtId`,`alexande_apflora`.`tblUmweltFaktoren`.`UfApArtId` AS `Uf ApArtId`,`alexande_apflora`.`tblUmweltFaktoren`.`UfErstelldatum` AS `Uf Erstelldatum`,`alexande_apflora`.`tblUmweltFaktoren`.`UfHoehenlage` AS `Uf Hoehenlage`,`alexande_apflora`.`tblUmweltFaktoren`.`UfRegion` AS `Uf Region`,`alexande_apflora`.`tblUmweltFaktoren`.`UfExposition` AS `Uf Exposition`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBesonnung` AS `Uf Besonnung`,`alexande_apflora`.`tblUmweltFaktoren`.`UfHangneigung` AS `Uf Hangneigung`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBodenTyp` AS `Uf Bodentyp`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBodenKalkgehalt` AS `Uf Boden Kalkgehalt`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBodenDurchlaessigkeit` AS `Uf Boden Durchlaessigkeit`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBodenHumus` AS `Uf Boden Humus`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBodenNaehrstoffgehalt` AS `Uf Boden Naehrstoffgehalt`,`alexande_apflora`.`tblUmweltFaktoren`.`UfWasserhaushalt` AS `Uf Wasserhaushalt`,`alexande_apflora`.`tblUmweltFaktoren`.`UfKonkurrenz` AS `Uf Konkurrenz`,`alexande_apflora`.`tblUmweltFaktoren`.`UfMoosschicht` AS `Uf Moosschicht`,`alexande_apflora`.`tblUmweltFaktoren`.`UfKrautschicht` AS `Uf Krautschicht`,`alexande_apflora`.`tblUmweltFaktoren`.`UfStrauchschicht` AS `Uf Strauchschicht`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBaumschicht` AS `Uf Baumschicht`,`alexande_apflora`.`tblUmweltFaktoren`.`UfBemerkungen` AS `Uf Bemerkungen`,`alexande_apflora`.`tblUmweltFaktoren`.`MutWann` AS `Uf MutWann`,`alexande_apflora`.`tblUmweltFaktoren`.`MutWer` AS `Uf MutWer` from (`alexande_apflora`.`tblUmweltFaktoren` left join ((((`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblUmweltFaktoren`.`UfApArtId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) where isnull(`alexande_apflora`.`tblAktionsplan`.`ApArtId`) order by `alexande_apflora`.`tblUmweltFaktoren`.`UfErstelldatum`;

-- --------------------------------------------------------

--
-- Struktur des Views `vZielBer`
--
DROP TABLE IF EXISTS `vZielBer`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vZielBer` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `AP Id`,`alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname` AS `AP Art`,`alexande_apflora`.`DomainApBearbeitungsstand`.`DomainTxt` AS `AP Status`,`alexande_apflora`.`tblAktionsplan`.`ApJahr` AS `AP Start im Jahr`,`alexande_apflora`.`DomainApUmsetzung`.`DomainTxt` AS `AP Stand Umsetzung`,`alexande_apflora`.`tblAdresse`.`AdrName` AS `AP verantwortlich`,`alexande_apflora`.`tblZiel`.`ZielId` AS `Ziel Id`,`alexande_apflora`.`tblZiel`.`ZielJahr` AS `Ziel Jahr`,`alexande_apflora`.`DomainZielTyp`.`ZieltypTxt` AS `Ziel Typ`,`alexande_apflora`.`tblZiel`.`ZielBezeichnung` AS `Ziel Beschreibung`,`alexande_apflora`.`tblZielBericht`.`ZielBerId` AS `ZielBer Id`,`alexande_apflora`.`tblZielBericht`.`ZielId` AS `ZielBer ZielId`,`alexande_apflora`.`tblZielBericht`.`ZielBerJahr` AS `ZielBer Jahr`,`alexande_apflora`.`tblZielBericht`.`ZielBerErreichung` AS `ZielBer Erreichung`,`alexande_apflora`.`tblZielBericht`.`ZielBerTxt` AS `ZielBer Bemerkungen`,`alexande_apflora`.`tblZielBericht`.`MutWann` AS `ZielBer MutWann`,`alexande_apflora`.`tblZielBericht`.`MutWer` AS `ZielBer MutWer` from (`alexande_apflora`.`tblZielBericht` left join ((`alexande_apflora`.`tblZiel` left join ((((`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblZiel`.`ApArtId`))) left join `alexande_apflora`.`DomainZielTyp` on((`alexande_apflora`.`tblZiel`.`ZielTyp` = `alexande_apflora`.`DomainZielTyp`.`ZieltypId`))) on((`alexande_apflora`.`tblZiel`.`ZielId` = `alexande_apflora`.`tblZielBericht`.`ZielId`))) order by `alexande_beob`.`ArtenDb_Arteigenschaften`.`Artname`,`alexande_apflora`.`tblZiel`.`ZielJahr`,`alexande_apflora`.`DomainZielTyp`.`ZieltypTxt`,`alexande_apflora`.`tblZiel`.`ZielTyp`,`alexande_apflora`.`tblZielBericht`.`ZielBerJahr`;

-- --------------------------------------------------------

--
-- Struktur des Views `vZielBerOhneZiel`
--
DROP TABLE IF EXISTS `vZielBerOhneZiel`;

CREATE ALGORITHM=UNDEFINED DEFINER=`alexande`@`localhost` SQL SECURITY DEFINER VIEW `vZielBerOhneZiel` AS select `alexande_apflora`.`tblAktionsplan`.`ApArtId` AS `AP Id`,`alexande_apflora`.`tblZiel`.`ZielId` AS `Ziel Id`,`alexande_apflora`.`tblZielBericht`.`ZielBerId` AS `ZielBer Id`,`alexande_apflora`.`tblZielBericht`.`ZielId` AS `ZielBer ZielId`,`alexande_apflora`.`tblZielBericht`.`ZielBerJahr` AS `ZielBer Jahr`,`alexande_apflora`.`tblZielBericht`.`ZielBerErreichung` AS `ZielBer Erreichung`,`alexande_apflora`.`tblZielBericht`.`ZielBerTxt` AS `ZielBer Bemerkungen`,`alexande_apflora`.`tblZielBericht`.`MutWann` AS `ZielBer MutWann`,`alexande_apflora`.`tblZielBericht`.`MutWer` AS `ZielBer MutWer` from (`alexande_apflora`.`tblZielBericht` left join ((`alexande_apflora`.`tblZiel` left join ((((`alexande_apflora`.`tblAktionsplan` left join `alexande_beob`.`ArtenDb_Arteigenschaften` on((`alexande_beob`.`ArtenDb_Arteigenschaften`.`TaxonomieId` = `alexande_apflora`.`tblAktionsplan`.`ApArtId`))) left join `alexande_apflora`.`DomainApBearbeitungsstand` on((`alexande_apflora`.`tblAktionsplan`.`ApStatus` = `alexande_apflora`.`DomainApBearbeitungsstand`.`DomainCode`))) left join `alexande_apflora`.`DomainApUmsetzung` on((`alexande_apflora`.`tblAktionsplan`.`ApUmsetzung` = `alexande_apflora`.`DomainApUmsetzung`.`DomainCode`))) left join `alexande_apflora`.`tblAdresse` on((`alexande_apflora`.`tblAktionsplan`.`ApBearb` = `alexande_apflora`.`tblAdresse`.`AdrId`))) on((`alexande_apflora`.`tblAktionsplan`.`ApArtId` = `alexande_apflora`.`tblZiel`.`ApArtId`))) left join `alexande_apflora`.`DomainZielTyp` on((`alexande_apflora`.`tblZiel`.`ZielTyp` = `alexande_apflora`.`DomainZielTyp`.`ZieltypId`))) on((`alexande_apflora`.`tblZiel`.`ZielId` = `alexande_apflora`.`tblZielBericht`.`ZielId`))) where isnull(`alexande_apflora`.`tblZiel`.`ZielId`) order by `alexande_apflora`.`tblZiel`.`ZielTyp`,`alexande_apflora`.`tblZielBericht`.`ZielBerJahr`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
