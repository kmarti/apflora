-- phpMyAdmin SQL Dump
-- version 3.5.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 01. Okt 2013 um 03:31
-- Server Version: 5.1.70-cll
-- PHP-Version: 5.3.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `alexande_apflora`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ArtenDb_LR`
--

CREATE TABLE IF NOT EXISTS `ArtenDb_LR` (
  `Id` int(10) NOT NULL AUTO_INCREMENT,
  `LrMethodId` int(10) DEFAULT NULL,
  `ENr` int(10) DEFAULT NULL,
  `Label` varchar(50) DEFAULT NULL,
  `Einheit` varchar(255) DEFAULT NULL,
  `ELat` varchar(255) DEFAULT NULL,
  `EEngl` varchar(50) DEFAULT NULL,
  `EFranz` varchar(50) DEFAULT NULL,
  `EItal` varchar(50) DEFAULT NULL,
  `Bemerkungen` longtext,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `ENr` (`ENr`),
  KEY `{6C5CEB02-785D-4F91-A85C-E0CB91` (`LrMethodId`),
  KEY `Id` (`Id`),
  KEY `Label` (`Label`),
  KEY `LrMethodId` (`LrMethodId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5810 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainApBearbeitungsstand`
--

CREATE TABLE IF NOT EXISTS `DomainApBearbeitungsstand` (
  `DomainCode` int(10) NOT NULL DEFAULT '0',
  `DomainTxt` varchar(50) DEFAULT NULL,
  `DomainOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`DomainCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Domain: Bearbeitungsstand des APs';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainApErfKrit`
--

CREATE TABLE IF NOT EXISTS `DomainApErfKrit` (
  `BeurteilId` int(10) NOT NULL AUTO_INCREMENT,
  `BeurteilTxt` varchar(50) DEFAULT NULL COMMENT 'Wie werden die durchgefuehrten Massnahmen beurteilt?',
  `BeurteilOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`BeurteilId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Domain: Skala fuer die Beurteilung des Erfolgs des APs' AUTO_INCREMENT=1168274205 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainApUmsetzung`
--

CREATE TABLE IF NOT EXISTS `DomainApUmsetzung` (
  `DomainCode` int(10) NOT NULL,
  `DomainTxt` varchar(50) DEFAULT NULL,
  `DomainOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`DomainCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Domain: Umsetzungsstand des APs';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainErfBeurtKrit`
--

CREATE TABLE IF NOT EXISTS `DomainErfBeurtKrit` (
  `DomainCode` int(10) NOT NULL,
  `DomainTxt` varchar(50) DEFAULT NULL,
  `DomainOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`DomainCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Domain: Kriterien fuer die Beurteilung des Erfolgs des APs';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainFloraStatus`
--

CREATE TABLE IF NOT EXISTS `DomainFloraStatus` (
  `StatusWert` char(2) NOT NULL DEFAULT '',
  `StatusText` text NOT NULL,
  PRIMARY KEY (`StatusWert`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainGemeinden`
--

CREATE TABLE IF NOT EXISTS `DomainGemeinden` (
  `BfsNr` int(11) NOT NULL DEFAULT '0',
  `GmdName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`BfsNr`),
  KEY `GmdName` (`GmdName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainPopEntwicklung`
--

CREATE TABLE IF NOT EXISTS `DomainPopEntwicklung` (
  `EntwicklungId` int(10) NOT NULL AUTO_INCREMENT,
  `EntwicklungTxt` varchar(50) DEFAULT NULL,
  `EntwicklungOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`EntwicklungId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Domain fuer die Populationsentwicklung' AUTO_INCREMENT=100 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainPopHerkunft`
--

CREATE TABLE IF NOT EXISTS `DomainPopHerkunft` (
  `HerkunftId` int(10) NOT NULL AUTO_INCREMENT,
  `HerkunftTxt` varchar(50) DEFAULT NULL COMMENT 'Beschreibung der Herkunft',
  `HerkunftOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  `ZdsfVorhanden` text NOT NULL COMMENT 'Wert im Feld Vorhandensein beim ZDSF',
  `ZdsfHerkunft` text NOT NULL COMMENT 'Wert im Feld Herkunft beim ZDSF',
  PRIMARY KEY (`HerkunftId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Domain fuer die Charakterisierung der Population' AUTO_INCREMENT=1200498804 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainTPopApBerichtRelevant`
--

CREATE TABLE IF NOT EXISTS `DomainTPopApBerichtRelevant` (
  `DomainCode` int(10) NOT NULL AUTO_INCREMENT,
  `DomainTxt` text,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`DomainCode`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainTPopEntwicklung`
--

CREATE TABLE IF NOT EXISTS `DomainTPopEntwicklung` (
  `EntwicklungCode` int(10) NOT NULL,
  `EntwicklungTxt` varchar(50) DEFAULT NULL,
  `EntwicklungOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`EntwicklungCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Domain fuer die Entwicklung einer Teilpopulation';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainTPopFeldkontrTyp`
--

CREATE TABLE IF NOT EXISTS `DomainTPopFeldkontrTyp` (
  `DomainCode` int(10) NOT NULL,
  `DomainTxt` varchar(50) DEFAULT NULL,
  `DomainOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`DomainCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Domain fuer die Typisierung der Feldkontrolle einer Teilpop';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainTPopKontrIdBiotUebereinst`
--

CREATE TABLE IF NOT EXISTS `DomainTPopKontrIdBiotUebereinst` (
  `DomainCode` int(10) NOT NULL,
  `DomainTxt` varchar(50) DEFAULT NULL,
  `DomainOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`DomainCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Domain: Kriterien fuer die Beurteilung des Erfolgs des APs';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainTPopKontrMethode`
--

CREATE TABLE IF NOT EXISTS `DomainTPopKontrMethode` (
  `BeurteilCode` int(10) NOT NULL,
  `BeurteilTxt` varchar(50) DEFAULT NULL,
  `BeurteilOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`BeurteilCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Domain fuer die Methode der Feldkontrolle einer Teilpop.';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainTPopKontrZaehleinheit`
--

CREATE TABLE IF NOT EXISTS `DomainTPopKontrZaehleinheit` (
  `ZaehleinheitCode` int(10) NOT NULL,
  `ZaehleinheitTxt` varchar(50) DEFAULT NULL,
  `ZaehleinheitOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`ZaehleinheitCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Domain fuer Zaehleinheiten einer Teilpopulation';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainTPopMassnErfolgsbeurteilung`
--

CREATE TABLE IF NOT EXISTS `DomainTPopMassnErfolgsbeurteilung` (
  `BeurteilId` int(10) NOT NULL AUTO_INCREMENT,
  `BeurteilTxt` varchar(50) DEFAULT NULL COMMENT 'Wie werden die durchgefuehrten Massnahmen beurteilt?',
  `BeurteilOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`BeurteilId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Domain fur die Erfolgsbeurteilung von Massnahmen einer TPop' AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainTPopMassnTyp`
--

CREATE TABLE IF NOT EXISTS `DomainTPopMassnTyp` (
  `MassnTypCode` int(10) NOT NULL,
  `MassnTypTxt` varchar(50) DEFAULT NULL,
  `MassnTypOrd` smallint(5) DEFAULT NULL,
  `MassnAnsiedlung` tinyint(1) NOT NULL COMMENT 'Handelt es sich um eine Ansiedlung?',
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`MassnTypCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Domain fuer die Typisierung von Massnahmen einer Teilpop';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `DomainZielTyp`
--

CREATE TABLE IF NOT EXISTS `DomainZielTyp` (
  `ZieltypId` int(10) NOT NULL AUTO_INCREMENT,
  `ZieltypTxt` varchar(50) DEFAULT NULL COMMENT 'Beschreibung des Ziels',
  `ZieltypOrd` smallint(5) DEFAULT NULL,
  `MutWann` datetime DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) NOT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`ZieltypId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Domain fuer den Typ von Zielen eines APs' AUTO_INCREMENT=1170775557 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblAdresse`
--

CREATE TABLE IF NOT EXISTS `tblAdresse` (
  `AdrId` int(10) NOT NULL AUTO_INCREMENT,
  `AdrName` varchar(255) DEFAULT NULL,
  `AdrAdresse` varchar(255) DEFAULT NULL,
  `AdrTel` varchar(255) DEFAULT NULL,
  `AdrEmail` varchar(255) DEFAULT NULL,
  `freiwErfko` int(10) DEFAULT NULL,
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`AdrId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Adressdaten' AUTO_INCREMENT=2130770338 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblAktionsplan`
--

CREATE TABLE IF NOT EXISTS `tblAktionsplan` (
  `ApArtId` int(10) NOT NULL COMMENT 'ID der Tabelle tblAktionsplan. nein SISF-Nr aus tblFloraSisf',
  `ApStatus` int(10) DEFAULT NULL COMMENT 'In welchem Bearbeitungsstand befindet sich der AP?',
  `ApJahr` smallint(5) DEFAULT NULL COMMENT 'Wann wurde mit der Umsetzung des Aktionsplans begonnen?',
  `ApUmsetzung` int(10) DEFAULT NULL COMMENT 'In welchem Umsetzungsstand befindet sich der AP?',
  `ApBearb` int(10) DEFAULT NULL COMMENT 'Verantwortliche fuer die Art',
  `ApGuid` varchar(38) DEFAULT NULL COMMENT 'ACHTUNG: GUID ist die GUID der Art in der ArtenDb, nicht diese. NICHT BENUTZEN',
  `ApArtwert` int(11) DEFAULT NULL COMMENT 'redundant aber erspart viele Abfragen',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`ApArtId`),
  KEY `ApGuid` (`ApGuid`),
  KEY `ApStatus` (`ApStatus`),
  KEY `ApUmsetzung` (`ApUmsetzung`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Angaben zu Aktionsplaenen';

--
-- Trigger `tblAktionsplan`
--
DROP TRIGGER IF EXISTS `newguidap`;
DELIMITER //
CREATE TRIGGER `newguidap` BEFORE INSERT ON `tblAktionsplan`
 FOR EACH ROW set new.ApGuid = UUID()
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblAssozArten`
--

CREATE TABLE IF NOT EXISTS `tblAssozArten` (
  `AaId` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle tblIbArtenAssoz',
  `AaApArtId` int(11) NOT NULL COMMENT 'Fremdschluessel aus der Tabelle tblAktionsplan',
  `AaSisfNr` int(11) NOT NULL COMMENT 'Assoziierte Art (SisfNr)',
  `AaBem` text COMMENT 'Bemerkungen zur Assoziation',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Wer hat den Datensatz zuletzt geaendert?',
  PRIMARY KEY (`AaId`),
  KEY `IbaassApArtId` (`AaApArtId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Assoziierte Arten' AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblBeobZuordnung`
--

CREATE TABLE IF NOT EXISTS `tblBeobZuordnung` (
  `NO_NOTE` varchar(38) DEFAULT NULL,
  `TPopId` int(10) DEFAULT NULL,
  `BeobNichtZuordnen` tinyint(1) DEFAULT NULL,
  `BeobBemerkungen` longtext,
  `BeobMutWann` date DEFAULT NULL,
  `BeobMutWer` varchar(20) DEFAULT NULL,
  KEY `no_note` (`NO_NOTE`),
  KEY `tpopid` (`TPopId`),
  KEY `beobnichtzuordnen` (`BeobNichtZuordnen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblBer`
--

CREATE TABLE IF NOT EXISTS `tblBer` (
  `BerId` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle Berichte',
  `ApArtId` int(10) DEFAULT NULL COMMENT 'ID aus der Tabelle tblAktionsplan',
  `BerAutor` varchar(150) DEFAULT NULL COMMENT 'Autor des Berichts',
  `BerJahr` smallint(5) DEFAULT NULL COMMENT 'Jahr der Publikation',
  `BerTitel` varchar(255) DEFAULT NULL COMMENT 'Titel des Berichts',
  `BerURL` varchar(255) DEFAULT NULL COMMENT 'Link zum Bericht',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`BerId`),
  KEY `ApArtId` (`ApArtId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Berichte zu AP-Arten' AUTO_INCREMENT=27 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblErfKrit`
--

CREATE TABLE IF NOT EXISTS `tblErfKrit` (
  `ErfkritId` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle tblErfBeurtZielSkala',
  `ApArtId` int(10) DEFAULT NULL COMMENT 'ID der Tabelle tblAktionsplan',
  `ErfkritErreichungsgrad` int(10) DEFAULT NULL COMMENT 'Wie gut wurden die Ziele erreicht?',
  `ErfkritTxt` varchar(255) DEFAULT NULL COMMENT 'Beschreibung der Kriterien fuer den Erreichungsgrad',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`ErfkritId`),
  KEY `ApArtId` (`ApArtId`),
  KEY `ErfBeurtZielSkalaErreichungsgrad` (`ErfkritErreichungsgrad`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Domain. Skala fuer die Beurteilung des Erfolgs des AP' AUTO_INCREMENT=1980375827 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblJBer`
--

CREATE TABLE IF NOT EXISTS `tblJBer` (
  `JBerId` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle tblApBericht',
  `ApArtId` int(10) DEFAULT NULL COMMENT 'ID der Tabellle tblAktionsplan',
  `JBerJahr` smallint(5) DEFAULT NULL COMMENT 'Fuer welches Jahr gilt der Bericht?',
  `JBerSituation` longtext COMMENT 'Beschreibung der Situation im Berichtjahr',
  `JBerVergleichVorjahrGesamtziel` longtext COMMENT 'Vergleich zu Vorjahr und Ausblick auf das Gesamtziel',
  `JBerBeurteilung` int(10) DEFAULT NULL COMMENT 'Beurteilung des Erfolgs des Aktionsplans bisher',
  `JBerVeraenGegenVorjahr` varchar(2) DEFAULT NULL COMMENT 'Veraenderung gegenueber Vorjahr: plus heisst aufgestiegen, minus heisst abgestiegen',
  `JBerAnalyse` varchar(255) DEFAULT NULL COMMENT 'Was sind die Ursachen fuer die beobachtete Entwicklung?',
  `JBerUmsetzung` longtext COMMENT 'Konsequenzen fuer die Umsetzung',
  `JBerErfko` longtext COMMENT 'Konsequenzen fuer die Erfolgskontrolle',
  `JBerATxt` longtext COMMENT 'Bemerkungen zum Aussagebereich A: Grundmengen und getroffene Massnahmen',
  `JBerBTxt` longtext COMMENT 'Bemerkungen zum Aussagebereich B: Bestandeskontrolle',
  `JBerCTxt` longtext COMMENT 'Bemerkungen zum Aussagebereich C: Zwischenbilanz zur Wirkung von Massnahmen',
  `JBerDTxt` longtext COMMENT 'Bemerkungen zum Aussagebereich D: Einschaetzung der Wirkung des AP insgesamt pro Art',
  `JBerDatum` date DEFAULT NULL COMMENT 'Datum der Nachfuehrung',
  `JBerBearb` int(10) DEFAULT NULL COMMENT 'BerichtsverfasserIn: tblAdr',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`JBerId`),
  KEY `ApArtId` (`ApArtId`),
  KEY `ApBerBeurteilung` (`JBerBeurteilung`),
  KEY `ApBerBearb` (`JBerBearb`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Jahresberichte zu den APs' AUTO_INCREMENT=2143994627 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblJBerUebersicht`
--

CREATE TABLE IF NOT EXISTS `tblJBerUebersicht` (
  `JbuJahr` smallint(5) NOT NULL,
  `JbuBemerkungen` longtext COMMENT 'Bemerkungen zur Artuebersicht',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`JbuJahr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Bemerkungen zur Artuebersicht im Jahresbericht';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblKonstanten`
--

CREATE TABLE IF NOT EXISTS `tblKonstanten` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `JBerJahr` smallint(5) DEFAULT NULL COMMENT 'Fuer dieses Jahr wird der Jahresbericht angezeigt',
  `ApArtId` int(10) DEFAULT NULL COMMENT 'Von Access aus eine Art waehlen, um schnelle views zu ermoeglichen',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2013 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblPopBericht`
--

CREATE TABLE IF NOT EXISTS `tblPopBericht` (
  `PopBerId` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle tblPopBericht',
  `PopId` int(10) DEFAULT NULL COMMENT 'ID der Tabelle tblPopulation',
  `PopBerJahr` smallint(5) DEFAULT NULL COMMENT 'Fuer welches Jahr gilt der Bericht?',
  `PopBerEntwicklung` int(10) DEFAULT NULL COMMENT 'Beurteilung der Populationsentwicklung: nein DomainEntwicklung',
  `PopBerTxt` longtext COMMENT 'Bemerkungen zur Beurteilung',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`PopBerId`),
  KEY `PopId` (`PopId`),
  KEY `PopBerEntwicklung` (`PopBerEntwicklung`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Berichte ueber Populationen' AUTO_INCREMENT=2146903350 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblPopMassnBericht`
--

CREATE TABLE IF NOT EXISTS `tblPopMassnBericht` (
  `PopMassnBerId` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle tblPopMassnBericht',
  `PopId` int(10) DEFAULT NULL COMMENT 'ID der Tabelle tblPopulation',
  `PopMassnBerJahr` smallint(5) DEFAULT NULL COMMENT 'Fuer welches Jahr gilt der Bericht?',
  `PopMassnBerErfolgsbeurteilung` int(10) DEFAULT NULL COMMENT 'Wie wird die Wirkung aller im Rahmen des AP durchgefuehrten Massnahmen beurteilt?',
  `PopMassnBerTxt` longtext COMMENT 'Bemerkungen zur Beurteilung',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`PopMassnBerId`),
  KEY `PopId` (`PopId`),
  KEY `PopMassnBerErfolgsbeurteilung` (`PopMassnBerErfolgsbeurteilung`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Berichte ueber Massnahmen' AUTO_INCREMENT=2143136907 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblPopulation`
--

CREATE TABLE IF NOT EXISTS `tblPopulation` (
  `PopId` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle tblPopulation',
  `ApArtId` int(10) DEFAULT NULL COMMENT 'Fremdschluessel aus der Tabelle tblAktionsplan',
  `PopNr` int(10) DEFAULT NULL COMMENT 'Nummer der Population',
  `PopName` varchar(150) DEFAULT NULL COMMENT 'Bezeichnung der Population',
  `PopHerkunft` int(10) DEFAULT NULL COMMENT 'Herkunft der Population: autochthon oder angesiedelt? Aus DomainPopHerkunft',
  `PopHerkunftUnklar` tinyint(1) DEFAULT NULL,
  `PopHerkunftUnklarBegruendung` varchar(255) DEFAULT NULL,
  `PopBekanntSeit` smallint(5) DEFAULT NULL COMMENT 'Seit wann ist die Population bekannt?',
  `PopXKoord` int(10) DEFAULT NULL COMMENT 'Wird in der Regel von TPop uebernommen',
  `PopYKoord` int(10) DEFAULT NULL COMMENT 'Wird in der Regel von TPop uebernommen',
  `PopPolygon` polygon DEFAULT NULL,
  `PopGuid` varchar(40) DEFAULT NULL,
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`PopId`),
  KEY `ApArtId` (`ApArtId`),
  KEY `PopGuid` (`PopGuid`),
  KEY `PopHerkunft` (`PopHerkunft`),
  KEY `PopXKoord` (`PopXKoord`,`PopYKoord`),
  KEY `popykoord` (`PopYKoord`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Angaben zu Populationen' AUTO_INCREMENT=2146169399 ;

--
-- Trigger `tblPopulation`
--
DROP TRIGGER IF EXISTS `newguidp`;
DELIMITER //
CREATE TRIGGER `newguidp` BEFORE INSERT ON `tblPopulation`
 FOR EACH ROW set new.PopGuid = UUID()
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblTeilPopBericht`
--

CREATE TABLE IF NOT EXISTS `tblTeilPopBericht` (
  `TPopBerId` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle tblTeilPopBericht',
  `TPopId` int(10) DEFAULT NULL COMMENT 'ID der Tabelle tblTeilpopulation',
  `TPopBerJahr` smallint(5) DEFAULT NULL COMMENT 'Fuer welches Jahr gilt der Bericht?',
  `TPopBerEntwicklung` int(10) DEFAULT NULL COMMENT 'Beurteilung der Populationsentwicklung: nein DomainPopEntwicklung',
  `TPopBerTxt` longtext COMMENT 'Bemerkungen zur Beurteilung',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`TPopBerId`),
  KEY `TPopId` (`TPopId`),
  KEY `TPopBerEntwicklung` (`TPopBerEntwicklung`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Berichte zu Teilpopulationen' AUTO_INCREMENT=2143682801 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblTeilPopFeldkontrolle`
--

CREATE TABLE IF NOT EXISTS `tblTeilPopFeldkontrolle` (
  `TPopKontrId` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle tblTeilPopKontrolle',
  `TPopId` int(10) DEFAULT NULL COMMENT 'ID der Tabelle tblTeilpopulation',
  `TPopKontrTyp` varchar(50) DEFAULT NULL COMMENT 'Erfolgskontrolle, Ausgangszustand, Zwischenbeurteilung, Zwischenziel, Ziel, "Freiwilligen-Erfolgskontrolle". Aus DomainTPopFeldkontrTyp',
  `TPopKontrDatum` date DEFAULT NULL COMMENT 'Wann wurde die Kontrolle durchgefuehrt?',
  `TPopKontrJahr` smallint(5) DEFAULT NULL COMMENT 'In welchem Jahr wurde die Kontrolle durchgefuehrt? Fuer welches Jahr soll die Beschreibung gelten?',
  `TPopKontrBearb` int(10) DEFAULT NULL COMMENT 'BearbeiterIn Kontrolle: tblAdr',
  `TPopKontrZaehleinheit1` int(10) DEFAULT NULL COMMENT 'Verwendete Zaehleinheit. Aus DomainTPopKontrZaehleinheit',
  `TPopKontrMethode1` int(10) DEFAULT NULL COMMENT 'Geschaetzt oder gezaehlt? Aus DomainTPopKontrMethode',
  `TPopKontrAnz1` int(10) DEFAULT NULL COMMENT 'Anzahl Zaehleinheit 1',
  `TPopKontrZaehleinheit2` int(10) DEFAULT NULL COMMENT 'Verwendete Zaehleinheit. Aus DomainTPopKontrZaehleinheit',
  `TPopKontrMethode2` int(10) DEFAULT NULL COMMENT 'Geschaetzt oder gezaehlt? Aus DomainTPopKontrMethode',
  `TPopKontrAnz2` int(10) DEFAULT NULL COMMENT 'Anzahl Zaehleinheit 2',
  `TPopKontrZaehleinheit3` int(10) DEFAULT NULL COMMENT 'Verwendete Zaehleinheit. Aus DomainTPopKontrZaehleinheit',
  `TPopKontrMethode3` int(10) DEFAULT NULL COMMENT 'Geschaetzt oder gezaehlt? Aus DomainTPopKontrMethode',
  `TPopKontrAnz3` int(10) DEFAULT NULL COMMENT 'Anzahl Zaehleinheit 3',
  `TPopKontrJungpfl` int(10) DEFAULT NULL COMMENT 'Anzahl Jungpflanzen',
  `TPopKontrVitalitaet` varchar(255) DEFAULT NULL COMMENT 'Vitalitaet der Pflanzen',
  `TPopKontrUeberleb` smallint(5) DEFAULT NULL COMMENT 'Ueberlebensrate (%)',
  `TPopKontrEntwicklung` int(10) DEFAULT NULL COMMENT 'Entwicklung des Bestandes: DomainTPopEntwicklung',
  `TPopKontrUrsach` varchar(255) DEFAULT NULL COMMENT 'Ursachen der Entwicklung',
  `TPopKontrUrteil` varchar(255) DEFAULT NULL COMMENT 'Erfolgsbeurteilung',
  `TPopKontrAendUms` varchar(255) DEFAULT NULL COMMENT 'Aenderungsvorschlag Umsetzung',
  `TPopKontrAendKontr` varchar(255) DEFAULT NULL COMMENT 'Aenderungsvorschlag Erfolgskontrolle',
  `TPopKontrTxt` longtext COMMENT 'Bemerkungen zur Erfolgskontrolle',
  `TPopKontrLeb` varchar(255) DEFAULT NULL COMMENT 'Lebensraumtyp nach Delarze',
  `TPopKontrFlaeche` int(10) DEFAULT NULL COMMENT 'Flaeche der Teilpopulation',
  `TPopKontrLebUmg` varchar(255) DEFAULT NULL COMMENT 'Lebensraumtyp der direkt angrenzenden Umgebung (nach Delarze)',
  `TPopKontrVegTyp` varchar(100) DEFAULT NULL COMMENT 'Vegetationstyp',
  `TPopKontrKonkurrenz` varchar(100) DEFAULT NULL COMMENT 'Konkurrenz',
  `TPopKontrMoosschicht` varchar(100) DEFAULT NULL COMMENT 'Moosschicht',
  `TPopKontrKrautschicht` varchar(100) DEFAULT NULL COMMENT 'Krautschicht',
  `TPopKontrStrauchschicht` varchar(255) DEFAULT NULL COMMENT 'Strauchschicht, ehem. Verbuschung (%)',
  `TPopKontrBaumschicht` varchar(100) DEFAULT NULL COMMENT 'Baumschicht',
  `TPopKontrBodenTyp` varchar(255) DEFAULT NULL COMMENT 'Bodentyp',
  `TPopKontrBodenKalkgehalt` varchar(100) DEFAULT NULL COMMENT 'Kalkgehalt des Bodens',
  `TPopKontrBodenDurchlaessigkeit` varchar(100) DEFAULT NULL COMMENT 'Durchlaessigkeit des Bodens',
  `TPopKontrBodenHumus` varchar(100) DEFAULT NULL COMMENT 'Humusgehalt des Bodens',
  `TPopKontrBodenNaehrstoffgehalt` varchar(100) DEFAULT NULL COMMENT 'Naehrstoffgehalt des Bodens',
  `TPopKontrBodenAbtrag` varchar(255) DEFAULT NULL COMMENT 'Oberbodenabtrag',
  `TPopKontrWasserhaushalt` varchar(255) DEFAULT NULL COMMENT 'Wasserhaushalt',
  `TPopKontrIdealBiotopUebereinst` int(10) DEFAULT NULL COMMENT 'Uebereinstimmung mit dem Idealbiotop',
  `TPopKontrHandlungsbedarf` longtext COMMENT 'Handlungsbedarf bezueglich Biotop',
  `TPopKontrUebFlaeche` int(10) DEFAULT NULL COMMENT 'Ueberpruefte Flaeche in m2. Freiwilligen-Erfolgskontrolle',
  `TPopKontrPlan` tinyint(1) DEFAULT NULL COMMENT 'Flaeche / Wuchsort auf Plan eingezeichnet? Freiwilligen-Erfolgskontrolle',
  `TPopKontrVeg` smallint(5) DEFAULT NULL COMMENT 'Von Pflanzen, Streu oder Moos bedeckter Boden (%). Freiwilligen- Erfolgskontrolle',
  `TPopKontrNaBo` smallint(5) DEFAULT NULL COMMENT 'Flaechenanteil nackter Boden (%). Freiwilligen-Erfolgskontrolle',
  `TPopKontrUebPfl` smallint(5) DEFAULT NULL COMMENT 'Flaechenanteil der ueberprueften Pflanzenart (%). Freiwilligen-Erfolgskontrolle',
  `TPopKontrJungPflJN` tinyint(1) DEFAULT NULL COMMENT 'Gibt es neben alten Pflanzen auch junge? Freiwilligen-Erfolgskontrolle',
  `TPopKontrVegHoeMax` smallint(5) DEFAULT NULL COMMENT 'Maximale Vegetationshoehe in cm. Freiwilligen-Erfolgskontrolle',
  `TPopKontrVegHoeMit` smallint(5) DEFAULT NULL COMMENT 'Vegetationshoehe Mittelwert in cm. Freiwilligen-Erfolgskontrolle',
  `TPopKontrGefaehrdung` varchar(255) DEFAULT NULL COMMENT 'Gefaehrdung. Freiwilligen-Erfolgskontrolle',
  `TPopKontrMutDat` datetime DEFAULT NULL COMMENT 'Letzte Mutation. Wird benoetigt, um zu klaeren, welche Daten in den nationalen Kreislauf exportiert werden sollen',
  `TPopKontrGuid` varchar(40) DEFAULT NULL COMMENT 'GUID. Wird u.a. verwendet fuer die Identifikation der Beobachtung im nationalen Beobachtungs-Daten-Kreislaufs',
  `ZeitGuid` varchar(40) DEFAULT NULL COMMENT 'GUID fuer den Export von Zeiten in EvAB',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`TPopKontrId`),
  KEY `TPopId` (`TPopId`),
  KEY `TPopKontrBearb` (`TPopKontrBearb`),
  KEY `TPopKontrZaehleinheit1` (`TPopKontrZaehleinheit1`),
  KEY `TPopKontrMethode1` (`TPopKontrMethode1`),
  KEY `TPopKontrZaehleinheit2` (`TPopKontrZaehleinheit2`),
  KEY `TPopKontrMethode2` (`TPopKontrMethode2`),
  KEY `TPopKontrZaehleinheit3` (`TPopKontrZaehleinheit3`),
  KEY `TPopKontrMethode3` (`TPopKontrMethode3`),
  KEY `TPopKontrEntwicklung` (`TPopKontrEntwicklung`),
  KEY `DomainTPopKontrIdBiotUebereinst` (`TPopKontrIdealBiotopUebereinst`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Feldkontrollen von Teilpopulationen' AUTO_INCREMENT=2147008978 ;

--
-- Trigger `tblTeilPopFeldkontrolle`
--
DROP TRIGGER IF EXISTS `newguid`;
DELIMITER //
CREATE TRIGGER `newguid` BEFORE INSERT ON `tblTeilPopFeldkontrolle`
 FOR EACH ROW set new.TPopKontrGuid = UUID()
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblTeilPopMassnahme`
--

CREATE TABLE IF NOT EXISTS `tblTeilPopMassnahme` (
  `TPopMassnId` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle tblMassnahme',
  `TPopId` int(10) DEFAULT NULL COMMENT 'Fremdschluessel aus der Tabelle tblTeilpopulation',
  `TPopMassnTyp` int(10) DEFAULT NULL COMMENT 'Typ aus DomainTPopMassnTyp',
  `TPopMassnTxt` varchar(255) DEFAULT NULL COMMENT 'Was wurde gemacht? V.a. fuer andere Massnahme',
  `TPopMassnJahr` smallint(5) DEFAULT NULL COMMENT 'Jahr, in dem die Massnahme durchgefuehrt wurde',
  `TPopMassnDatum` date DEFAULT NULL,
  `TPopMassnBearb` int(10) DEFAULT NULL COMMENT 'BearbeiterIn Massnahme: tblAdr',
  `TPopMassnBemTxt` longtext COMMENT 'Bemerkungen zur Massnahme',
  `TPopMassnPlan` tinyint(1) DEFAULT NULL COMMENT 'Plan vorhanden?',
  `TPopMassnPlanBez` varchar(255) DEFAULT NULL COMMENT 'Bezeichnung auf dem Plan',
  `TPopMassnFlaeche` int(10) DEFAULT NULL COMMENT 'Flaeche der Massnahme bzw. Teilpopulation (m2)',
  `TPopMassnMarkierung` varchar(255) DEFAULT NULL COMMENT 'Markierung der Massnahme bzw. Teilpopulation',
  `TPopMassnAnsiedAnzTriebe` int(10) DEFAULT NULL COMMENT 'Anzahl angesiedelte Triebe',
  `TPopMassnAnsiedAnzPfl` int(10) DEFAULT NULL COMMENT 'Anzahl angesiedelte Pflanzen',
  `TPopMassnAnzPflanzstellen` int(10) DEFAULT NULL COMMENT 'Anzahl Toepfe/Pflanzstellen',
  `TPopMassnAnsiedWirtspfl` varchar(255) DEFAULT NULL COMMENT 'Wirtspflanze',
  `TPopMassnAnsiedHerkunftPop` varchar(255) DEFAULT NULL COMMENT 'Aus welcher Population stammt das Pflanzenmaterial?',
  `TPopMassnAnsiedDatSamm` varchar(50) DEFAULT NULL COMMENT 'Datum, an dem die angesiedelten Pflanzen gesammelt wurden',
  `TPopMassnAnsiedForm` varchar(255) DEFAULT NULL COMMENT 'Form, Groesse der Ansiedlung',
  `TPopMassnAnsiedPflanzanordnung` varchar(255) DEFAULT NULL COMMENT 'Anordnung der Pflanzung',
  `TPopMassnGuid` varchar(40) DEFAULT NULL COMMENT 'GUID der Tabelle tblTeilPopMassnahme',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`TPopMassnId`),
  UNIQUE KEY `guid` (`TPopMassnGuid`),
  KEY `TPopId` (`TPopId`),
  KEY `TPopMassnBearb` (`TPopMassnBearb`),
  KEY `TPopMassnTyp` (`TPopMassnTyp`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Massnahmen in Teilpopulationen' AUTO_INCREMENT=2145292510 ;

--
-- Trigger `tblTeilPopMassnahme`
--
DROP TRIGGER IF EXISTS `newguidtpm`;
DELIMITER //
CREATE TRIGGER `newguidtpm` BEFORE INSERT ON `tblTeilPopMassnahme`
 FOR EACH ROW set new.TPopMassnGuid = UUID()
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblTeilPopMassnBericht`
--

CREATE TABLE IF NOT EXISTS `tblTeilPopMassnBericht` (
  `TPopMassnBerId` int(10) NOT NULL AUTO_INCREMENT,
  `TPopId` int(10) DEFAULT NULL,
  `TPopMassnBerJahr` smallint(5) DEFAULT NULL,
  `TPopMassnBerErfolgsbeurteilung` int(10) DEFAULT NULL,
  `TPopMassnBerTxt` longtext,
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`TPopMassnBerId`),
  KEY `TPopId` (`TPopId`),
  KEY `TPopMassnBerErfolgsbeurteilung` (`TPopMassnBerErfolgsbeurteilung`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2139935507 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblTeilpopulation`
--

CREATE TABLE IF NOT EXISTS `tblTeilpopulation` (
  `TPopId` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle tblTeilpopulation',
  `PopId` int(10) DEFAULT NULL COMMENT 'ID der Tabelle tblPopulation',
  `TPopNr` int(10) DEFAULT NULL COMMENT 'Nummer der Teilpopulation',
  `TPopGemeinde` varchar(255) DEFAULT NULL COMMENT 'Gemeinde',
  `TPopFlurname` varchar(255) DEFAULT NULL COMMENT 'Flurname',
  `TPopXKoord` int(10) DEFAULT NULL COMMENT 'X-Koordinate der Teilpopulation',
  `TPopYKoord` int(10) DEFAULT NULL COMMENT 'Y-Koordinate der Teilpopulation',
  `TPopPunktgeometrie` point DEFAULT NULL,
  `TPopRadius` smallint(5) DEFAULT NULL COMMENT 'Radius der Teilpopulation (m)',
  `TPopHoehe` smallint(5) DEFAULT NULL COMMENT 'Hoehe ue. M. (m)',
  `TPopExposition` varchar(50) DEFAULT NULL COMMENT 'Exposition / Besonnung des Standorts',
  `TPopKlima` varchar(50) DEFAULT NULL COMMENT 'Klima des Standorts',
  `TPopNeigung` varchar(50) DEFAULT NULL COMMENT 'Hangneigung des Standorts',
  `TPopBeschr` varchar(255) DEFAULT NULL COMMENT 'Beschreibung der Flaeche',
  `TPopKatNr` varchar(255) DEFAULT NULL COMMENT 'Kataster-Nummer',
  `TPopVerantw` int(10) DEFAULT NULL COMMENT 'Verantwortliche Fachperson: tblAdr',
  `TPopHerkunft` int(10) DEFAULT NULL COMMENT 'Herkunft der Teilpopulation: autochthon oder angesiedelt? Aus DomainPopHerkunft',
  `TPopHerkunftUnklar` tinyint(1) DEFAULT NULL COMMENT 'Ist der Status der Teilpopulation unklar? (es bestehen keine glaubwuerdigen Beboachtungen)',
  `TPopHerkunftUnklarBegruendung` varchar(255) DEFAULT NULL COMMENT 'Wieso ist der Status unklar?',
  `TPopApBerichtRelevant` int(10) DEFAULT NULL COMMENT 'Ist die Teilpopulation fuer den AP-Bericht relevant? DomainTPopApBerichtRelevant',
  `TPopBekanntSeit` smallint(5) DEFAULT NULL COMMENT 'Seit wann ist die Teilpopulation bekannt?',
  `TPopEigen` varchar(255) DEFAULT NULL COMMENT 'EigentuemerIn',
  `TPopKontakt` varchar(255) DEFAULT NULL COMMENT 'Kontaktperson vor Ort',
  `TPopNutzungszone` varchar(255) DEFAULT NULL COMMENT 'Nutzungszone',
  `TPopBewirtschafterIn` varchar(255) DEFAULT NULL COMMENT 'Wer bewirtschaftet die Flaeche?',
  `TPopBewirtschaftung` varchar(255) DEFAULT NULL COMMENT 'Wie wird die Flaeche bewirtschaftet?',
  `TPopTxt` longtext COMMENT 'Bemerkungen zur Teilpopulation',
  `TPopAuswahl` tinyint(1) DEFAULT '0' COMMENT 'Mit Hilfe dieses Felds koennen Teilpopulation voruebergehend ausgewaehlt werden',
  `TPopGuid` varchar(40) DEFAULT NULL,
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`TPopId`),
  KEY `PopId` (`PopId`),
  KEY `TPopGuid` (`TPopGuid`),
  KEY `TPopHerkunft` (`TPopHerkunft`),
  KEY `TPopVerantw` (`TPopVerantw`),
  KEY `TPopApBerichtRelevant` (`TPopApBerichtRelevant`),
  KEY `xkoord` (`TPopXKoord`),
  KEY `ykoord` (`TPopYKoord`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Angaben zu Teilpopulationen' AUTO_INCREMENT=2146451643 ;

--
-- Trigger `tblTeilpopulation`
--
DROP TRIGGER IF EXISTS `newguidtp`;
DELIMITER //
CREATE TRIGGER `newguidtp` BEFORE INSERT ON `tblTeilpopulation`
 FOR EACH ROW set new.TPopGuid = UUID()
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblTeiPopFuerAuswahl`
--

CREATE TABLE IF NOT EXISTS `tblTeiPopFuerAuswahl` (
  `TPopId` int(10) NOT NULL DEFAULT '0' COMMENT 'ID der Tabelle tblTeilpopulation',
  PRIMARY KEY (`TPopId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Hilfstabelle, um sich eine Auswahl von TPop zu merken';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblUmweltFaktoren`
--

CREATE TABLE IF NOT EXISTS `tblUmweltFaktoren` (
  `UfApArtId` int(11) NOT NULL COMMENT 'ID der Tabelle tblIdealbiotop, Fremdschluessel aus tblAktionsplan',
  `UfErstelldatum` date DEFAULT NULL COMMENT 'Erstelldatum',
  `UfHoehenlage` text COMMENT 'Hoehenlage',
  `UfRegion` text COMMENT 'Region',
  `UfExposition` text COMMENT 'Exposition',
  `UfBesonnung` text COMMENT 'Besonnung',
  `UfHangneigung` text COMMENT 'Hangneigung',
  `UfBodenTyp` text COMMENT 'Bodentyp',
  `UfBodenKalkgehalt` text COMMENT 'Kalkgehalt im Boden',
  `UfBodenDurchlaessigkeit` text COMMENT 'Bodendurchlaessigkeit',
  `UfBodenHumus` text COMMENT 'Bodenhumusgehalt',
  `UfBodenNaehrstoffgehalt` text COMMENT 'Bodennaehrstoffgehalt',
  `UfWasserhaushalt` text COMMENT 'Wasserhaushalt',
  `UfKonkurrenz` text COMMENT 'Konkurrenz',
  `UfMoosschicht` text COMMENT 'Moosschicht',
  `UfKrautschicht` text COMMENT 'Krautschicht',
  `UfStrauchschicht` text COMMENT 'Strauchschicht',
  `UfBaumschicht` text COMMENT 'Baumschicht',
  `UfBemerkungen` text NOT NULL COMMENT 'Bemerkungen',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt veraendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Wer hat den Datensatz zuletzt veraendert?',
  PRIMARY KEY (`UfApArtId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Ideale Umweltfaktoren';

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblUser`
--

CREATE TABLE IF NOT EXISTS `tblUser` (
  `UserName` varchar(30) NOT NULL,
  `Passwort` text NOT NULL,
  `NurLesen` tinyint(1) DEFAULT '-1' COMMENT 'Hier Ja setzen, wenn ein User keine Daten aendern darf',
  PRIMARY KEY (`UserName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblZiel`
--

CREATE TABLE IF NOT EXISTS `tblZiel` (
  `ZielId` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle Ziele',
  `ApArtId` int(10) DEFAULT NULL COMMENT 'Fremdschluessel aus der Tabelle tblAktionsplan',
  `ZielTyp` int(10) DEFAULT NULL COMMENT 'z.B. Zwischenziel, Gesamtziel. Aus DomainZielTyp',
  `ZielJahr` smallint(5) DEFAULT NULL COMMENT 'Wann soll das Ziel erreicht werden?',
  `ZielBezeichnung` longtext COMMENT 'Textliche Beschreibung des Ziels',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`ZielId`),
  KEY `ApArtId` (`ApArtId`),
  KEY `ZielTyp` (`ZielTyp`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='AP-Ziele' AUTO_INCREMENT=2125272821 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tblZielBericht`
--

CREATE TABLE IF NOT EXISTS `tblZielBericht` (
  `ZielBerId` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID der Tabelle tblZielBericht',
  `ZielId` int(10) DEFAULT NULL COMMENT 'Fremdschluessel aus der Tabelle tblZiel',
  `ZielBerJahr` smallint(5) DEFAULT NULL COMMENT 'Fuer welches Jahr gilt der Bericht?',
  `ZielBerErreichung` varchar(255) DEFAULT NULL COMMENT 'Beurteilung der Zielerreichung',
  `ZielBerTxt` varchar(255) DEFAULT NULL COMMENT 'Bemerkungen zur Zielerreichung',
  `MutWann` date DEFAULT NULL COMMENT 'Wann wurde der Datensatz zuletzt geaendert?',
  `MutWer` varchar(20) DEFAULT NULL COMMENT 'Von wem wurde der Datensatz zuletzt geaendert?',
  PRIMARY KEY (`ZielBerId`),
  KEY `ZielId` (`ZielId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Berichte ueber AP-Ziele' AUTO_INCREMENT=2137502991 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tpm_line`
--

CREATE TABLE IF NOT EXISTS `tpm_line` (
  `TpmLineId` int(10) NOT NULL AUTO_INCREMENT,
  `TpmLineLine` linestring NOT NULL,
  `TPopMassnGuid` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`TpmLineId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tpm_point`
--

CREATE TABLE IF NOT EXISTS `tpm_point` (
  `TpmPointId` int(10) NOT NULL AUTO_INCREMENT,
  `TpmPointPoint` point NOT NULL,
  `TPopMassnGuid` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`TpmPointId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tpm_polygon`
--

CREATE TABLE IF NOT EXISTS `tpm_polygon` (
  `TpmPolyId` int(10) NOT NULL AUTO_INCREMENT,
  `TpmPolyPolygon` polygon NOT NULL,
  `TPopMassnGuid` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`TpmPolyId`),
  KEY `guid` (`TPopMassnGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
